import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitiPriorityComponent } from './citi-priority.component';

describe('CitiPriorityComponent', () => {
  let component: CitiPriorityComponent;
  let fixture: ComponentFixture<CitiPriorityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitiPriorityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitiPriorityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
