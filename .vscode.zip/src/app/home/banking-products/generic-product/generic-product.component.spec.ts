import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenericProductComponent } from './generic-product.component';

describe('GenericProductComponent', () => {
  let component: GenericProductComponent;
  let fixture: ComponentFixture<GenericProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
