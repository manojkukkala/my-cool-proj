import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generic-product',
  templateUrl: './generic-product.component.html',
  styleUrls: ['./generic-product.component.css']
})
export class GenericProductComponent implements OnInit {

  card: object = [{ 
    "moduleName":"Card 1",
    "product":"citigold",
    "productTitle":"",
    "featureOne": [{
        "header":"Banking and Wealth Management",
        "list": true,
            "featureOneText": [{
                "text":""},
                {
                "text": "" }]
                }],
    "featureTwo": [{
        "header":"",
        "list": true,
            "featureTwoText": [{
                "text":"Professional strategies and guidance from a Citi Personal Wealth Management Financial Advisor by phone" },
              {
                "text":"Investment resources to simplify your financial decisions" },
              {
                "text":"Preferred pricing and rates on select deposit products and services" },
              {
                "text":"Ability to earn a higher level of Citi ThankYou Rewards Points offered for a checking relationship" },
              {
                "text":"A robust library of online financial education articles and tools" }]
                }],
    "featureThree": [{
        "header":"To waive the $30 monthly service fee",
        "list": false,        
            "featureThreeText": [{
                "text":"Maintain a combined average monthly balance of $50,000+ in eligible linked deposit, retirement and investment accounts." }]
                }],            
    "primaryCtaLabel":"See details",
    "primaryCtaURL":"https://online.citi.com/US/banking/checking/citi.action?ID=citigold"
}]
  constructor() { }

  ngOnInit() {
  }

}
