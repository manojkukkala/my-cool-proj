import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-with-citi',
  templateUrl: './bank-with-citi.component.html',
  styleUrls: ['./bank-with-citi.component.css']
})
export class BankWithCitiComponent implements OnInit {

  copy: object = [{
    "copyTitle": "When you bank with Citi, you can:", 
    "columnOne" : [{
          "text": "Open a checking account with no minimum opening deposit"},
          {
          "text": "Pay your bills online"},
          {
          "text": "Deposit checks from your mobile device"},
          {
          "text": "Deposit checks from your mobile device"},
          {
          "text": "Easily move money between your Citi and non-Citi accounts",
      }],
    "columnTwo" : [{
          "text": "Set up balance and payment alerts"},
          {
          "text": "Get access to entertainment and dining perks with Citi® Private Pass using your Citi Debit Card"},
          {
          "text": "Add your Citi Debit Card to mobile wallets"},
          {
          "text": "Use thousands of fee-free ATMs throughout the US"},
          {
          "text": "Access even more benefits, including the opportunity to enroll in Citi ThankYou® Rewards with an eligible checking package",
      }]
  }]

  promo: object = [{
    "promoText": "Need help choosing the right account package?",
    "promoCtaLabel": "Find your best fit",
    "promoCtaURL":"https://online.citi.com/US/login.do"
  }]

  constructor() { }

  ngOnInit() {
  }

}
