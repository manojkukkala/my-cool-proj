import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VacationExpensesComponent } from './vacation-expenses.component';

describe('VacationExpensesComponent', () => {
  let component: VacationExpensesComponent;
  let fixture: ComponentFixture<VacationExpensesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VacationExpensesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationExpensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
