import { Component, OnInit, Renderer2 } from '@angular/core';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { SessionTimeoutHandler, RenewSessionHandler, AppConfigService } from 'angular-nexus-uiux/services';
import { Http } from '@angular/http';
import { CbolCoreContentService } from '../services/cbol-core-content.service';
import { CbolSessionService } from '../services/cbol-session.service';
import { Subscription } from 'rxjs/Rx';
import { Router, NavigationEnd } from '@angular/router';

@Component({
	selector: 'cbol-session',
	templateUrl: './cbol-session.component.html'
})
export class CbolSessionComponent implements OnInit {

	public showTimeOutOverlay: Boolean = false;
	public minsLeft: Number;
	public secsLeft: Number;
	public content: any = {};
	private _routerChangeSubscription: Subscription;
	private rendererHandle: any;

	constructor(private _sessionService: CbolSessionService,
		private _http: Http,
		private _appConfigService: AppConfigService,
		private coreContent: CbolCoreContentService,
		private _router: Router,
		private renderer: Renderer2) { }

	ngOnInit() {

		this.content = this.coreContent.getContentForKey('copy$$SessionTimeOut');
		const sessionTimeoutHandler: SessionTimeoutHandler = (): void => {
			this._routerChangeSubscription.unsubscribe();
			window.location.href = this._appConfigService.getConfig('sessionService').sessionTimeoutUrl;
		};

		const renewSessionHandler: RenewSessionHandler = (): void => {
			if (Cookie.get('NGACoExistenceCookie')) {
				if (Cookie.get('NGAKeepAOAlive')) {
					this._http.get(Cookie.get('NGAKeepAOAlive')).subscribe();
				}
			}
		};


		/* Listen to router change to identify and initialize post login session timeout.*/
		this._routerChangeSubscription = this._router.events
			.filter(event => event instanceof NavigationEnd)
			.subscribe((event) => {
				console.log('router event detected!', Cookie.get('NGACoExistenceCookie'), this._sessionService.isTimerInitialized());
				if (this._sessionService.isTimerInitialized() === false && Cookie.get('NGACoExistenceCookie')) {
					console.log('init timer');
					this._sessionService.start(sessionTimeoutHandler, renewSessionHandler);
					this.rendererHandle = this.renderer.listen('document', 'click', (event) => {
						this._sessionService.clickHandler(true);
					});
				} else if (this._sessionService.isTimerInitialized() === true && !Cookie.get('NGACoExistenceCookie')) {
					console.log('reset timer');
					this._sessionService.resetSession();
					this.rendererHandle(); // unbind click event on document
				}
			});


		this._sessionService.getSessionEmitter().subscribe((event) => {
			if (event === 'showOverLay') {
				this.showTimeOutOverlay = true;
			} else {
				console.log(event);
				const remTime = 120 - event;
				if (remTime > 0) {
					this.minsLeft = Math.floor(remTime / 60);
					this.secsLeft = Math.floor(remTime % 60);
				} else {
					this._sessionService.executeTImeout();
				}
			}
		});

	}

	onEndUserSession() {
		console.log('end user session');
		this._sessionService.executeTImeout();
	}

	onContinueUserSession() {
		this.showTimeOutOverlay = false;
		this._sessionService.renew();
	}

	/* Disables tracking user clicks when the timeout modal is active.*/
	isModalShown(event) {
		this._sessionService.toggleActivityCheck(event);
	}

}
