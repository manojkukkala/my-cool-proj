import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnauthorizedComponent } from './component/unauthorized.component';
import { NonFatalErrorComponent } from './component/cbol-core-nonFatalError.component';

export const routes: Routes = [
	{
		path: '',
		redirectTo: 'credit-cards',
		pathMatch: 'full'
	},
	{
		path: 'credit-cards',
		loadChildren: '../home/home.module#HomeModule'
	},
    {
		path: 'banking',
		loadChildren: '../banking/banking.module#BankingModule'
	},
	{
		path: 'articles',
		loadChildren: '../articles/articles.module#ArticlesModule'
	},
	{
		path: 'credit-cards/knowledge-center',
		loadChildren: '../knowledge-center/knowledge-center.module#KnowledgeCenterModule'
	},
	{
		path: 'credit-cards/help-center',
		loadChildren: '../help-center/help-center.module#HelpCenterModule'
	},
	{
		path: 'unauthorized',
		component: UnauthorizedComponent
	},
	{
		path: 'error',
		component: NonFatalErrorComponent
	}

];


@NgModule({
	imports: [
		RouterModule.forRoot(routes)
	],
	exports: [RouterModule]
})
export class CbolCoreRoutingModule { }
