import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhatToKnowAboutCashBackCreditCardsComponent } from './what-to-know-about-cash-back-credit-cards.component';

describe('WhatToKnowAboutCashBackCreditCardsComponent', () => {
  let component: WhatToKnowAboutCashBackCreditCardsComponent;
  let fixture: ComponentFixture<WhatToKnowAboutCashBackCreditCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhatToKnowAboutCashBackCreditCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhatToKnowAboutCashBackCreditCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
