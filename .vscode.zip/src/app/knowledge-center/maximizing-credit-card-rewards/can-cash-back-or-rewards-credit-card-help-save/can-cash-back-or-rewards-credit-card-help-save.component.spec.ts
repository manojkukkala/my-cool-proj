import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CanCashBackOrRewardsCreditCardHelpSaveComponent } from './can-cash-back-or-rewards-credit-card-help-save.component';

describe('CanCashBackOrRewardsCreditCardHelpSaveComponent', () => {
  let component: CanCashBackOrRewardsCreditCardHelpSaveComponent;
  let fixture: ComponentFixture<CanCashBackOrRewardsCreditCardHelpSaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CanCashBackOrRewardsCreditCardHelpSaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CanCashBackOrRewardsCreditCardHelpSaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
