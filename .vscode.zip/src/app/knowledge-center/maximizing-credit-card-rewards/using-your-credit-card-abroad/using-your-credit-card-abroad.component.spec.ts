import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsingYourCreditCardAbroadComponent } from './using-your-credit-card-abroad.component';

describe('UsingYourCreditCardAbroadComponent', () => {
  let component: UsingYourCreditCardAbroadComponent;
  let fixture: ComponentFixture<UsingYourCreditCardAbroadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsingYourCreditCardAbroadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsingYourCreditCardAbroadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
