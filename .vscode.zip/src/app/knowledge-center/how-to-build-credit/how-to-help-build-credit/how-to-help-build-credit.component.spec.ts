import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToHelpBuildCreditComponent } from './how-to-help-build-credit.component';

describe('HowToHelpBuildCreditComponent', () => {
  let component: HowToHelpBuildCreditComponent;
  let fixture: ComponentFixture<HowToHelpBuildCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToHelpBuildCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToHelpBuildCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
