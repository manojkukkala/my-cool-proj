import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonCreditCardTermsDecodedComponent } from './common-credit-card-terms-decoded.component';

describe('CommonCreditCardTermsDecodedComponent', () => {
  let component: CommonCreditCardTermsDecodedComponent;
  let fixture: ComponentFixture<CommonCreditCardTermsDecodedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonCreditCardTermsDecodedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonCreditCardTermsDecodedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
