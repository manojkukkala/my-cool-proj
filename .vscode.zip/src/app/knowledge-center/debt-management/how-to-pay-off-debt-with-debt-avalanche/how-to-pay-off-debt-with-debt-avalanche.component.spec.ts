import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToPayOffDebtWithDebtAvalancheComponent } from './how-to-pay-off-debt-with-debt-avalanche.component';

describe('HowToPayOffDebtWithDebtAvalancheComponent', () => {
  let component: HowToPayOffDebtWithDebtAvalancheComponent;
  let fixture: ComponentFixture<HowToPayOffDebtWithDebtAvalancheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToPayOffDebtWithDebtAvalancheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToPayOffDebtWithDebtAvalancheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
