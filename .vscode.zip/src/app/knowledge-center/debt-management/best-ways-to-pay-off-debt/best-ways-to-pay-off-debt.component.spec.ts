import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BestWaysToPayOffDebtComponent } from './best-ways-to-pay-off-debt.component';

describe('BestWaysToPayOffDebtComponent', () => {
  let component: BestWaysToPayOffDebtComponent;
  let fixture: ComponentFixture<BestWaysToPayOffDebtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BestWaysToPayOffDebtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BestWaysToPayOffDebtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
