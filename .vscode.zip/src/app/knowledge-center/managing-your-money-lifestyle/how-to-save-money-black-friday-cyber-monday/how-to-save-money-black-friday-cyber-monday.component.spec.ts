import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToSaveMoneyBlackFridayCyberMondayComponent } from './how-to-save-money-black-friday-cyber-monday.component';

describe('HowToSaveMoneyBlackFridayCyberMondayComponent', () => {
  let component: HowToSaveMoneyBlackFridayCyberMondayComponent;
  let fixture: ComponentFixture<HowToSaveMoneyBlackFridayCyberMondayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToSaveMoneyBlackFridayCyberMondayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToSaveMoneyBlackFridayCyberMondayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
