import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToPayOffDebtComponent } from './how-to-pay-off-debt.component';

describe('HowToPayOffDebtComponent', () => {
  let component: HowToPayOffDebtComponent;
  let fixture: ComponentFixture<HowToPayOffDebtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToPayOffDebtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToPayOffDebtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
