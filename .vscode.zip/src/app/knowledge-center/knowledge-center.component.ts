import { Datastore } from '../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../drupal-content-services/models/nodes/marketing_page.model';
import { ShowcaseComponent } from '../uicomponents-with-content/showcase/showcase.component';

import { ContentfulService } from '../contentful-services/contentful.service';
import { connectableObservableDescriptor } from 'rxjs/observable/ConnectableObservable';
@Component({
  selector: 'app-knowledge-center',
  templateUrl: './knowledge-center.component.html',
  styleUrls: ['./knowledge-center.component.css']
})
export class KnowledgeCenterComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  private pageId = "f548bba3-1424-41cb-adb1-27dbff28943b";

  mp: MarketingPageModel;
  cf;
  
  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};
   
  version;
  //Merge all query paramters in queryParamters
  private queryParameters = {};
  id;
  public isLoaded: boolean = false;

  constructor(private datastore: Datastore,private contentfulService :ContentfulService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.contentfulService.getCourses()
    .then(faqDs => {
      let data = faqDs.filter(_marketPage =>{
        return _marketPage.sys.contentType.sys.id === "marketingPage"
      })
      this.cf = data[0].fields;
      this.version = this.cf.actionType.fields.version[0]
      this.id = data[0].sys.id;
      this.isLoaded = true;
    })  
    // this.datastore.findRecord(MarketingPageModel, this.pageId, this.queryParameters)
    //   .subscribe((marketingPage: MarketingPageModel) => {
    //     this.mp = marketingPage;
    //     console.log("marketing page",marketingPage);
    //     this.isLoaded = true;
    //   });
  }
}

