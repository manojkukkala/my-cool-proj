import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleCheckingComponent } from './simple-checking.component';

describe('SimpleCheckingComponent', () => {
  let component: SimpleCheckingComponent;
  let fixture: ComponentFixture<SimpleCheckingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimpleCheckingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleCheckingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
