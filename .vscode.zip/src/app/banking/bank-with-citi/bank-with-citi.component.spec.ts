import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankWithCitiComponent } from './bank-with-citi.component';

describe('BankWithCitiComponent', () => {
  let component: BankWithCitiComponent;
  let fixture: ComponentFixture<BankWithCitiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankWithCitiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankWithCitiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
