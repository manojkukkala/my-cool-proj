import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
import { FileDataModel } from '../nodes/file.model';

@JsonApiModelConfig({
    type: 'article_related'
})
export class ArticleRelatedModel extends JsonApiModel {
    
    @BelongsTo()
    articleRelatedImage: FileDataModel;
    
    @Attribute()
    articleRelatedLink: Link;    
}