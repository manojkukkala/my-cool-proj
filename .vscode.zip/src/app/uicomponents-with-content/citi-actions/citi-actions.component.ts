import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-citi-actions',
  templateUrl: './citi-actions.component.html',
  styleUrls: ['./citi-actions.component.css']

})


export class CitiActionsComponent implements OnInit {
  @Input() components= [];
  constructor() { }
// Style for small titles
/*public smallTitleStyle = {
  'margin-bottom': '0px',
  'font-size': '26px'
};

// style for big titles
public bigTitleStyle = {
  'margin-bottom': '20px',
  'font-size': '46px'
};*/
  ngOnInit() {
  }

}
