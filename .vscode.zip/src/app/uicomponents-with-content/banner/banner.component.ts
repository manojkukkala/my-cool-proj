import { Component, OnInit, Input } from '@angular/core';
import { environment } from 'environments/environment'
import { BannerModel } from "app/drupal-content-services/models/paragraphs/banner.model";
import { BannerDataModel } from '../../drupal-content-services/models/nodes';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css']
})
export class BannerComponent implements OnInit {

  @Input() component: BannerModel;
  @Input() bannerData: BannerDataModel;
  @Input() dynamic: boolean;


  public env = environment.drupalUrl;

  public bannerDelivery = this.dynamic;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
    console.log('Data', this.bannerData);
    this.bannerDelivery = this.dynamic;
    console.log('Is Banner Dynamic? ', this.dynamic);
    
  }

}
