import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';

@Component({
  selector: 'app-breadcrumb-contentful',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbContenfulComponent implements OnInit {
  @Input() component;
  breadcrumb
  constructor() { }

  ngOnInit() {
    this.breadcrumb = this.component.fields;
  }

  isObject(obj){
    return _.isObject(obj);
  }

}
