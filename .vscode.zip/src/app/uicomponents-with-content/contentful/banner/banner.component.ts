import { Component, OnInit, Input } from '@angular/core';

import { environment } from 'environments/environment'
@Component({
  selector: 'app-banner-contentful',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css']
})
export class BannerContentfulComponent implements OnInit {

  @Input() component;

  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId
  constructor() { }

  ngOnInit() {
    
  }

}
