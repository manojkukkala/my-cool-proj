export const environment = {
	production: false,
	environment: 'DIT',
	drupalUrl: 'http://cddemo10ode52.prod.acquia-sites.com',
	apiServerUrl: 'https://sit.api.citi.com/gcgapi/dev1/public/v1',
	locale: 'en_US',
	businessId: 'USGCB',
	snarejsUrl: 'https://ci-mpsnare.iovation.com/snare.js',
	amwSubDomainName: 'paperuat.citi.com',
	amwSnippetId: '1278930',
	ensightenHost: 'https://nexus.ensighten.com/citi/na_dev',
	crossSiteScriptingRegex: /\00|<|\+ADw-|>|\+AD4-|%25|\(\s*[a-z]{2,}\.[a-z]{2,}.*\)/g,
	sessionCookieInformation: {

		cookieName: 'NGACoExistenceCookie',
		valueSeparator: '|',
		headers: [
			{
				headerName: 'bizToken',
				headerValue: '[bizToken]'
			},
			{
				headerName: 'Authorization',
				headerValue: 'Bearer [authToken]'
			},
			{
				headerName: 'client_id',
				headerValue: '[clientId]'
			}
		],
		isFriendKey: 'isFriend'
	},

	sessionService: {
		sessionTimeout: 600,
		keepAliveInterval: 180,
		sessionKeepAliveUrl: 'https://sit.api.citi.com/gcgapi/dev1/public/v1/public/sso/keepalive',
		sessionTimeoutUrl: 'https://dit31.online.citi.com/US/JSO/signon/CBOLSessionRecovery.do'
	},

	contentService: {
		staticBaseUrl: 'http://localhost:3000/assets',
		bundles: {
			static_test: {
				businessId: 'BUSIDSTATICTEST',
				locale: 'en_US'
			}
		}
	},

	mfaUiService: {
		bundleName: 'mfa_common',
		pinBlockedUrl: 'https://dit31.online.citi.com/JSO/signoff/Signoff.do?eostype=OTPBlockedPIN'
	},
	idleTimeRouterService: {
		routeAfter: 600,
		routingInfo: [
			{
				appName: 'TY',
				routeUrl: 'https://thankyou.com'
			}
		],
		defaultRoute: 'https://dit31.online.citi.com/US/login.do'
	},

	httpService: {
		defaultHeaders:
		{
			'Content-Type': 'application/json',
			'client_id': '19ec18cc-9580-43d5-8449-90cd2e13edb1',
			'businessCode': 'GCB',
			'countryCode': 'US',
			'channelId': 'CBOL',
			'Accept': 'application/json',
			'uuid': 'e941b996-ada1-4f4f-ab76-cf3aaf96c100'
		},
		headersToSendFromPreviousResponse: [
			{
				headerNameInPreviousResponse: 'CCPToken',
				headerNameToSendInRequest: 'CCPToken'
			},
			{
				headerNameInPreviousResponse: 'bizToken',
				headerNameToSendInRequest: 'bizToken',
				deleteOnAppLoad: true
			}
		]
	},
	mapService: {
		googleApiKey: 'AIzaSyBm5OAD_gzMWGCYtZMQQqYCEnRngONa9qw',
		endpointUrl: '//sit.api.citi.com/gcgapi/dev1/public/v1/geoLocations/places/retrieve'
	},
	customConfig: {
		brandingEndpoint: '/CBOLUS/branding',
		errorUrl: '/US/JPS/portal/Unauthorized.do',
		chatServiceEndpoint: 'https://vm-f1a3-a41e.nam.nsroot.net:8885/chat/getChatConfig?screenId=',
		chatScriptSrc: 'https://vm-f1a3-a41e.nam.nsroot.net:8885/JEA/CHAT/js/injectChat.js'
	}

}
