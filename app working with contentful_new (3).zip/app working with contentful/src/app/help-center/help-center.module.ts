import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreCommonModule } from 'angular-nexus-uiux';
import { CitiModule } from 'uicomponents/citi.module';
import { AmwModule } from 'angular-container-common/amw';

import { UIComponentsWithContentModule } from '../uicomponents-with-content/uicomponents-with-content.module';
import { HelpCenterComponent } from "./help-center.component";
import { HelpCenterRoutingModule } from "./help-center-routing.module";

@NgModule({
  imports: [
		CoreCommonModule,
		CitiModule,
        AmwModule, 
        HelpCenterRoutingModule,   
    UIComponentsWithContentModule
  ],
  declarations: [HelpCenterComponent] 
})
export class HelpCenterModule { }