import { HeroModel } from './../../drupal-content-services/models/paragraphs/hero.model';
import { Component, OnInit, AfterViewInit, Input, ViewChild, ElementRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { NgZone } from '@angular/core';

@Component({
  selector: 'app-hero', /*this is a re-write of citi-hero in node modules */
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css']
})
export class HeroComponent implements OnInit, AfterViewInit {

  public heroModel: HeroModel;
  public type:
  'a-1-0' | 'a-1-1' |
  'a-2-0' | 'a-2-1' | 'a-2-2' | 'a-2-3' | 'a-2-4' | 'a-2-5' | 'a-2-6' | 'a-2-7' |
  'a-3-0' |
  'a-4-0' | 'a-4-1' | 'a-4-2' | 'a-4-3' | 'a-4-4' | 'a-4-5' | 'a-4-6' | 'a-4-7'
  = 'a-1-0';
  public promoImage: string;
  public eyebrow: string;
  public heroTitle: string;
  public legend: string;
  public subHeadingTitle: string;
  public subHeadingLegend: string;
  public subHeadingImage: string;
  public subHeadingImageAlt: string;
  public citiGold: boolean = false;
  public shows: boolean = true;


  @Input() 
  set heroModelObj (heroModelObj: HeroModel) {
    this.heroModel = heroModelObj;
  }


  /**
   * @Property: heroType
   * @Description: Sets the hero type as defined in the DDL modules. Use only one of the available types.
   * The available types include the following: 'a-1-0', 'a-1-1', 'a-2-0', 'a-2-1', 'a-2-2', 'a-2-3', 'a-2-4',
   * 'a-2-5', 'a-2-6', 'a-3-0', 'a-4-0', 'a-4-1', 'a-4-2', 'a-4-3', 'a-4-4', 'a-4-5', 'a-4-6', 'a-4-7'
   * @Type: string
   * @Two-way: false
   */
  @Input()
  set heroType(type: any) {
    this.type = type;
  }

  /**
   * @Property: promoImageSrc
   * @Description: Sets the url string for the hero image source.
   * @Type: string
   */
  @Input()
  set promoImageSrc(promoImageSrc: string) {
    this.promoImage = promoImageSrc;
  }

  /**
   * @Property: eyebrowText
   * @Description: Sets the text string to be displayed as the hero eyebrow.
   * @Type: string
   */
  @Input()
  set eyebrowText(eyebrowText: string) {
    this.eyebrow = eyebrowText;
  }

  /**
   * @Property: heroTitleText
   * @Description: Sets the text string to be displayed as the hero title.
   * @Type: string
   */
  @Input()
  set heroTitleText(heroTitleText: string) {
    this.heroTitle = heroTitleText;
  }

  /**
   * @Property: legendText
   * @Description: Sets the text string to be displayed as the hero legend.
   * @Type: string
   */
  @Input()
  set legendText(legendText: string) {
    this.legend = legendText;
  }

  /**
   * @Property: subHeadingTitleText
   * @Description: Sets the text string to be displayed as the hero component subheading.
   * @Type: string
   */
  @Input()
  set subHeadingTitleText(subHeadingTitleText: string) {
    this.subHeadingTitle = subHeadingTitleText;
  }

  /**
   * @Property: subHeadingLegendText
   * @Description: Sets the text string to be displayed as the hero component subheading legend.
   * @Type: string
   */
  @Input()
  set subHeadingLegendText(subHeadingLegendText: string) {
    this.subHeadingLegend = subHeadingLegendText;
  }

  /**
   * @Property: subHeadingImageSrc
   * @Description:  Sets the url string for the subheading image source.
   * @Type: string
   */
  @Input()
  set subHeadingImageSrc(subHeadingImageSrc: string) {
    this.subHeadingImage = subHeadingImageSrc;
  }

  /**
   * @Property: subHeadingImageAltText
   * @Description:  Sets the url string for the subheading image alt text.
   * @Type: string
   */
  @Input()
  set subHeadingImageAltText(subHeadingImageAltText: string) {
    this.subHeadingImageAlt = subHeadingImageAltText;
  }

  /**
  * @Property: citiGoldBool
  * @Description:  sets background of hero title to gold if true
  * @Type: boolean
  */
  @Input()
  set citiGoldBool(citiGoldBool: boolean) {
    this.citiGold = citiGoldBool;
  }

  /**
   * @Property: htmlContent
   * @Description: Adds the given string as the content and supports simple HTML.
   * Do not pass anything within the component tags using ng-content. Do not use citi-* components in the String.
   * This works with expressions for asynchronously loaded content that will get picked up by the Angular 2 change detection.
   * @Type: string
   * @Two-way: false
   */
  @Input() htmlContent: string;

  constructor(private element: ElementRef, private _sanitizer: DomSanitizer, private zone: NgZone) { }

  ngOnInit() {

    window.onresize = (e) => {
      this.zone.run(() => {
        //`console.log('window resize:', e);
      });
    }

    if (typeof this.heroModel !== 'undefined'){
      this.heroType = this.heroModel.field_hero_type;
      this.eyebrow = this.heroModel.field_eyebrow;    
      this.heroTitle = this.heroModel.field_hero_title;
      this.legend = this.heroModel.field_legend;
      if (typeof this.heroModel.field_promo_image !== 'undefined'){
        this.promoImage = this.heroModel.field_promo_image.url;
      }
      this.subHeadingTitle = this.heroModel.field_subheading_title;
      this.subHeadingLegend = this.heroModel.field_subheading_legend;
      if (typeof this.heroModel.field_subheading_image !== 'undefined'){
        this.subHeadingImage = this.heroModel.field_subheading_image.url;
      }
      this.subHeadingImageAlt = "";
      this.citiGold = this.heroModel.field_citigold;
    }


  }

  ngAfterViewInit() {
    // debugger;
  }

  getHHClass() {

    var HHClassHeight: string = 'common-module-header';
    var HHClassBrand: string = 'citi-brand';

    if ((this.type == 'a-4-2') || (this.type == 'a-4-4') || (this.type == 'a-4-5')) {
      HHClassHeight = 'common-module-header-2';
    }

    if ((this.citiGold)) {
      HHClassBrand = 'citi-gold';
    }
    return HHClassHeight + ' ' + HHClassBrand;
  }

  getStyles() {
    return this._sanitizer.bypassSecurityTrustStyle('left:' + -this.element.nativeElement.offsetLeft + 'px; width:' + document.body.clientWidth + 'px');
  }
}
