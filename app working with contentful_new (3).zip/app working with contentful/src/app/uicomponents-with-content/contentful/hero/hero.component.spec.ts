import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeroContentfulComponent } from './hero.component';

describe('HeroContentfulComponent', () => {
  let component: HeroContentfulComponent;
  let fixture: ComponentFixture<HeroContentfulComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeroContentfulComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeroContentfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
