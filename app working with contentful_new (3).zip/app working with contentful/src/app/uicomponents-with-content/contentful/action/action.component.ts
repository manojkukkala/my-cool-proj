import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-action-contentful',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css']
})
export class ActionContentfulComponent implements OnInit {
  
  @Input() component;


  constructor() { }

  ngOnInit() {
  }

}
