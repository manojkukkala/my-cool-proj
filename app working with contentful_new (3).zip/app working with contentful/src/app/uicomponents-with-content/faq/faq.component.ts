import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { environment } from 'environments/environment'
import { Http } from '@angular/http';
import { FaqDataModel } from '../../drupal-content-services/models/nodes';

import { JsonApiQueryData } from 'angular2-jsonapi';
import { FaqfilterService } from '../../shared/services/faqfilter.service';
import { ContentfulService } from '../../contentful-services/contentful.service';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {

  @Input() faqData: FaqDataModel;
  @Input() dynamic: boolean;

  public faq_title: string;

  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId

  private faqfilterService: FaqfilterService;

  public faqDelivery = this.dynamic;

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  private _isOpen: boolean = false;

  public question: any;
  public answer: any;
  public tips: any;
  public filterFaq: any = {};
  public categoryKeys: any;
  public filterFaqs: any;
  public categoryType:any;
  public tags:any =[];

  constructor(private datastore: Datastore, private contentfulService: ContentfulService) {
    this.faqfilterService = new FaqfilterService();
    this.faq_title = "Products & Service";
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      //filter: this.faqfilterService.getfilters(),
    }

  }
  ngOnInit() { }

  ngAfterViewInit() {
    this.getContent();
  }

  getContent() {
    this.contentfulService.getCourses()
      .then(faqDs => {
        let group = [];
        let data = faqDs.filter(_faqPage =>{
          return _faqPage.sys.contentType.sys.id === "faq"
        })
        data.forEach(_content =>{
          let faqData = {}; 
          let tagArray = _content.fields['faqCategories']? _content.fields['faqCategories'].split(',')[0] : 'others';
          faqData['faqQuestion'] = _content.fields['questions'];
          faqData['faqAnswer'] = _content.fields['answers']; 
          faqData['nid']  = _content.sys['id']
          if (!this.filterFaq[tagArray]) {
            group = [];
            group.push(faqData);
          }
          else {
            group = this.filterFaq[tagArray];
            group.push(faqData);
          }
          this.filterFaq[tagArray] = group;
        })
        // console.log("==> filter data",this.filterFaq)
        this.categoryKeys = Object.keys(this.filterFaq);
        this.categoryType = this.categoryKeys[0];
      }
      );
  }

  // showContent(tip) {
  //   if (!tip.isOpen) {
  //     this.closeAllTips();
  //   }
  //   tip.isOpen = !tip.isOpen;
  // }
}