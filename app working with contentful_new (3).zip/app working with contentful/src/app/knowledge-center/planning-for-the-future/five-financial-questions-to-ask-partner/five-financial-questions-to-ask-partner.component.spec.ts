import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiveFinancialQuestionsToAskPartnerComponent } from './five-financial-questions-to-ask-partner.component';

describe('FiveFinancialQuestionsToAskPartnerComponent', () => {
  let component: FiveFinancialQuestionsToAskPartnerComponent;
  let fixture: ComponentFixture<FiveFinancialQuestionsToAskPartnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiveFinancialQuestionsToAskPartnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiveFinancialQuestionsToAskPartnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
