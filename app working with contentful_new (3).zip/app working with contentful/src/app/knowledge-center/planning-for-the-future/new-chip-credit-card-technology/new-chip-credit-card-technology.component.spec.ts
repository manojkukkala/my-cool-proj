import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewChipCreditCardTechnologyComponent } from './new-chip-credit-card-technology.component';

describe('NewChipCreditCardTechnologyComponent', () => {
  let component: NewChipCreditCardTechnologyComponent;
  let fixture: ComponentFixture<NewChipCreditCardTechnologyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewChipCreditCardTechnologyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewChipCreditCardTechnologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
