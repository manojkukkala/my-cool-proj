import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialLiteracyForKidsComponent } from './financial-literacy-for-kids.component';

describe('FinancialLiteracyForKidsComponent', () => {
  let component: FinancialLiteracyForKidsComponent;
  let fixture: ComponentFixture<FinancialLiteracyForKidsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialLiteracyForKidsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialLiteracyForKidsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
