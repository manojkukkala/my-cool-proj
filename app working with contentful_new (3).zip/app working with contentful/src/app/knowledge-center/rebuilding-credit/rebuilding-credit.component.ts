import { Component, OnInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { JsonApiModel, JsonApiQueryData } from 'angular2-jsonapi';

@Component({
  selector: 'app-rebuilding-credit',
  templateUrl: './rebuilding-credit.component.html',
  styleUrls: ['./rebuilding-credit.component.css']
})
export class RebuildingCreditComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  //private pageId = "d303c81c-e139-4305-b331-65bc155fc441";

  private pageFilters = {
    titleFilter: {
      condition: {
        path: 'title',
        value: 'Temporary Place Holder Page'
      }
    }
  };
  
  mp: MarketingPageModel;

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.pageFilters,
    }
  }

  ngOnInit() {
    this.datastore.findAll(MarketingPageModel, this.queryParameters)
      .subscribe((marketingPage: JsonApiQueryData<MarketingPageModel>) => {
        this.mp = marketingPage.getModels[0];
        console.log(this.mp);
        // For temporary the loaded is false till the page is underconstruction.
        this.isLoaded = false;
      });
  }

}
