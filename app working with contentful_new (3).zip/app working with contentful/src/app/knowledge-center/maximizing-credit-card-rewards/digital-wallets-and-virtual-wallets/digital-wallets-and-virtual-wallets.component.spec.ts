import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalWalletsAndVirtualWalletsComponent } from './digital-wallets-and-virtual-wallets.component';

describe('DigitalWalletsAndVirtualWalletsComponent', () => {
  let component: DigitalWalletsAndVirtualWalletsComponent;
  let fixture: ComponentFixture<DigitalWalletsAndVirtualWalletsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalWalletsAndVirtualWalletsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalWalletsAndVirtualWalletsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
