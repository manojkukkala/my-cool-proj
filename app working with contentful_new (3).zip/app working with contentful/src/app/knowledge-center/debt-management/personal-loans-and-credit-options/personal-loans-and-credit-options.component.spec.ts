import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalLoansAndCreditOptionsComponent } from './personal-loans-and-credit-options.component';

describe('PersonalLoansAndCreditOptionsComponent', () => {
  let component: PersonalLoansAndCreditOptionsComponent;
  let fixture: ComponentFixture<PersonalLoansAndCreditOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalLoansAndCreditOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalLoansAndCreditOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
