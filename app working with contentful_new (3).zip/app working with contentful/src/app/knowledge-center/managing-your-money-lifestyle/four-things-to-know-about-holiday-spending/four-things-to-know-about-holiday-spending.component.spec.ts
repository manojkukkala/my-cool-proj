import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FourThingsToKnowAboutHolidaySpendingComponent } from './four-things-to-know-about-holiday-spending.component';

describe('FourThingsToKnowAboutHolidaySpendingComponent', () => {
  let component: FourThingsToKnowAboutHolidaySpendingComponent;
  let fixture: ComponentFixture<FourThingsToKnowAboutHolidaySpendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FourThingsToKnowAboutHolidaySpendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FourThingsToKnowAboutHolidaySpendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
