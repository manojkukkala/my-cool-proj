import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonMoneyMistakesToAvoidComponent } from './common-money-mistakes-to-avoid.component';

describe('CommonMoneyMistakesToAvoidComponent', () => {
  let component: CommonMoneyMistakesToAvoidComponent;
  let fixture: ComponentFixture<CommonMoneyMistakesToAvoidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonMoneyMistakesToAvoidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonMoneyMistakesToAvoidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
