import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CoreCommonModule } from 'angular-nexus-uiux';
import { CitiModule } from 'uicomponents/citi.module';

import { HomeRoutingModule } from './home-routing.module';
import { IndexComponent } from './index.component';
import { AmwModule } from 'angular-container-common/amw';
import { ShowcaseV1Component } from './showcase-v1/showcase-v1.component';
import { CardComponent } from './card/card.component';
import { CardComponentV2 } from "./card-v2/card-v2.component";
import { CitigoldPackageComponent } from './banking-products/citigold-package/citigold-package.component';
import { CitiPriorityComponent } from './banking-products/citi-priority/citi-priority.component';
import { BankingProductsComponent } from './banking-products/banking-products.component';
import { BankingHeroComponent } from './banking-products/banking-hero/banking-hero.component';
import { BankWithCitiComponent } from './banking-products/bank-with-citi/bank-with-citi.component';
import { ShowcaseV2Component } from './showcase-v2/showcase-v2.component';
import { ShowcaseV3Component } from './showcase-v3/showcase-v3.component';
import { GenericProductComponent} from './banking-products/generic-product/generic-product.component';

@NgModule({
	imports: [
		CoreCommonModule,
		CitiModule,
		AmwModule,
		HomeRoutingModule
	],
	declarations: [
		IndexComponent,
		ShowcaseV1Component,
		CardComponent,
		CardComponentV2,
		CitigoldPackageComponent,
		CitiPriorityComponent,
		BankingProductsComponent,
		BankingHeroComponent,
		BankWithCitiComponent,
		ShowcaseV2Component,
		ShowcaseV3Component,
		GenericProductComponent
	],
	providers: []
})
export class HomeModule {

}


