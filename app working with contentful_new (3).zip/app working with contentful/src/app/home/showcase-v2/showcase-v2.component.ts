import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showcase-v2',
  templateUrl: './showcase-v2.component.html',
  styleUrls: ['./showcase-v2.component.css']
})
export class ShowcaseV2Component implements OnInit {

  showcases = [
    { 
      "headerText": "Get More From Your Banking Relationship",
      "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_GetMoreRelationship.jpg",
      "subheaderText": "Buttery biscuits are better with our bountiful blueberry jam.",
      "headerIcon": "https://citi-ddl-ui.criticalmass.com/images/showcase-icon.svg",
      "footerLinkText": "Sign up for Citi Price Rewind",
      "footerLinkUrl": "https://www.citi.com",
      "rowData": [
        {
          "columnData": [
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }, 
            {
              "headerLinkText": "Cookie Monster Strikes Back",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
            }, 
            {
              "headerLinkText": "So Many Xenomorphs",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
            }
          ]
        }
      ]
    },
    { 
      "headerText": "Welcome to a New Way of Banking",
      "headerImg": "https://online.citi.com/JRS/banners/modules/Benefit-Hub-Redesign-M1.jpg",
      "rowData": [
        {
          "lineDivider": true,
          "columnData": [
            {
              "headerText": "Citi® Credit Cards",
              "descriptionText": "With a diverse range of benefits and rewards to choose from, Citi has a credit card to fit your unique needs.",
              "footerLinkText": "Visit Credit Cards",
              "footerLinkUrl": "https://www.citi.com/credit-cards"
            }, 
            {
              "headerText": "Citi® Savings",
              "descriptionText": "Put your nest egg in a linked Citi Savings Account to help meet your monthly minimum balance.",
              "footerLinkText": "Explore Citi Savings",
              "footerLinkUrl": "https://online.citi.com/US/banking/savings/citi.action?ID=citi-savings"
            }, 
            {
              "headerText": "Citi Personal Wealth Management",
              "descriptionText": "Waive annual fees on your Citi Personal Wealth Management investment accounts when you link them to your Citigold account.",
              "footerLinkText": "Invest with Citi Personal Wealth Management",
              "footerLinkUrl": "https://online.citi.com/JRS/pands/detail.do?ID=InvestingCiti"
            }
          ]
        },
        {
          "lineDivider": false,
          "columnData": [
            {
              "headerText": "Citi® Credit Cards",
              "descriptionText": "With a diverse range of benefits and rewards to choose from, Citi has a credit card to fit your unique needs.",
              "footerLinkText": "Visit Credit Cards",
              "footerLinkUrl": "https://www.citi.com/credit-cards"
            }, 
            {
              "headerText": "Citi® Savings",
              "descriptionText": "Put your nest egg in a linked Citi Savings Account to help meet your monthly minimum balance.",
              "footerLinkText": "Explore Citi Savings",
              "footerLinkUrl": "https://online.citi.com/US/banking/savings/citi.action?ID=citi-savings"
            }, 
            {
              "headerText": "Citi Personal Wealth Management",
              "descriptionText": "Waive annual fees on your Citi Personal Wealth Management investment accounts when you link them to your Citigold account.",
              "footerLinkText": "Invest with Citi Personal Wealth Management",
              "footerLinkUrl": "https://online.citi.com/JRS/pands/detail.do?ID=InvestingCiti"
            }
          ]
        }
      ]
    },
    { 
      "headerText": "Free Breakfast for New Account Holders",
      "headerImg": "https://online.citi.com/JRS/banners/modules/MobileApp_.jpg",
      "subheaderText": "Buttery biscuits are better with our bountiful blueberry jam.",
      "headerIcon": "https://citi-ddl-ui.criticalmass.com/images/calculator-linking-icon.svg",
      "footerLinkText": "Follow us on Instagram",
      "footerLinkUrl": "https://www.citi.com",
      "rowData": [
        {
          "columnData": [
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }, 
            {
              "headerLinkText": "Cookie Monster Strikes Back",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
            }, 
            {
              "headerLinkText": "So Many Xenomorphs",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
            }
          ]
        }, 
        {
          "columnData": [
            {
              "headerText": "Citi® Credit Cards",
              "descriptionText": "With a diverse range of benefits and rewards to choose from, Citi has a credit card to fit your unique needs.",
              "footerLinkText": "Visit Credit Cards",
              "footerLinkUrl": "https://www.citi.com/credit-cards"
            }, 
            {
              "headerText": "Citi® Savings",
              "descriptionText": "Put your nest egg in a linked Citi Savings Account to help meet your monthly minimum balance.",
              "footerLinkText": "Explore Citi Savings",
              "footerLinkUrl": "https://online.citi.com/US/banking/savings/citi.action?ID=citi-savings"
            }, 
            {
              "headerText": "Citi Personal Wealth Management",
              "descriptionText": "Waive annual fees on your Citi Personal Wealth Management investment accounts when you link them to your Citigold account.",
              "footerLinkText": "Invest with Citi Personal Wealth Management",
              "footerLinkUrl": "https://online.citi.com/JRS/pands/detail.do?ID=InvestingCiti"
            }
          ]
        }
      ]
    },
    { 
      "headerText": "Get More From Your Banking Relationship",
      "headerImg": "https://online.citi.com/JRS/banners/modules/HP370_M.jpg",
      "subheaderText": "Buttery biscuits are better with our bountiful blueberry jam.",
      "footerLinkText": "Sign up for Citi Price Rewind",
      "footerLinkUrl": "https://www.citi.com",
      "rowData": [
        {
          "columnData": [
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }, 
            {
              "headerLinkText": "So Many Xenomorphs",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
            }
          ]
        }, 
        {
          "columnData": [
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }, 
            {
              "headerLinkText": "Cookie Monster Strikes Back",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
            }, 
            {
              "headerLinkText": "So Many Xenomorphs",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
            }
          ]
        },
        {
          "columnData": [
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }, 
            {
              "headerLinkText": "Cookie Monster Strikes Back",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
            }, 
            {
              "headerLinkText": "So Many Xenomorphs",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
            },
            {
              "headerLinkText": "The New CitiFood Truck",
              "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
              "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
            }
          ]
        }
      ]
    }
  ]



  constructor() { }


  ngOnInit() {
  }

}
