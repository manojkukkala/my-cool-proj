'use strict';

let http = require('http');
let url = require('url');
let JSZip   = require('jszip');
let fs = require('graceful-fs-extra');
let path = require("path");
let rimraf = require('rimraf');
let jsonfile = require('jsonfile');
let Spinner = require('cli-spinner').Spinner;
let sem = require('semaphore')(1);

let command = {
    execute(){
        let isError = this.pre_execute();
        if(isError){
            return;
        }
		let isUpdateDepSuccessful = this.updateDependencyConfig();
		if(isUpdateDepSuccessful){
        this.readDependencyConfig();
		}
        
    },
    pre_execute(){
        if (!fs.existsSync('.ngcliproject')) {
        	console.log('ERROR: You must execute this command inside an Angular project');
        	return true;
    	}
        if (!fs.existsSync('package.ng.json')) {
        	console.log('ERROR: You must have a package.ng.json file in your project.');
        	return true;
    	} 
        return false; 
    },
	updateDependencyConfig(){
		
		        let ngPackageJson = require('./package.ng.json');
                let dependencyNamesArray = Object.keys(ngPackageJson.dependencies.list);
                this.updateSemaphoreCapacity(ngPackageJson);
				let actionParam = process.argv[2];
				 if(actionParam === 'update'){
			         		let packageParam = process.argv[3];
                            if(packageParam === undefined){
                               console.log("ERROR: Please specify the package name to update");
                               return false;
                            }
                            let depDetails =packageParam.substring(2).split('@');
                            console.log(depDetails[0]);
                            if(dependencyNamesArray.indexOf(depDetails[0]) === -1){
                               console.log("ERROR: Please specify a valid package name to update");
                               return false;
                            }
							if(depDetails[1] !== 'latest' &&  depDetails[1] !== undefined){
								 ngPackageJson.dependencies.list[depDetails[0]].version = depDetails[1];
								 fs.writeFileSync('package.ng.json',JSON.stringify(ngPackageJson));
								 return true;
							}else{
								// No update required. update to the version specified in package.ng.json
								return true;
							}

				 }else{
					 return true;
				 }


	},
    readDependencyConfig(){
        jsonfile.readFile('package.ng.json',(error,packageJson)=>{
                if(error){
                    console.log('ERROR: Error occured while reading the dependency config file.');
                    return;
                }
                let ngPackageJson = packageJson;
                let dependencyNamesArray = Object.keys(ngPackageJson.dependencies.list);
                this.updateSemaphoreCapacity(ngPackageJson);
                let actionParam = process.argv[2];
                switch(actionParam){
                        case 'install':{
                            this.installDependencies(ngPackageJson,dependencyNamesArray);
                            break;
                        }
                        case 'update' :{
                            let packageParam = process.argv[3];
                            if(packageParam === undefined){
                               console.log("ERROR: Please specify the package name to update");
                               return;
                            }
                            let depDetails =packageParam.substring(2).split('@');
                            console.log(depDetails[0]);
                            if(dependencyNamesArray.indexOf(depDetails[0]) === -1){
                               console.log("ERROR: Please specify a valid package name to update");
                               return;
                            }
                            if(depDetails[1] === 'latest' || depDetails[1] === undefined){
                                console.log('updating latest version');
                                let depObj = ngPackageJson.dependencies.list[depDetails[0]];
                                this.installDependency(depDetails[0],depObj.version,depObj.repositoryUrl);
                                return;
                            }else{
                               let depObj = ngPackageJson.dependencies.list[depDetails[0]]; 
                               this.installDependency(depDetails[0],depDetails[1],depObj.repositoryUrl);
                               return;
                            }
                    }
             }
        });
    },
    updateSemaphoreCapacity(ngPackageJson){
            if (ngPackageJson.dependencies.options && ngPackageJson.dependencies.options.maxOpenFiles && typeof ngPackageJson.dependencies.options.maxOpenFiles === "number"){
				sem.capacity = ngPackageJson.dependencies.options.maxOpenFiles; 
			}else{
                sem.capacity = 50;
            }
    },
    installDependency(dependencyName,version, repositoryUrl){
        console.log('installing '+ dependencyName +' with '+version+' version. from '+repositoryUrl );
        if (fs.existsSync('./node_modules/' + dependencyName)) {
			console.log('Deleting existing node_modules/' + dependencyName + ' ...');
			rimraf.sync('./node_modules/' + dependencyName);
		}
		    console.log('Proceed to install ' + dependencyName);
        let zipFileNameExp = repositoryUrl.split('/')[repositoryUrl.split('/').length - 1];
		if (!version){
			console.log('ERROR: You must specify a version for ' + dependencyName);
        	return;
		}
		let nameRegex = new RegExp('{name}', 'g');
		let versionRegex = new RegExp('{version}', 'g');

		let zipFileName = zipFileNameExp.replace(nameRegex, dependencyName).replace(versionRegex, version);
		let zipUrl = repositoryUrl.replace(nameRegex, dependencyName).replace(versionRegex, version);

		if (fs.existsSync(zipFileName)) {
			console.log('Deleting existing ' + zipFileName + ' ...');
			fs.unlinkSync(zipFileName);
		}
		//Download module and unzip
		this.downloadDependency(dependencyName, zipFileName, zipUrl);

    },
    downloadDependencyConfig(){

    },
    installDependencies(ngPackageJson,dependencyNamesArray){
            for( let depName of dependencyNamesArray){
                  this.installDependency(depName,ngPackageJson.dependencies.list[depName].version,ngPackageJson.dependencies.list[depName].repositoryUrl);   
            }
    },
    updateDependency(depName,depVersion){
            
    },
    downloadDependency(dependencyName, zipFileName, zipUrl) {
		var self = this;
		var request = http.get(url.parse(zipUrl), function(response) {		

			if (response.statusCode !== 200) {
				console.log("ERROR: status code " + response.statusCode);
				return;
			}
			if (response.headers["content-type"] !== "application/zip"){
				console.log('ERROR: The URL provided is not a zip file. The content-type is: ' + response.headers["content-type"]);
				fs.unlinkSync(zipFileName);
				return;
			}
			var data = [], dataLen = 0;

			var spinner = new Spinner('Downloading ' + zipUrl + '... %s');
			spinner.setSpinnerString('|/-\\');
			spinner.start();

			response.on('data', function(chunk){
				data.push(chunk);
    			dataLen += chunk.length;
			});

			response.on('end', function() {
				spinner.stop();
				console.log("");
				
  				console.log("Download completed");
  				//Unzip module
				var buf = Buffer.concat(data);

				JSZip.loadAsync(buf).then(function (zip) {
					try {
						zip.forEach(function (relativePath, file){
	    					self.writeFile(relativePath, file);
				  		});
					} catch(e){
						console.log(`ERROR: ${e.message}`);
					}
				});						    		
			});		    	
		}).on('error', (e) => {
  			console.log(`ERROR: ${e.message}`);
		});	
	},
    writeFile(relativePath, file){
		var self = this;
		sem.take(function() {
				var filepath = path.join("./node_modules", relativePath);
				filepath.split(path.sep).forEach((dir, index, splits) => {
					const parent = splits.slice(0, index).join(path.sep);
					const dirPath = path.resolve(parent, dir);
					if (!file.dir && (splits.length - 1 === index)){
						//This means is the file name
						fs.writeFileSync(filepath);
						file.nodeStream().pipe(fs.createWriteStream(filepath)).on('finish', function () {
							if (self.verbose){
								console.log('File: "' + filepath + '" created.');
							}
							sem.leave();
						});		
					} else {
						if (!fs.existsSync(dirPath)) {
							fs.mkdirSync(dirPath);
							if (self.verbose){
								console.log('Directory: "' + filepath + '" created.');	
							}
						}	
					}
				});
				if (file.dir){
					sem.leave();
				}
		})
	}

}
module.exports = command;