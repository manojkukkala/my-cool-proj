import { Component, OnInit } from '@angular/core';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { WindowRef } from 'uicomponents/utility/services/window-ref.service';
import { SessionService, SessionTimeoutHandler, RenewSessionHandler, AppConfigService, StorageService } from 'angular-nexus-uiux/services';
import { Http } from '@angular/http';

@Component({
	selector: 'cbol-core',
	templateUrl: './cbol-core.component.html',
	styleUrls: ['./cbol-core.component.css']
})
export class CbolCoreComponent implements OnInit {

	window: any;
	constructor(private _sessionService: SessionService,
		private _appConfigService: AppConfigService,
		private _http: Http,
		private _storageService: StorageService,
		private _window: WindowRef) {
		this.window = _window.nativeWindow;
	}

	ngOnInit() {

		const defaultHeaders: any = this._appConfigService.getHttpServiceConfig().defaultHeaders;
		defaultHeaders['devicePrint'] = (window as any).encode_deviceprint();
		defaultHeaders['deviceTokenCookie'] = this._storageService.get('RSA', StorageService.COOKIE);
		if (typeof this.window.ioGetBlackbox === 'function') {
			defaultHeaders['blackbox'] = this.window.ioGetBlackbox().blackbox;
		} else {
			const intervalId = setInterval(() => {
				if (typeof this.window.ioGetBlackbox === 'function') {
					defaultHeaders['blackbox'] = this.window.ioGetBlackbox().blackbox;
					clearInterval(intervalId);
				}
			}, 50);
		}

	}


}
