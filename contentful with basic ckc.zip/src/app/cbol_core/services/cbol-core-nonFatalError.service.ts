import { Injectable } from '@angular/core';
import { HttpService, StorageService } from 'angular-nexus-uiux/services';
import { AppConfigService, ContentService } from 'angular-nexus-uiux/services';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class NonFatalErrorService {
		errorCustomConfig: any = this.appConfigService.getConfig('nonFatalErrorConfig');
	errorCategory: any;

	constructor(private httpService: HttpService,
		private appConfigService: AppConfigService,
		private _cs: ContentService,
		private _storageService: StorageService,
	) { }



	getErrorMessageData(errorCategory): Observable<any> {
		let language = this._storageService.get('locale');
		if (language == null || language === '') {
			language = 'en_US';
		}
		this.appConfigService.setLocale(language);
		this._storageService.delete('isLegacyError');
		return this._cs.getStaticBundle('USCBOL');

	}
}
