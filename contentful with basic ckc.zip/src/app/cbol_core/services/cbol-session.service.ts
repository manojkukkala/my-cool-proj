/**
 * @module CoreServicesModule
 **/
/** SessionService **/

import { Injectable, EventEmitter } from '@angular/core';
import { Response } from '@angular/http';
import { Observable, Observer, Subscription } from 'rxjs/Rx';
import { AppConfigService, HttpService, StorageService } from 'angular-nexus-uiux/services';
import { Router, NavigationEnd } from '@angular/router';
import { CbolCoreConfigService } from './cbol-core-config.service';

export type SessionTimeoutHandler = () => void;
export type RenewSessionHandler = () => void;

/**
* @class CbolSessionService
* @constructor
**/
@Injectable()
export class CbolSessionService {

	private _keepAliveIntervalHandler: () => void;
	private _customTimeoutHandler: SessionTimeoutHandler;
	private _customRenewSessionHandler: RenewSessionHandler;

	private _keepAliveIntervalObservable: Observable<any>;
	private _keepAliveIntervalObserver: Observer<any>;
	private _keepAliveIntervalSubscription: Subscription;

	private _sessionTimeoutObservable: Observable<any>;
	private _sessionTimeoutObserver: Observer<any>;
	private _sessionTimeoutSubscription: Subscription;
	private _routerChangeSubscription: Subscription;

	public sessionEmitter = new EventEmitter<any>();
	private activityFlag = false;
	private disableActivityCheck = false;
	private isTimerInit = false;

	constructor(private _appConfigService: AppConfigService,
		private _httpService: HttpService,
		private _storageService: StorageService,
		private _router: Router,
		private configSevice: CbolCoreConfigService) { };

	/**
		 * The start method is used to start the session timer. It recevies a SessionTimeoutHandler.
		 * When the session timeout occurs, it will execute the handleSessionTimeout method of SessionTimeoutHandler object.
		 *
		 * @method start
		 * @public
		 * @param customTimeoutHandler {SessionTimeoutHandler} When the session timeout occurs,
		 * the handleSessionTimouet method of this object is called.
		 * @returns {void}
	*/
	public start(customTimeoutHandler: SessionTimeoutHandler, customRenewSessionHandler?: RenewSessionHandler): void {

		if (this._sessionTimeoutSubscription) {
			this._sessionTimeoutSubscription.unsubscribe();
		}

		this._customTimeoutHandler = customTimeoutHandler;
		this._customRenewSessionHandler = customRenewSessionHandler;
		this._sessionTimeoutObservable = Observable.timer((this._appConfigService.getSessionServiceConfig().sessionTimeout - 120) * 1000, 1000);

		const keepAliveInterval = this._appConfigService.getSessionServiceConfig().keepAliveInterval * 1000;
		this._keepAliveIntervalObservable = Observable.timer(keepAliveInterval, keepAliveInterval);

		const self = this;
		this.activityFlag = false;
		this.disableActivityCheck = false;
		this.isTimerInit = true;

		this._keepAliveIntervalHandler = () => {
			console.log('self.activityFlag ', self.activityFlag);
			if (self.activityFlag === true) {
				self.activityFlag = false;
				self.renew();
			}
		}

		this._keepAliveIntervalObserver = {
			next: (x) => {
				self._keepAliveIntervalHandler();
			},
			error: (err) => {
				console.log('KeepAliveIntervalObserver Err: %s', err);
			},
			complete: () => {
			}
		};


		this._sessionTimeoutObserver = {
			next: (x) => {
				if (x === 0 && this.configSevice.config['fallbacks'] &&
					this.configSevice.config['fallbacks']['sessionTimeOut'] === true) {
					this.sessionEmitter.emit('showOverLay');
				}
				this.sessionEmitter.emit(x);
			},
			error: (err) => {
				console.log('SessionTimeoutObserver Err: %s', err);
			},
			complete: () => {
				// self._routerChangeSubscription.unsubscribe();
				console.log('sessionTimeoutObserver complete');
			}
		};

		this._sessionTimeoutSubscription = this._sessionTimeoutObservable.subscribe(this._sessionTimeoutObserver);
		this._keepAliveIntervalSubscription = this._keepAliveIntervalObservable.subscribe(this._keepAliveIntervalObserver);
	}

	public executeTImeout(): void {
		this._customTimeoutHandler();
	}

	public toggleActivityCheck(disabled: boolean): void {
		this.disableActivityCheck = disabled;
	}

	public isTimerInitialized(): boolean {
		return this.isTimerInit;
	}

	public clickHandler(active: boolean): void {
		if (this.disableActivityCheck === false) {
			console.log('click detected!');
			this.activityFlag = true;
		}
	}

	public resetSession() {
		this.isTimerInit = false;
		this.activityFlag = false;
		this.disableActivityCheck = false;
		this._sessionTimeoutSubscription.unsubscribe();
		this._keepAliveIntervalSubscription.unsubscribe();
	}

	/**
		 * The renew method sends a keep alive request to the url specified
		 * in the sessionKeepAliveUrl property of the SessionServiceConfig object in the Application Config.
		 * After the keep alive request is sent, it will also restart the session timeout timer.
		 * @method start
		 * @public
		 * @param customTimeoutHandler {SessionTimeoutHandler} When the session timeout occurs,
		 *  the handleSessionTimouet method of this object is called.
		 * @returns {void}
	*/
	public renew(): void {

		let httpRequestFunction = this._httpService.post.bind(this._httpService);
		if (this._appConfigService.getSessionServiceConfig().sessionKeepAliveMethod) {
			if (this._appConfigService.getSessionServiceConfig().sessionKeepAliveMethod === 'GET') {
				httpRequestFunction = this._httpService.get.bind(this._httpService);
			} else if (this._appConfigService.getSessionServiceConfig().sessionKeepAliveMethod === 'PUT') {
				httpRequestFunction = this._httpService.put.bind(this._httpService);
			}
		}
		httpRequestFunction(this._appConfigService.getSessionServiceConfig().sessionKeepAliveUrl).catch((error: Response | any) => {
			// TODO
		}).subscribe((response: Response) => {
			console.log('Reset timer');
			this._sessionTimeoutSubscription.unsubscribe();
			this._keepAliveIntervalSubscription.unsubscribe();
			console.log('Subscribe Again');
			this._sessionTimeoutSubscription = this._sessionTimeoutObservable.subscribe(this._sessionTimeoutObserver);
			this._keepAliveIntervalSubscription = this._keepAliveIntervalObservable.subscribe(this._keepAliveIntervalObserver);
		});

		if (this._customRenewSessionHandler) {
			this._customRenewSessionHandler();
		}
	}

	private isPresentSessionTokens() {
		const cookieName: string = this._appConfigService.getSessionCookieInformation().cookieName;
		const valueSeparator: string = this._appConfigService.getSessionCookieInformation().valueSeparator;
		const arrValues: string[] = this._storageService.getArray(cookieName, valueSeparator, StorageService.COOKIE);
		return (arrValues && arrValues.length > 2);
	}

	private isPresentFriendKey() {
		const isFriendKey: string = this._appConfigService.getSessionCookieInformation().isFriendKey;
		const isFriend: string = this._storageService.get(isFriendKey);
		return (isFriend !== null && isFriend !== 'false');
	}

	/**
			 * The isVisitor method returns true if the cookie for the session
			 *  does not exist or it exists but it does not contain the session tokens.
			 * @method isVisitor
			 * @public
			 * @returns {boolean}
		*/
	public isVisitor(): boolean {
		return !this.isPresentSessionTokens();
	}


	/**
		* The isCustomer method returns true if all the OUath token is present for the customer.
		* If OuathToken is not present then it would return false.
		* @method isCustomer
		* @public
		* @returns {boolean}
 */
	public isCustomer(): boolean {
		return this.isPresentSessionTokens() && !this.isPresentFriendKey();
	}

	/**
		* The isFriend method returns true if all the OUath token is present and also if the key for isFriend is available in storage
		* @method isFriend
		* @public
		* @returns {boolean}
 */
	public isFriend(): boolean {
		return this.isPresentSessionTokens() && this.isPresentFriendKey();
	}

	/**
			* The setFriendKey method inserts the friend key in the storage.
			* @method setFriendKey
			* @param isFriend {boolean} If true it inserts the friend key, if false it deletes the friend key.
			* @public
			* @returns {boolean}
	 */
	public setFriendKey(isFriend: boolean): void {
		const isFriendKey: string = this._appConfigService.getSessionCookieInformation().isFriendKey;
		if (isFriend) {
			this._storageService.set(isFriendKey, 'true');
		} else {
			this._storageService.delete(isFriendKey);
		}
	}

	getSessionEmitter(): EventEmitter<any> {
		return this.sessionEmitter;
	}

}


