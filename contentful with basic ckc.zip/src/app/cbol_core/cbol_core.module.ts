import { NgModule, APP_INITIALIZER } from '@angular/core';

import { CoreServicesModule, CoreCommonModule, CoreRoutingModule } from 'angular-nexus-uiux';
import { AppConfigService } from 'angular-nexus-uiux/services';
import { CitiServicesModule } from 'uicomponents/citi-services.module';
import { CitiModule } from 'uicomponents/citi.module';
import { environment } from '../../environments/environment';
import { CbolCoreComponent } from './component/cbol-core.component';
import { UnauthorizedComponent } from './component/unauthorized.component';
import { CbolCoreRoutingModule } from './cbol_core-routing.module';
import { MfaModule } from 'angular-nexus-uiux/mfa';
import { MfaUiModule } from 'angular-container-common/mfa-ui/mfa-ui.module';
import { WindowRef } from 'uicomponents/utility/services/window-ref.service';
import { HttpModule } from '@angular/http';
import { CbolSessionComponent } from './component/cbol-session.component';
import { CbolCoreContentService } from './services/cbol-core-content.service';
import { CbolSessionService } from './services/cbol-session.service';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { NonFatalErrorComponent } from './component/cbol-core-nonFatalError.component';
import { NonFatalErrorRedirectService } from '../cbol_core/services/nonFatalErrorRedirect.service';
import { CbolCoreConfigService } from './services/cbol-core-config.service';

export function configServiceFactory(configService: CbolCoreConfigService): Function {
	return () => configService.load();
}

@NgModule({
	imports: [
		CoreServicesModule,
		CoreCommonModule,
		CitiServicesModule,
		CitiModule,
		MfaModule,
		MfaUiModule,
		HttpModule,
		CbolCoreRoutingModule,
		CoreRoutingModule
	],
	declarations: [CbolCoreComponent, UnauthorizedComponent, CbolSessionComponent, NonFatalErrorComponent],
	exports: [CbolCoreComponent, UnauthorizedComponent, NonFatalErrorComponent],
	providers: [
		WindowRef,
		CbolCoreContentService,
		CbolSessionService,
		NonFatalErrorRedirectService,
		CbolCoreConfigService,
		{
			// Provider for APP_INITIALIZER
			provide: APP_INITIALIZER,
			useFactory: configServiceFactory,
			deps: [CbolCoreConfigService],
			multi: true
		}
	]
})
export class CbolCoreModule {

	constructor(public appConfigService: AppConfigService) {
		const locale = Cookie.get('locale');
		if (locale) {
			environment.locale = locale;
		}
		appConfigService.setAppConfig(environment);
	}

}
