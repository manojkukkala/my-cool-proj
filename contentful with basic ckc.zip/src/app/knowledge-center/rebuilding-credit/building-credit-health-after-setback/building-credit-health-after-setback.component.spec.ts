import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingCreditHealthAfterSetbackComponent } from './building-credit-health-after-setback.component';

describe('BuildingCreditHealthAfterSetbackComponent', () => {
  let component: BuildingCreditHealthAfterSetbackComponent;
  let fixture: ComponentFixture<BuildingCreditHealthAfterSetbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildingCreditHealthAfterSetbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildingCreditHealthAfterSetbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
