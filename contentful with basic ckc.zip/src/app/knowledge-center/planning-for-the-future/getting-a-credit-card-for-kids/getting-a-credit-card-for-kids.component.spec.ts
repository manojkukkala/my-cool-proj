import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GettingACreditCardForKidsComponent } from './getting-a-credit-card-for-kids.component';

describe('GettingACreditCardForKidsComponent', () => {
  let component: GettingACreditCardForKidsComponent;
  let fixture: ComponentFixture<GettingACreditCardForKidsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GettingACreditCardForKidsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GettingACreditCardForKidsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
