import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanningForTheFutureComponent } from './planning-for-the-future.component';

describe('PlanningForTheFutureComponent', () => {
  let component: PlanningForTheFutureComponent;
  let fixture: ComponentFixture<PlanningForTheFutureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanningForTheFutureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanningForTheFutureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
