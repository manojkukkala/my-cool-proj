import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreCommonModule } from 'angular-nexus-uiux';
import { CitiModule } from 'uicomponents/citi.module';
import { AmwModule } from 'angular-container-common/amw';

import { UIComponentsWithContentModule } from '../uicomponents-with-content/uicomponents-with-content.module';
import { KnowledgeCenterRoutingModule } from "./knowledge-center-routing.module";
import { KnowledgeCenterComponent } from "./knowledge-center.component";
import { HowToBuildCreditComponent } from './how-to-build-credit/how-to-build-credit.component';
import { MaximizingCreditCardRewardsComponent } from './maximizing-credit-card-rewards/maximizing-credit-card-rewards.component';
import { ManagingYourMoneyLifestyleComponent } from './managing-your-money-lifestyle/managing-your-money-lifestyle.component';
import { DebtManagementComponent } from './debt-management/debt-management.component';
import { RebuildingCreditComponent } from './rebuilding-credit/rebuilding-credit.component';
import { PlanningForTheFutureComponent } from './planning-for-the-future/planning-for-the-future.component';
import { BuildCreditWithASecuredCreditCardComponent } from './how-to-build-credit/build-credit-with-a-secured-credit-card/build-credit-with-a-secured-credit-card.component';
import { BestTimeToBookAwardTravelComponent } from './maximizing-credit-card-rewards/best-time-to-book-award-travel/best-time-to-book-award-travel.component';
import { NineWaysToSaveMoneyOnHolidayShoppingComponent } from './managing-your-money-lifestyle/nine-ways-to-save-money-on-holiday-shopping/nine-ways-to-save-money-on-holiday-shopping.component';
import { CreditCardFactsComponent } from './rebuilding-credit/credit-card-facts/credit-card-facts.component';
import { HowToGetOutOfDebtSuccessStoryComponent } from './debt-management/how-to-get-out-of-debt-success-story/how-to-get-out-of-debt-success-story.component';
import { GettingACreditCardForKidsComponent } from './planning-for-the-future/getting-a-credit-card-for-kids/getting-a-credit-card-for-kids.component';
import { CommonCreditCardTermsDecodedComponent } from './how-to-build-credit/common-credit-card-terms-decoded/common-credit-card-terms-decoded.component';
import { SecuredVsUnsecuredCreditCardsComponent } from './how-to-build-credit/secured-vs-unsecured-credit-cards/secured-vs-unsecured-credit-cards.component';
import { CreditCardFaqsAndTipsComponent } from './how-to-build-credit/credit-card-faqs-and-tips/credit-card-faqs-and-tips.component';
import { FiveQuestionsToAskBeforeGettingFirstCreditCardComponent } from './how-to-build-credit/five-questions-to-ask-before-getting-first-credit-card/five-questions-to-ask-before-getting-first-credit-card.component';
import { HowToOvercomeCreditCardFearComponent } from './how-to-build-credit/how-to-overcome-credit-card-fear/how-to-overcome-credit-card-fear.component';
import { CreditCardTermsComponent } from './how-to-build-credit/credit-card-terms/credit-card-terms.component';
import { SmartCreditCardTipsComponent } from './how-to-build-credit/smart-credit-card-tips/smart-credit-card-tips.component';
import { BuildCreditNewResidentsComponent } from './how-to-build-credit/build-credit-new-residents/build-credit-new-residents.component';
import { BuildingCreditAfterCollegeComponent } from './how-to-build-credit/building-credit-after-college/building-credit-after-college.component';
import { InsideACreditReportComponent } from './how-to-build-credit/inside-a-credit-report/inside-a-credit-report.component';
import { HowToCheckACreditReportComponent } from './how-to-build-credit/how-to-check-a-credit-report/how-to-check-a-credit-report.component';
import { HowToHelpBuildCreditComponent } from './how-to-build-credit/how-to-help-build-credit/how-to-help-build-credit.component';
import { FiveTipsToReduceHolidayStressComponent } from './maximizing-credit-card-rewards/five-tips-to-reduce-holiday-stress/five-tips-to-reduce-holiday-stress.component';
import { UsingYourCreditCardAbroadComponent } from './maximizing-credit-card-rewards/using-your-credit-card-abroad/using-your-credit-card-abroad.component';
import { CashBackVsTraveRewardsCreditCardsComponent } from './maximizing-credit-card-rewards/cash-back-vs-trave-rewards-credit-cards/cash-back-vs-trave-rewards-credit-cards.component';
import { TravelHacksComponent } from './maximizing-credit-card-rewards/travel-hacks/travel-hacks.component';
import { ThePointsGuyCreditCardTipsComponent } from './maximizing-credit-card-rewards/the-points-guy-credit-card-tips/the-points-guy-credit-card-tips.component';
import { WhatToKnowAboutCashBackCreditCardsComponent } from './maximizing-credit-card-rewards/what-to-know-about-cash-back-credit-cards/what-to-know-about-cash-back-credit-cards.component';
import { UsingCreditCardRewardsForTravelComponent } from './maximizing-credit-card-rewards/using-credit-card-rewards-for-travel/using-credit-card-rewards-for-travel.component';
import { DigitalWalletsAndVirtualWalletsComponent } from './maximizing-credit-card-rewards/digital-wallets-and-virtual-wallets/digital-wallets-and-virtual-wallets.component';
import { TravelCreditCardComponent } from './maximizing-credit-card-rewards/travel-credit-card/travel-credit-card.component';
import { TravelingTheWorldComponent } from './maximizing-credit-card-rewards/traveling-the-world/traveling-the-world.component';
import { TravelRewardsComponent } from './maximizing-credit-card-rewards/travel-rewards/travel-rewards.component';
import { FourTravelTipsCardsOverseasComponent } from './maximizing-credit-card-rewards/four-travel-tips-cards-overseas/four-travel-tips-cards-overseas.component';
import { HowDoCashBackCardsWorkComponent } from './maximizing-credit-card-rewards/how-do-cash-back-cards-work/how-do-cash-back-cards-work.component';
import { AirlineCreditCardsComponent } from './maximizing-credit-card-rewards/airline-credit-cards/airline-credit-cards.component';
import { HowToUseACreditCardComponent } from './maximizing-credit-card-rewards/how-to-use-a-credit-card/how-to-use-a-credit-card.component';
import { CanCashBackOrRewardsCreditCardHelpSaveComponent } from './maximizing-credit-card-rewards/can-cash-back-or-rewards-credit-card-help-save/can-cash-back-or-rewards-credit-card-help-save.component';
import { HowToSaveMoneyBlackFridayCyberMondayComponent } from './managing-your-money-lifestyle/how-to-save-money-black-friday-cyber-monday/how-to-save-money-black-friday-cyber-monday.component';
import { MovingBudgetChecklistComponent } from './managing-your-money-lifestyle/moving-budget-checklist/moving-budget-checklist.component';
import { FourThingsToKnowAboutHolidaySpendingComponent } from './managing-your-money-lifestyle/four-things-to-know-about-holiday-spending/four-things-to-know-about-holiday-spending.component';
import { WaysToSaveMoneyHolidayShoppingComponent } from './managing-your-money-lifestyle/ways-to-save-money-holiday-shopping/ways-to-save-money-holiday-shopping.component';
import { CollegeCostsAndExpensesComponent } from './managing-your-money-lifestyle/college-costs-and-expenses/college-costs-and-expenses.component';
import { CommonMoneyMistakesToAvoidComponent } from './managing-your-money-lifestyle/common-money-mistakes-to-avoid/common-money-mistakes-to-avoid.component';
import { BudgetingTipsCutCollegeCostsComponent } from './managing-your-money-lifestyle/budgeting-tips-cut-college-costs/budgeting-tips-cut-college-costs.component';
import { GetTheMostFromYourCreditCardComponent } from './managing-your-money-lifestyle/get-the-most-from-your-credit-card/get-the-most-from-your-credit-card.component';
import { MoneyManagementLessonsComponent } from './managing-your-money-lifestyle/money-management-lessons/money-management-lessons.component';
import { EstablishingCreditAndBuildingCreditHealthComponent } from './managing-your-money-lifestyle/establishing-credit-and-building-credit-health/establishing-credit-and-building-credit-health.component';
import { RewardsCreditCardsForHolidayShoppingComponent } from './managing-your-money-lifestyle/rewards-credit-cards-for-holiday-shopping/rewards-credit-cards-for-holiday-shopping.component';
import { SixThingsToKnowAboutAprComponent } from './debt-management/six-things-to-know-about-apr/six-things-to-know-about-apr.component';
import { HowToGetOutOfCreditCardDebtComponent } from './debt-management/how-to-get-out-of-credit-card-debt/how-to-get-out-of-credit-card-debt.component';
import { HowToPayOffDebtWithDebtAvalancheComponent } from './debt-management/how-to-pay-off-debt-with-debt-avalanche/how-to-pay-off-debt-with-debt-avalanche.component';
import { DebtSnowballComponent } from './debt-management/debt-snowball/debt-snowball.component';
import { FiftyThirtyTwentyBudgetPlannerComponent } from './debt-management/fifty-thirty-twenty-budget-planner/fifty-thirty-twenty-budget-planner.component';
import { SharedCreditCardsProsAndConsComponent } from './debt-management/shared-credit-cards-pros-and-cons/shared-credit-cards-pros-and-cons.component';
import { ConsolidatingCreditCardDebtComponent } from './debt-management/consolidating-credit-card-debt/consolidating-credit-card-debt.component';
import { HowToPayOffCreditCardDebtComponent } from './debt-management/how-to-pay-off-credit-card-debt/how-to-pay-off-credit-card-debt.component';
import { BestWaysToPayOffDebtComponent } from './debt-management/best-ways-to-pay-off-debt/best-ways-to-pay-off-debt.component';
import { FourWaysTowardsFinancialGoalsComponent } from './debt-management/four-ways-towards-financial-goals/four-ways-towards-financial-goals.component';
import { WaysToPayOffCreditCardComponent } from './debt-management/ways-to-pay-off-credit-card/ways-to-pay-off-credit-card.component';
import { PersonalLoansAndCreditOptionsComponent } from './debt-management/personal-loans-and-credit-options/personal-loans-and-credit-options.component';
import { BalanceTransferComponent } from './debt-management/balance-transfer/balance-transfer.component';
import { BuildingCreditHealthAfterSetbackComponent } from './rebuilding-credit/building-credit-health-after-setback/building-credit-health-after-setback.component';
import { ImproveCreditHealthComponent } from './rebuilding-credit/improve-credit-health/improve-credit-health.component';
import { ImproveCreditHistoryComponent } from './rebuilding-credit/improve-credit-history/improve-credit-history.component';
import { HowToPayOffDebtComponent } from './rebuilding-credit/how-to-pay-off-debt/how-to-pay-off-debt.component';
import { EmploymentCreditCheckComponent } from './planning-for-the-future/employment-credit-check/employment-credit-check.component';
import { NewChipCreditCardTechnologyComponent } from './planning-for-the-future/new-chip-credit-card-technology/new-chip-credit-card-technology.component';
import { ShareRentLeaseOrBuyACarOptionsComponent } from './planning-for-the-future/share-rent-lease-or-buy-a-car-options/share-rent-lease-or-buy-a-car-options.component';
import { FiveFinancialQuestionsToAskPartnerComponent } from './planning-for-the-future/five-financial-questions-to-ask-partner/five-financial-questions-to-ask-partner.component';
import { FinancialLiteracyForKidsComponent } from './planning-for-the-future/financial-literacy-for-kids/financial-literacy-for-kids.component';
import { WhenShouldIGetACreditCardComponent } from './planning-for-the-future/when-should-i-get-a-credit-card/when-should-i-get-a-credit-card.component';
import { HowDoesDivorceAffectYourCreditComponent } from './planning-for-the-future/how-does-divorce-affect-your-credit/how-does-divorce-affect-your-credit.component';
import { ShouldIGetABusinessCreditCardComponent } from './planning-for-the-future/should-i-get-a-business-credit-card/should-i-get-a-business-credit-card.component';
import { FinancialTipsToGetAheadComponent } from './planning-for-the-future/financial-tips-to-get-ahead/financial-tips-to-get-ahead.component';
import { HowToPayForWeddingSeasonComponent } from './planning-for-the-future/how-to-pay-for-wedding-season/how-to-pay-for-wedding-season.component';
import { MarriageAndFinancesAnswersToCommonQuestionsComponent } from './planning-for-the-future/marriage-and-finances-answers-to-common-questions/marriage-and-finances-answers-to-common-questions.component';
import { SevenStepsToFinancialHealthComponent } from './planning-for-the-future/seven-steps-to-financial-health/seven-steps-to-financial-health.component';


@NgModule({
  imports: [
		CoreCommonModule,
		CitiModule,
		AmwModule,
    KnowledgeCenterRoutingModule,
    UIComponentsWithContentModule
  ],
  declarations: [KnowledgeCenterComponent, HowToBuildCreditComponent, MaximizingCreditCardRewardsComponent, ManagingYourMoneyLifestyleComponent, DebtManagementComponent, RebuildingCreditComponent, PlanningForTheFutureComponent, BuildCreditWithASecuredCreditCardComponent, BestTimeToBookAwardTravelComponent, NineWaysToSaveMoneyOnHolidayShoppingComponent, HowToGetOutOfDebtSuccessStoryComponent, CreditCardFactsComponent, GettingACreditCardForKidsComponent, CommonCreditCardTermsDecodedComponent, SecuredVsUnsecuredCreditCardsComponent, CreditCardFaqsAndTipsComponent, FiveQuestionsToAskBeforeGettingFirstCreditCardComponent, HowToOvercomeCreditCardFearComponent, CreditCardTermsComponent, SmartCreditCardTipsComponent, BuildCreditNewResidentsComponent, BuildingCreditAfterCollegeComponent, InsideACreditReportComponent, HowToCheckACreditReportComponent, HowToHelpBuildCreditComponent, FiveTipsToReduceHolidayStressComponent, UsingYourCreditCardAbroadComponent, CashBackVsTraveRewardsCreditCardsComponent, TravelHacksComponent, ThePointsGuyCreditCardTipsComponent, WhatToKnowAboutCashBackCreditCardsComponent, UsingCreditCardRewardsForTravelComponent, DigitalWalletsAndVirtualWalletsComponent, TravelCreditCardComponent, TravelingTheWorldComponent, TravelRewardsComponent, FourTravelTipsCardsOverseasComponent, HowDoCashBackCardsWorkComponent, AirlineCreditCardsComponent, HowToUseACreditCardComponent, CanCashBackOrRewardsCreditCardHelpSaveComponent, HowToSaveMoneyBlackFridayCyberMondayComponent, MovingBudgetChecklistComponent, FourThingsToKnowAboutHolidaySpendingComponent, WaysToSaveMoneyHolidayShoppingComponent, CollegeCostsAndExpensesComponent, CommonMoneyMistakesToAvoidComponent, BudgetingTipsCutCollegeCostsComponent, GetTheMostFromYourCreditCardComponent, MoneyManagementLessonsComponent, EstablishingCreditAndBuildingCreditHealthComponent, RewardsCreditCardsForHolidayShoppingComponent, SixThingsToKnowAboutAprComponent, HowToGetOutOfCreditCardDebtComponent, HowToPayOffDebtWithDebtAvalancheComponent, DebtSnowballComponent, FiftyThirtyTwentyBudgetPlannerComponent, SharedCreditCardsProsAndConsComponent, ConsolidatingCreditCardDebtComponent, HowToPayOffCreditCardDebtComponent, BestWaysToPayOffDebtComponent, FourWaysTowardsFinancialGoalsComponent, WaysToPayOffCreditCardComponent, PersonalLoansAndCreditOptionsComponent, BalanceTransferComponent, BuildingCreditHealthAfterSetbackComponent, ImproveCreditHealthComponent, ImproveCreditHistoryComponent, HowToPayOffDebtComponent, EmploymentCreditCheckComponent, NewChipCreditCardTechnologyComponent, ShareRentLeaseOrBuyACarOptionsComponent, FiveFinancialQuestionsToAskPartnerComponent, FinancialLiteracyForKidsComponent, WhenShouldIGetACreditCardComponent, HowDoesDivorceAffectYourCreditComponent, ShouldIGetABusinessCreditCardComponent, FinancialTipsToGetAheadComponent, HowToPayForWeddingSeasonComponent, MarriageAndFinancesAnswersToCommonQuestionsComponent, SevenStepsToFinancialHealthComponent] 
})
export class KnowledgeCenterModule { }
