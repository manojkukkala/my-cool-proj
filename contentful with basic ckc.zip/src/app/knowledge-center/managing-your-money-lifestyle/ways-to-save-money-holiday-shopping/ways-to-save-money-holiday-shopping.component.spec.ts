import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaysToSaveMoneyHolidayShoppingComponent } from './ways-to-save-money-holiday-shopping.component';

describe('WaysToSaveMoneyHolidayShoppingComponent', () => {
  let component: WaysToSaveMoneyHolidayShoppingComponent;
  let fixture: ComponentFixture<WaysToSaveMoneyHolidayShoppingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaysToSaveMoneyHolidayShoppingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaysToSaveMoneyHolidayShoppingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
