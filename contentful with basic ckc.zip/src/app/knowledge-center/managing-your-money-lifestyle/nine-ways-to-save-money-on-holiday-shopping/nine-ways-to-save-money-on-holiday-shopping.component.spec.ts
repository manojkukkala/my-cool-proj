import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NineWaysToSaveMoneyOnHolidayShoppingComponent } from './nine-ways-to-save-money-on-holiday-shopping.component';

describe('NineWaysToSaveMoneyOnHolidayShoppingComponent', () => {
  let component: NineWaysToSaveMoneyOnHolidayShoppingComponent;
  let fixture: ComponentFixture<NineWaysToSaveMoneyOnHolidayShoppingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NineWaysToSaveMoneyOnHolidayShoppingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NineWaysToSaveMoneyOnHolidayShoppingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
