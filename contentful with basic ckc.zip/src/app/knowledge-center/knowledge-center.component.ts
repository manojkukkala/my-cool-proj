import { Datastore } from '../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

//import { DrupalJSONAPIService } from '../drupal-content-services/drupal-jsonapi.service';
import { ContentfulService } from '../contentful-services/contentful.service';
import { MarketingPageModel } from '../drupal-content-services/models/nodes/marketing_page.model';
import { ShowcaseComponent } from '../uicomponents-with-content/showcase/showcase.component';

@Component({
  selector: 'app-knowledge-center',
  templateUrl: './knowledge-center.component.html',
  styleUrls: ['./knowledge-center.component.css']
})
export class KnowledgeCenterComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  private pageId = "f548bba3-1424-41cb-adb1-27dbff28943b";

  mp: MarketingPageModel;
  
  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore,private contentfulService: ContentfulService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.datastore.findRecord(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((marketingPage: MarketingPageModel) => {
        this.mp = marketingPage;
        console.log(marketingPage);
        this.isLoaded = true;
      });
  }
}

