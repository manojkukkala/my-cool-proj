import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiveTipsToReduceHolidayStressComponent } from './five-tips-to-reduce-holiday-stress.component';

describe('FiveTipsToReduceHolidayStressComponent', () => {
  let component: FiveTipsToReduceHolidayStressComponent;
  let fixture: ComponentFixture<FiveTipsToReduceHolidayStressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiveTipsToReduceHolidayStressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiveTipsToReduceHolidayStressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
