import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirlineCreditCardsComponent } from './airline-credit-cards.component';

describe('AirlineCreditCardsComponent', () => {
  let component: AirlineCreditCardsComponent;
  let fixture: ComponentFixture<AirlineCreditCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirlineCreditCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirlineCreditCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
