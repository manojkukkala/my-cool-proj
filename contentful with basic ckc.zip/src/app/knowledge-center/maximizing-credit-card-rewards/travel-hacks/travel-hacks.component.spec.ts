import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelHacksComponent } from './travel-hacks.component';

describe('TravelHacksComponent', () => {
  let component: TravelHacksComponent;
  let fixture: ComponentFixture<TravelHacksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelHacksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelHacksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
