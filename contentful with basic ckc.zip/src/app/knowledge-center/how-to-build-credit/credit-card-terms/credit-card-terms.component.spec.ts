import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditCardTermsComponent } from './credit-card-terms.component';

describe('CreditCardTermsComponent', () => {
  let component: CreditCardTermsComponent;
  let fixture: ComponentFixture<CreditCardTermsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditCardTermsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardTermsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
