import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildCreditNewResidentsComponent } from './build-credit-new-residents.component';

describe('BuildCreditNewResidentsComponent', () => {
  let component: BuildCreditNewResidentsComponent;
  let fixture: ComponentFixture<BuildCreditNewResidentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildCreditNewResidentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildCreditNewResidentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
