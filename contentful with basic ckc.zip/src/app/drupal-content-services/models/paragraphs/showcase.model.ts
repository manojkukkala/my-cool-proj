import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
import { ColumnDataModel } from '../nodes/column_data.model';
import { FileDataModel } from '../nodes/file.model';
import { RowDataModel } from './showcase_row.model';
import { MarketingPageModel } from 'app/drupal-content-services/models/nodes';

@JsonApiModelConfig({
    type: 'paragraph--showcase'
})
export class ShowcaseModel extends JsonApiModel {
    @Attribute()
    showcaseType: string;

    @Attribute()
    imageSide: string;

    @BelongsTo()
    headerImg: FileDataModel;

    @Attribute()
    headerText: string;

    @BelongsTo()
    headerIcon: FileDataModel;

    @Attribute()
    subheaderText: string;

    @Attribute()
    cta: Link;

    @HasMany()
    rowData: RowDataModel[];

    @HasMany()
    columnData: ColumnDataModel[];

    @HasMany()
    components: JsonApiModel[];
}