import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--list'
})
export class ListModel extends JsonApiModel {
    @Attribute()
    field_list_title: string;

    @Attribute()
    field_list_item: string;
}