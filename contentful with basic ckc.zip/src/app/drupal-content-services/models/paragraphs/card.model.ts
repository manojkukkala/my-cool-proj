import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { body } from '../../drupal-fields.interface';

@JsonApiModelConfig({
    type: 'paragraph--card'
})
export class CardModel extends JsonApiModel {
    @Attribute()
    cardName: string;

    @Attribute()
    product: string;

    @Attribute()
    productTitle: string;

    @Attribute()
    featureOneHeader: string;

    @Attribute()
    featureTwoHeader: string;

    @Attribute()
    featureTwoText: string;

    @Attribute()
    listText: string;

    @Attribute()
    isList: boolean;

    @Attribute()
    featureThreeHeader: string;

    @Attribute()
    featureThreeText: string;

    @Attribute()
    primaryCtaLabel: string;
    
    @Attribute()
    primaryCtaUrl: string;
}