import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'link'
})
export class LinkModel extends JsonApiModel {
    @Attribute()
    linkText: string;

    @Attribute()
    linkUrl: string;
}