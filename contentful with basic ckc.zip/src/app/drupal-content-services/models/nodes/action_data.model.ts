import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
import { FileDataModel } from '../nodes/file.model';

@JsonApiModelConfig({
    type: 'action'
})
export class ActionDataModel extends JsonApiModel {
    @BelongsTo()
    icon: FileDataModel;

    @Attribute()
    headerLink: Link;

    @Attribute()
    descriptionText: string;

}