import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany } from 'angular2-jsonapi';

@JsonApiModelConfig({
  type: 'marketing_page'
})
export class MarketingPageModel extends JsonApiModel {

  @Attribute()
  nid: number;
  
  @Attribute()
  title: string;

  @HasMany()
  components: JsonApiModel[];

  @Attribute()
  pageType: string;

  @Attribute()
  seoTags: string;

}