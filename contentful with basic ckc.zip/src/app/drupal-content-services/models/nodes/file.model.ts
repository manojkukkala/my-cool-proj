import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'file--file'
})
export class FileDataModel extends JsonApiModel {
    @Attribute()
    url: string;

    @Attribute()
    filename: string;
}