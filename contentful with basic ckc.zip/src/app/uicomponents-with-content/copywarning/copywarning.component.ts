import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { CopyWarningModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'copy-warning',
  templateUrl: './copywarning.component.html',
  styleUrls: ['./copywarning.component.css']
})
export class CopywarningComponent implements OnInit {
  @Input() component: CopyWarningModel;

  @Input() header: string;
  @Input() headerType: string;
  @Input() copyContent: string;
  @Input() textStyle: string;
  @Input() border: boolean;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }


}