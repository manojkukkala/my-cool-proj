import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as _ from 'underscore';
import { ShowcaseModel } from '../../drupal-content-services/models/paragraphs';
import { environment } from 'environments/environment'
import { MarketingPageModel } from "app/drupal-content-services/models/nodes";

@Component({
  selector: 'app-showcase',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.css']
})
export class ShowcaseComponent implements OnInit {

  @Input() component: ShowcaseModel;

  @Input() layout: MarketingPageModel;

  //public env = environment.drupalUrl;
  public envimages = environment.assestUrl;
  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId;
  public token = environment.contentful.token;

  /*  Setting page types changes the Showcase template view so that the same content 
      structure can be used in different visual variations. The only currently accepted
      value is 'category' and is set at the Marketing Page level.
  */
  public pageType = this.layout;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
    console.log('Page type is', this.layout);
    this.pageType = this.layout;
  }

  isObject(obj){
    return _.isObject(obj);
  }

}
