import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { BreadcrumbModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {
  @Input() component: BreadcrumbModel;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }

}
