import { Component, OnInit, Input, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as _ from 'underscore';
import { SocialIconModel } from '../../drupal-content-services/models/paragraphs';
import { environment } from 'environments/environment'

@Component({
  selector: 'app-social-icons',
  templateUrl: './social-icons.component.html',
  styleUrls: ['./social-icons.component.css']
})
export class SocialIconsComponent implements OnInit {

  @Input() component: SocialIconModel;

  public env = environment.drupalUrl;
  
 constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }
}