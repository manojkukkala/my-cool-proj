import { Datastore } from './../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';

@Component({
  selector: 'app-citigold-package',
  templateUrl: './citigold-package.component.html',
  styleUrls: ['./citigold-package.component.css']
})
export class CitigoldPackageComponent implements OnInit {
  /**
   * content ID of the marketing page node
  */
  private pageId = "1eb3c70a-9832-4c2c-8571-331836d8dfd9";
  mp: MarketingPageModel;
  /**
  * JSONAPI include
  */
  private include = 'components,components.components,components.field_showcase_type,components.field_showcase_header_image,components.field_showcase_header_icon,components.field_showcase_headline,components.field_showcase_subheader_text,components.field_showcase_cta,components.field_showcase_content,components.field_showcase_content.field_showcase_img,components.field_showcase_content.field_showcase_headline,components.field_showcase_content.field_body,components.field_showcase_content.field_showcase_cta,components.field_showcase_row_data,components.field_showcase_row_data.field_showcase_column_data,components.field_showcase_row_data.field_showcase_column_data.field_body,components.field_showcase_row_data.field_showcase_column_data.field_showcase_cta,components.field_showcase_row_data.field_showcase_column_data.field_showcase_headline,components.field_showcase_row_data.field_showcase_column_data.field_showcase_img,components.field_para_component,components.field_showcase_row_data.field_showcase_line_divider,components.field_promo_image';
  /**
  * JSONAPI fields
  */
  private fields = {};
  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};

  public isLoaded: boolean = false;


  public actionComponents = [];

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }
  ngOnInit() {
    this.datastore.findRecord(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((marketingPage: MarketingPageModel) => {
        this.mp = marketingPage;
        console.log(marketingPage);
        this.isLoaded = true;

        this.actionComponents = [
                      this.mp.components[5],this.mp.components[6],
                      this.mp.components[7],this.mp.components[8],
                      this.mp.components[11],this.mp.components[10],
                      this.mp.components[9],this.mp.components[12]
        ];


      });
  }
}
