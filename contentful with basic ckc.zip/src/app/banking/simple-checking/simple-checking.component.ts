import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';

import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { ShowcaseModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-simple-checking',
  templateUrl: './simple-checking.component.html',
  styleUrls: ['./simple-checking.component.css']
})
export class SimpleCheckingComponent implements OnInit {

  /**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/141
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "42154dff-ed08-4890-8d73-36a189765c4d";
  
  /**
   * JSONAPI include
   */
  private include = 'components,components.field_showcase_type,components.field_showcase_header_image,components.field_showcase_header_icon,components.field_showcase_headline,components.field_showcase_subheader_text,components.field_showcase_cta,components.field_showcase_content,components.field_showcase_content.field_showcase_img,components.field_showcase_content.field_showcase_headline,components.field_showcase_content.field_body,components.field_showcase_content.field_showcase_cta,components.field_showcase_row_data,components.field_showcase_row_data.field_showcase_column_data,components.field_showcase_row_data.field_showcase_column_data.field_body,components.field_showcase_row_data.field_showcase_column_data.field_showcase_cta,components.field_showcase_row_data.field_showcase_column_data.field_showcase_headline,components.field_showcase_row_data.field_showcase_column_data.field_showcase_img,components.field_showcase_row_data.field_showcase_line_divider';

  /**
   * JSONAPI fields
   */
  private fields = {
    'paragraph--showcase': 'showcaseType,imageSide,headerImg,subheaderText,headerIcon,headerText,cta,columnData,rowData',
    'paragraph--showcase_row': 'columnData,lineDivider',
    'showcase': 'headerImg,headerText,descriptionText,footerLink',
    'file--file': 'url,filename'
  };

  public components = {
    basicBanking: '69690706-648a-4783-a263-7e90a45df998',
    whyCiti: '82c177fe-8b37-4dc3-871c-d8d19cb561c7',
    getMoreBanking: 'c9a8c588-14c6-42e3-9fcc-08750feed163',
    businessBanking: '31aa6418-ecf3-4b04-a264-6a944a3dcc68'
  };
  
  /**
   * Merge all query paramters in queryParamters
   */
  private queryParameters = {};  

  public isLoaded: boolean = false;
  public page: any;
    

    constructor(private drupalJSONAPIService: DrupalJSONAPIService) {
      this.queryParameters = {
        include: this.include,
        fields: this.fields
      }
    }

    ngOnInit() {
      this.drupalJSONAPIService.getDocument(MarketingPageModel, this.pageId, this.queryParameters)
        .subscribe((document: MarketingPageModel) => {
          console.log(document); // metadata
          this.page = document;
          document.components.forEach(component => {
            if (component instanceof ShowcaseModel) {
              _.each(this.components, (v, k) => {
                if (component.id == v) {
                  this.components[k] = component;
                  console.log(component);
                }
              });
            }
          });
            this.isLoaded = true;
        });
    }

}
