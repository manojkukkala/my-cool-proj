import { Component, OnInit ,AfterViewInit } from '@angular/core';
import { Datastore } from '../drupal-content-services/datastore';

import { DrupalJSONAPIService } from '../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../drupal-content-services/models/nodes/marketing_page.model';
import { FaqDataModel } from '../drupal-content-services/models/nodes/faq_data.model';
import { ShowcaseComponent } from '../uicomponents-with-content/showcase/showcase.component';

import { JsonApiQueryData } from 'angular2-jsonapi';
import { MockDecision } from '../mock-test/mock-decision';

@Component({
  selector: 'app-help-center',
  templateUrl: './help-center.component.html',
  styleUrls: ['./help-center.component.css']
})
export class HelpCenterComponent implements OnInit {
  
  public passedData: any;
  public mp: MarketingPageModel;
  public faqd: FaqDataModel;  
  public mockDecision: MockDecision;

  //This is the machine generated uuid for the content item in Drupal
  private pageId = "045420f7-5e4b-4d73-9dcf-9bf7aeae55b4";

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

   
  constructor(private datastore: Datastore) {     
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {  }

  ngAfterViewInit() {
    this.datastore.findRecord(MarketingPageModel, this.pageId)
      .subscribe((marketingPage: MarketingPageModel) => {
        this.mp = marketingPage;
        console.log(marketingPage);
        this.isLoaded = true;
      });     
  }
}