import { Injectable } from '@angular/core';

@Injectable()
export class BannerService {
    public data: any;

    constructor() {
        this.data = {
   // Filter by Banner title
            'FICO':{
                'titleFilter': {
                    'condition': {
                        'path': 'title',
                        'value': 'Citi FICO'
                   }
                }
            },
            'Simplicity':{
                'titleFilter': {
                    'condition': {
                        'path': 'title',
                        'value': 'citi Simplicity Card'
                   }
                }
            },
			'Costco':{
                'titleFilter': {
                    'condition': {
                        'path': 'title',
                        'value': 'Citi Costco Anywhere Visa Card'
                   }
                }
            },
			'DoubleCash':{
                'titleFilter': {
                    'condition': {
                        'path': 'title',
                        'value': 'Citi Double Cash Card'
                   }
                }
            },
            'AAdvantage': {
                'titleFilter': {
                    'condition': {
                        'path': 'title',
                        'value': 'Citi/AAdvantage Platinum Select World Elite Mastercard'                
                    }
                }
            },
    // Filter by single Taxonomy term        
            'FICOtag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_cards_tags.name',                        
                        'value': 'FICO'                
                    }
                }
            },
   // Filter by double Taxonomy term            
            'Simplicitytag': {
                'filter': {
                    'andGroup': {
                        'group': {
                            'conjunction': 'AND'
                        }
                    },
                    'cardTag': {
                        'condition': {
                            'path': 'field_cards_tags.name',                        
                            'value': 'Simplicity Card',
                            'memberOf': 'andGroup'                
                        }
                    },
                    'feeTag': {
                        'condition': {
                            'path': 'field_fee_tag.name',                        
                            'value': 'No Annual Fee',
                            'memberOf': 'andGroup'
                        }
                    }
                }
            },
            'Costcotag': {
                'filter': {
                    'andGroup': {
                        'group': {
                            'conjunction': 'AND'
                        }
                    },
                    'cardTag': {
                        'condition': {
                            'path': 'field_cards_tags.name',                        
                            'value': 'Costco Card',
                            'memberOf': 'andGroup'                
                        }
                    },
                    'feeTag': {
                        'condition': {
                            'path': 'field_fee_tag.name',                        
                            'value': 'No annual fee with your paid Costco membership',
                            'memberOf': 'andGroup'
                        }
                    }
                }
            }

        };
    };
    // Default filter
    getfilters = () =>{  
        let filterData =  this.data.Simplicitytag; 
        if(filterData){
            return filterData.filter;
        }else{
            return this.data.FICO;
        }
    };
}