import { BannerService } from './services/banner.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { fullHtmlPipe } from '../pipes/fullHtml.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [ BannerService ],
  declarations: [ fullHtmlPipe ],
  exports: [ 
    fullHtmlPipe
  ]
})
export class SharedModule { }
