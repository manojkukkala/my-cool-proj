import { Datastore } from './../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';
import { ArticlePageModel } from '../../drupal-content-services/models/nodes/article_page.model';

@Component({
  selector: 'app-financial-harmony',
  templateUrl: './financial-harmony.component.html',
  styleUrls: ['./financial-harmony.component.css']
})
export class FinancialHarmonyComponent implements OnInit {
  /**
   * content ID of the article page node
  */
  private pageId = "701bdac4-533b-4b42-a524-ad2098827679";
  ap: ArticlePageModel;
  /**
  * JSONAPI include
  */
  private include = 'field_components,field_components.field_article_hero,field_components.field_showcase_type,field_components.field_showcase_header_image,field_components.field_showcase_header_icon,field_components.field_showcase_headline,field_components.field_showcase_subheader_text,field_components.field_showcase_cta,field_components.field_showcase_content,field_components.field_showcase_content.field_showcase_img,field_components.field_showcase_content.field_showcase_headline,field_components.field_showcase_content.field_body,field_components.field_showcase_content.field_showcase_cta,field_components.field_showcase_row_data,field_components.field_showcase_row_data.field_showcase_column_data,field_components.field_showcase_row_data.field_showcase_column_data.field_body,field_components.field_showcase_row_data.field_showcase_column_data.field_showcase_cta,field_components.field_showcase_row_data.field_showcase_column_data.field_showcase_headline,field_components.field_showcase_row_data.field_showcase_column_data.field_showcase_img,field_components.field_para_component,field_components.field_showcase_row_data.field_showcase_line_divider,field_components.field_article_related_content,field_components.field_article_related_content.field_article_related_cta,field_components.field_article_related_content.field_related_article_image';
  /**
  * JSONAPI fields
  */
  private fields = {};
  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }
  ngOnInit() {
    this.datastore.findRecord(ArticlePageModel, this.pageId, this.queryParameters)
      .subscribe((articlePage: ArticlePageModel) => {
        this.ap = articlePage;
        console.log(articlePage);
        this.isLoaded = true;
      });
  }
}

