import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingProductsComponent } from './banking-products.component';

describe('BankingProductsComponent', () => {
  let component: BankingProductsComponent;
  let fixture: ComponentFixture<BankingProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
