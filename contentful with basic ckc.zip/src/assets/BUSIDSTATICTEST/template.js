Handlebars.templates = Handlebars.templates || {};

