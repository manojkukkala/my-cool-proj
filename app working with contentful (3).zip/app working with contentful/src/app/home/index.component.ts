import { Component } from '@angular/core';

@Component({
	templateUrl: './index.component.html',
	styleUrls: ['./index.component.css']
})
export class IndexComponent {

	tagValue = 'transaction';
	constructor() {

	}

}


