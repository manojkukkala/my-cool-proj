import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showcase-v1',
  templateUrl: './showcase-v1.component.html',
  styleUrls: ['./showcase-v1.component.css']
})
export class ShowcaseV1Component implements OnInit {

  showcases = [
    { 
      "headerText": "Convenient Locations",
      "headerIcon": "https://citi-ddl-ui.criticalmass.com/images/showcase-icon.svg",
      "footerLinkText": "Learn more about our services",
      "footerLinkUrl": "https://www.citi.com",
      "columnData": [
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_01.jpg",
          "headerText": "Convenient Locations",
          "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
          "footerLinkText": "Find an ATM or branch near you",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        }, 
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_02_Citigold.jpg",
          "headerText": "Banking and Investment Mobile Tools",
          "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand."
        }, 
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_03.jpg",
          "headerText": "Account Protection",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
          "footerLinkText": "Sign up for Account Protection",
          "footerLinkUrl": "https://www.citi.com"
        }
      ]
    },
    {
      "headerText": "Why Citi?",
      "columnData": [
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_03.jpg",
          "headerText": "Account Protection",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise."
        },
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_02.jpg",
          "headerText": "Practical Digital Tools",
          "descriptionText": "Our award-winning website and mobile app make it easy to bank virtually anywhere, anytime."
        },
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_01.jpg",
          "headerText": "Convenient Locations",
          "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
          "footerLinkText": "Find an ATM or branch near you",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        }  
      ]
    },
    { 
      "headerText": "Basic Banking Account Details",
      "columnData": [
        {
          "headerText": "Unlimited Check Writing",
          "descriptionText": "Write as many checks as you need and have checks sent directly from your account using Online Bill Payment."
        },
        {
          "headerText": "Seamless Money Movement",
          "descriptionText": "Settle up with friends, pay your bills, transfer funds and deposit checks with digital services that make it easy to move your money.<sup>7,8,9,10</sup>"
        },
        {
          "headerText": "Free ATM Access",
          "descriptionText": "Get fee-free access to thousands of Citi ATMs. Plus no Citibank ATM fee when using a non-Citi ATM if first listed account owner is 62 or older."
        },
        {
          "headerText": "Unlimited Check Writing",
          "descriptionText": "Write as many checks as you need and have checks sent directly from your account using Online Bill Payment."
        },
        {
          "headerText": "Seamless Money Movement",
          "descriptionText": "<ul><li>Unlimited refunds of non-Citi ATM fees<sup>11</sup></li><li>Waived overdraft protection transfer fees<sup>12</sup></li><li>Waived fees for standard checkbook orders, stop payments, incoming wire transfers and money orders</li><li>Exclusive travel services like Citigold Home Connect and access to our Citigold Lounge<sup>13</sup></li></ul>"
        }
      ]
    },
    { 
      "headerText": "Award-Winning Service",
      "headerIcon": "https://citi-ddl-ui.criticalmass.com/images/showcase-icon.svg",
      "footerLinkText": "Watch on YouTube",
      "footerLinkUrl": "https://www.youtube.com/citi",
      "columnData": [
        {
          "headerText": "Convenient Locations",
          "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
          "footerLinkText": "Find an ATM or branch near you",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        }, 
        {
          "headerText": "Banking and Investment Mobile Tools",
          "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
          "footerLinkText": "Find a CitiBike location",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        }, 
        {
          "headerText": "Account Protection",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
          "footerLinkText": "Sign up for Account Protection",
          "footerLinkUrl": "https://www.citi.com"
        },
        {
          "headerText": "Banking and Investment Mobile Tools",
          "descriptionText": "Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
          "footerLinkText": "Find a CitiBike location",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        },
        {
          "headerText": "Account Protection",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise.",
          "footerLinkText": "Sign up for Account Protection",
          "footerLinkUrl": "https://www.citi.com"
        },
        {
          "headerText": "Convenient Locations",
          "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money.",
          "footerLinkText": "Find an ATM or branch near you",
          "footerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder"
        }
      ]
    },
    {
      "headerText": "The Freshmaker",
      "columnData": [
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_03.jpg",
          "headerLinkText": "The New CitiFood Truck",
          "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise."
        },
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_02.jpg",
          "headerLinkText": "Cookie Monster Strikes Back",
          "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise."
        },
        {
          "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_WhyCiti_01.jpg",
          "headerLinkText": "So Many Xenomorphs",
          "headerLinkUrl": "https://online.citi.com/US/ag/citibank-location-finder",
          "descriptionText": "We take measures to help protect your account with ongoing fraud monitoring, activity notifications and alerts. Plus you have automatic access to Citi® Identity Theft Solutions should the need ever arise."
        }  
      ]
    }
  ]

  constructor() { }

  ngOnInit() {
  }

}
