import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-banking-products',
  templateUrl: './banking-products.component.html',
  styleUrls: ['./banking-products.component.css']
})
export class BankingProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
