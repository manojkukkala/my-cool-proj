import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatingCreditCardDebtComponent } from './consolidating-credit-card-debt.component';

describe('ConsolidatingCreditCardDebtComponent', () => {
  let component: ConsolidatingCreditCardDebtComponent;
  let fixture: ComponentFixture<ConsolidatingCreditCardDebtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsolidatingCreditCardDebtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidatingCreditCardDebtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
