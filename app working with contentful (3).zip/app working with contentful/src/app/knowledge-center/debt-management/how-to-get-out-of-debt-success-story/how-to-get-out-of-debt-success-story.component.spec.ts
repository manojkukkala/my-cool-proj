import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToGetOutOfDebtSuccessStoryComponent } from './how-to-get-out-of-debt-success-story.component';

describe('HowToGetOutOfDebtSuccessStoryComponent', () => {
  let component: HowToGetOutOfDebtSuccessStoryComponent;
  let fixture: ComponentFixture<HowToGetOutOfDebtSuccessStoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToGetOutOfDebtSuccessStoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToGetOutOfDebtSuccessStoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
