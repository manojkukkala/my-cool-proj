import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SixThingsToKnowAboutAprComponent } from './six-things-to-know-about-apr.component';

describe('SixThingsToKnowAboutAprComponent', () => {
  let component: SixThingsToKnowAboutAprComponent;
  let fixture: ComponentFixture<SixThingsToKnowAboutAprComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SixThingsToKnowAboutAprComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SixThingsToKnowAboutAprComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
