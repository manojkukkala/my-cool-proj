import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiftyThirtyTwentyBudgetPlannerComponent } from './fifty-thirty-twenty-budget-planner.component';

describe('FiftyThirtyTwentyBudgetPlannerComponent', () => {
  let component: FiftyThirtyTwentyBudgetPlannerComponent;
  let fixture: ComponentFixture<FiftyThirtyTwentyBudgetPlannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiftyThirtyTwentyBudgetPlannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiftyThirtyTwentyBudgetPlannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
