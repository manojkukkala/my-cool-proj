import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtSnowballComponent } from './debt-snowball.component';

describe('DebtSnowballComponent', () => {
  let component: DebtSnowballComponent;
  let fixture: ComponentFixture<DebtSnowballComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtSnowballComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtSnowballComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
