import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToPayOffCreditCardDebtComponent } from './how-to-pay-off-credit-card-debt.component';

describe('HowToPayOffCreditCardDebtComponent', () => {
  let component: HowToPayOffCreditCardDebtComponent;
  let fixture: ComponentFixture<HowToPayOffCreditCardDebtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToPayOffCreditCardDebtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToPayOffCreditCardDebtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
