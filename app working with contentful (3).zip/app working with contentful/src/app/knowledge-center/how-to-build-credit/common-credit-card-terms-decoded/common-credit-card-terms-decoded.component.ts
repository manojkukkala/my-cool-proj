import { Datastore } from '../../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../../../drupal-content-services/drupal-jsonapi.service';
import { ArticlePageModel } from '../../../drupal-content-services/models/nodes/article_page.model';
import { SocialIconsComponent } from '../../../uicomponents-with-content/social-icons/social-icons.component';

@Component({
  selector: 'app-common-credit-card-terms-decoded',
  templateUrl: './common-credit-card-terms-decoded.component.html',
  styleUrls: ['./common-credit-card-terms-decoded.component.css']
})
export class CommonCreditCardTermsDecodedComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  private pageId = "ca8dbe4b-54bd-4d1b-a3f7-bccf5c98a071";

  ap: ArticlePageModel;

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.datastore.findRecord(ArticlePageModel, this.pageId, this.queryParameters)
      .subscribe((articlePage: ArticlePageModel) => {
        this.ap = articlePage;
        console.log(articlePage);
        this.isLoaded = true;
      });
  }

}
