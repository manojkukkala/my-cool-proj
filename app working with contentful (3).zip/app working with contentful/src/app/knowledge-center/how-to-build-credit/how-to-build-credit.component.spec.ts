import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToBuildCreditComponent } from './how-to-build-credit.component';

describe('HowToBuildCreditComponent', () => {
  let component: HowToBuildCreditComponent;
  let fixture: ComponentFixture<HowToBuildCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToBuildCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToBuildCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
