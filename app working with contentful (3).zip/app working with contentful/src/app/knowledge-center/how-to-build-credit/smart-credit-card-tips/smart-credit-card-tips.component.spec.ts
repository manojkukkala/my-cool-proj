import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartCreditCardTipsComponent } from './smart-credit-card-tips.component';

describe('SmartCreditCardTipsComponent', () => {
  let component: SmartCreditCardTipsComponent;
  let fixture: ComponentFixture<SmartCreditCardTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartCreditCardTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartCreditCardTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
