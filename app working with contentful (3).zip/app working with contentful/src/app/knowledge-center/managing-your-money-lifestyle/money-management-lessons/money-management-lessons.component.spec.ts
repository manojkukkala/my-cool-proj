import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoneyManagementLessonsComponent } from './money-management-lessons.component';

describe('MoneyManagementLessonsComponent', () => {
  let component: MoneyManagementLessonsComponent;
  let fixture: ComponentFixture<MoneyManagementLessonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoneyManagementLessonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoneyManagementLessonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
