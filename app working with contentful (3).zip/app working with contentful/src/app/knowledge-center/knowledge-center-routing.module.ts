import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KnowledgeCenterComponent } from "app/knowledge-center/knowledge-center.component";

/*debt management components*/
import { DebtManagementComponent } from "app/knowledge-center/debt-management/debt-management.component";
import { BalanceTransferComponent } from 'app/knowledge-center/debt-management/balance-transfer/balance-transfer.component';
import { BestWaysToPayOffDebtComponent } from 'app/knowledge-center/debt-management/best-ways-to-pay-off-debt/best-ways-to-pay-off-debt.component';
import { ConsolidatingCreditCardDebtComponent } from 'app/knowledge-center/debt-management/consolidating-credit-card-debt/consolidating-credit-card-debt.component';
import { DebtSnowballComponent } from 'app/knowledge-center/debt-management/debt-snowball/debt-snowball.component';
import { FiftyThirtyTwentyBudgetPlannerComponent} from 'app/knowledge-center/debt-management/fifty-thirty-twenty-budget-planner/fifty-thirty-twenty-budget-planner.component';
import { FourWaysTowardsFinancialGoalsComponent	} from 'app/knowledge-center/debt-management/four-ways-towards-financial-goals/four-ways-towards-financial-goals.component';
import { HowToGetOutOfCreditCardDebtComponent	} from 'app/knowledge-center/debt-management/how-to-get-out-of-credit-card-debt/how-to-get-out-of-credit-card-debt.component';
import { HowToGetOutOfDebtSuccessStoryComponent } from "app/knowledge-center/debt-management/how-to-get-out-of-debt-success-story/how-to-get-out-of-debt-success-story.component";
import {HowToPayOffCreditCardDebtComponent} from 'app/knowledge-center/debt-management/how-to-pay-off-credit-card-debt/how-to-pay-off-credit-card-debt.component';
import {HowToPayOffDebtWithDebtAvalancheComponent} from 'app/knowledge-center/debt-management/how-to-pay-off-debt-with-debt-avalanche/how-to-pay-off-debt-with-debt-avalanche.component';
import {PersonalLoansAndCreditOptionsComponent} from 'app/knowledge-center/debt-management/personal-loans-and-credit-options/personal-loans-and-credit-options.component';
import {SharedCreditCardsProsAndConsComponent} from 'app/knowledge-center/debt-management/shared-credit-cards-pros-and-cons/shared-credit-cards-pros-and-cons.component';
import {SixThingsToKnowAboutAprComponent} from 'app/knowledge-center/debt-management/six-things-to-know-about-apr/six-things-to-know-about-apr.component';
import {WaysToPayOffCreditCardComponent} from 'app/knowledge-center/debt-management/ways-to-pay-off-credit-card/ways-to-pay-off-credit-card.component';

/*how to build credit components*/
import { HowToBuildCreditComponent } from "app/knowledge-center/how-to-build-credit/how-to-build-credit.component";
import { BuildCreditNewResidentsComponent } from "app/knowledge-center/how-to-build-credit/build-credit-new-residents/build-credit-new-residents.component";
import { BuildCreditWithASecuredCreditCardComponent } from'app/knowledge-center/how-to-build-credit/build-credit-with-a-secured-credit-card/build-credit-with-a-secured-credit-card.component';
import { BuildingCreditAfterCollegeComponent } from "app/knowledge-center/how-to-build-credit/building-credit-after-college/building-credit-after-college.component";
import { CommonCreditCardTermsDecodedComponent } from 'app/knowledge-center/how-to-build-credit/common-credit-card-terms-decoded/common-credit-card-terms-decoded.component';
import { CreditCardFaqsAndTipsComponent } from "app/knowledge-center/how-to-build-credit/credit-card-faqs-and-tips/credit-card-faqs-and-tips.component";
import { CreditCardTermsComponent } from "app/knowledge-center/how-to-build-credit/credit-card-terms/credit-card-terms.component";
import { FiveQuestionsToAskBeforeGettingFirstCreditCardComponent } from "app/knowledge-center/how-to-build-credit/five-questions-to-ask-before-getting-first-credit-card/five-questions-to-ask-before-getting-first-credit-card.component";
import { HowToCheckACreditReportComponent } from "app/knowledge-center/how-to-build-credit/how-to-check-a-credit-report/how-to-check-a-credit-report.component";
import { HowToHelpBuildCreditComponent } from "app/knowledge-center/how-to-build-credit/how-to-help-build-credit/how-to-help-build-credit.component";
import { HowToOvercomeCreditCardFearComponent } from "app/knowledge-center/how-to-build-credit/how-to-overcome-credit-card-fear/how-to-overcome-credit-card-fear.component";
import { InsideACreditReportComponent } from "app/knowledge-center/how-to-build-credit/inside-a-credit-report/inside-a-credit-report.component";
import { SecuredVsUnsecuredCreditCardsComponent } from "app/knowledge-center/how-to-build-credit/secured-vs-unsecured-credit-cards/secured-vs-unsecured-credit-cards.component";
import { SmartCreditCardTipsComponent } from "app/knowledge-center/how-to-build-credit/smart-credit-card-tips/smart-credit-card-tips.component";

/*managing your money components*/
import { ManagingYourMoneyLifestyleComponent } from "app/knowledge-center/managing-your-money-lifestyle/managing-your-money-lifestyle.component";
import { BudgetingTipsCutCollegeCostsComponent } from "app/knowledge-center/managing-your-money-lifestyle/budgeting-tips-cut-college-costs/budgeting-tips-cut-college-costs.component";
import { CollegeCostsAndExpensesComponent } from "app/knowledge-center/managing-your-money-lifestyle/college-costs-and-expenses/college-costs-and-expenses.component";
import { CommonMoneyMistakesToAvoidComponent } from "app/knowledge-center/managing-your-money-lifestyle/common-money-mistakes-to-avoid/common-money-mistakes-to-avoid.component";
import { EstablishingCreditAndBuildingCreditHealthComponent } from "app/knowledge-center/managing-your-money-lifestyle/establishing-credit-and-building-credit-health/establishing-credit-and-building-credit-health.component";
import { FourThingsToKnowAboutHolidaySpendingComponent } from "app/knowledge-center/managing-your-money-lifestyle/four-things-to-know-about-holiday-spending/four-things-to-know-about-holiday-spending.component";
import { GetTheMostFromYourCreditCardComponent } from "app/knowledge-center/managing-your-money-lifestyle/get-the-most-from-your-credit-card/get-the-most-from-your-credit-card.component";
import { HowToSaveMoneyBlackFridayCyberMondayComponent } from "app/knowledge-center/managing-your-money-lifestyle/how-to-save-money-black-friday-cyber-monday/how-to-save-money-black-friday-cyber-monday.component";
import { MoneyManagementLessonsComponent } from "app/knowledge-center/managing-your-money-lifestyle/money-management-lessons/money-management-lessons.component";
import { MovingBudgetChecklistComponent } from "app/knowledge-center/managing-your-money-lifestyle/moving-budget-checklist/moving-budget-checklist.component";
import { NineWaysToSaveMoneyOnHolidayShoppingComponent } from 'app/knowledge-center/managing-your-money-lifestyle/nine-ways-to-save-money-on-holiday-shopping/nine-ways-to-save-money-on-holiday-shopping.component';
import { RewardsCreditCardsForHolidayShoppingComponent } from "app/knowledge-center/managing-your-money-lifestyle/rewards-credit-cards-for-holiday-shopping/rewards-credit-cards-for-holiday-shopping.component";
import { WaysToSaveMoneyHolidayShoppingComponent } from "app/knowledge-center/managing-your-money-lifestyle/ways-to-save-money-holiday-shopping/ways-to-save-money-holiday-shopping.component";

/*maximizing credit card rewards*/
 import { MaximizingCreditCardRewardsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/maximizing-credit-card-rewards.component";
 import { AirlineCreditCardsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/airline-credit-cards/airline-credit-cards.component";
 import { BestTimeToBookAwardTravelComponent } from "app/knowledge-center/maximizing-credit-card-rewards/best-time-to-book-award-travel/best-time-to-book-award-travel.component";
 import { CanCashBackOrRewardsCreditCardHelpSaveComponent } from "app/knowledge-center/maximizing-credit-card-rewards/can-cash-back-or-rewards-credit-card-help-save/can-cash-back-or-rewards-credit-card-help-save.component";
 import { CashBackVsTraveRewardsCreditCardsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/cash-back-vs-trave-rewards-credit-cards/cash-back-vs-trave-rewards-credit-cards.component";
 import { DigitalWalletsAndVirtualWalletsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/digital-wallets-and-virtual-wallets/digital-wallets-and-virtual-wallets.component";
 import { FiveTipsToReduceHolidayStressComponent } from "app/knowledge-center/maximizing-credit-card-rewards/five-tips-to-reduce-holiday-stress/five-tips-to-reduce-holiday-stress.component";
 import { FourTravelTipsCardsOverseasComponent } from "app/knowledge-center/maximizing-credit-card-rewards/four-travel-tips-cards-overseas/four-travel-tips-cards-overseas.component";
 import { HowDoCashBackCardsWorkComponent } from "app/knowledge-center/maximizing-credit-card-rewards/how-do-cash-back-cards-work/how-do-cash-back-cards-work.component";
 import { HowToUseACreditCardComponent } from "app/knowledge-center/maximizing-credit-card-rewards/how-to-use-a-credit-card/how-to-use-a-credit-card.component";
 import { ThePointsGuyCreditCardTipsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/the-points-guy-credit-card-tips/the-points-guy-credit-card-tips.component";
 import { TravelCreditCardComponent } from "app/knowledge-center/maximizing-credit-card-rewards/travel-credit-card/travel-credit-card.component";
 import { TravelHacksComponent } from "app/knowledge-center/maximizing-credit-card-rewards/travel-hacks/travel-hacks.component";
 import { TravelRewardsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/travel-rewards/travel-rewards.component";
 import { TravelingTheWorldComponent } from "app/knowledge-center/maximizing-credit-card-rewards/traveling-the-world/traveling-the-world.component";
 import { UsingCreditCardRewardsForTravelComponent } from "app/knowledge-center/maximizing-credit-card-rewards/using-credit-card-rewards-for-travel/using-credit-card-rewards-for-travel.component";
 import { UsingYourCreditCardAbroadComponent } from "app/knowledge-center/maximizing-credit-card-rewards/using-your-credit-card-abroad/using-your-credit-card-abroad.component";
 import { WhatToKnowAboutCashBackCreditCardsComponent } from "app/knowledge-center/maximizing-credit-card-rewards/what-to-know-about-cash-back-credit-cards/what-to-know-about-cash-back-credit-cards.component";


 /*planning the future components*/
import { PlanningForTheFutureComponent } from "app/knowledge-center/planning-for-the-future/planning-for-the-future.component";
import { EmploymentCreditCheckComponent } from "app/knowledge-center/planning-for-the-future/employment-credit-check/employment-credit-check.component";
import { FinancialLiteracyForKidsComponent } from "app/knowledge-center/planning-for-the-future/financial-literacy-for-kids/financial-literacy-for-kids.component";
import { FinancialTipsToGetAheadComponent } from "app/knowledge-center/planning-for-the-future/financial-tips-to-get-ahead/financial-tips-to-get-ahead.component";
import { FiveFinancialQuestionsToAskPartnerComponent } from "app/knowledge-center/planning-for-the-future/five-financial-questions-to-ask-partner/five-financial-questions-to-ask-partner.component";
import { GettingACreditCardForKidsComponent } from "app/knowledge-center/planning-for-the-future/getting-a-credit-card-for-kids/getting-a-credit-card-for-kids.component";
import { HowDoesDivorceAffectYourCreditComponent } from "app/knowledge-center/planning-for-the-future/how-does-divorce-affect-your-credit/how-does-divorce-affect-your-credit.component";
import { HowToPayForWeddingSeasonComponent } from "app/knowledge-center/planning-for-the-future/how-to-pay-for-wedding-season/how-to-pay-for-wedding-season.component";
import { MarriageAndFinancesAnswersToCommonQuestionsComponent } from "app/knowledge-center/planning-for-the-future/marriage-and-finances-answers-to-common-questions/marriage-and-finances-answers-to-common-questions.component";
import { NewChipCreditCardTechnologyComponent } from "app/knowledge-center/planning-for-the-future/new-chip-credit-card-technology/new-chip-credit-card-technology.component";
import { SevenStepsToFinancialHealthComponent } from "app/knowledge-center/planning-for-the-future/seven-steps-to-financial-health/seven-steps-to-financial-health.component";
import { ShareRentLeaseOrBuyACarOptionsComponent } from "app/knowledge-center/planning-for-the-future/share-rent-lease-or-buy-a-car-options/share-rent-lease-or-buy-a-car-options.component";
import { ShouldIGetABusinessCreditCardComponent } from "app/knowledge-center/planning-for-the-future/should-i-get-a-business-credit-card/should-i-get-a-business-credit-card.component";
import { WhenShouldIGetACreditCardComponent } from "app/knowledge-center/planning-for-the-future/when-should-i-get-a-credit-card/when-should-i-get-a-credit-card.component";

/*rebuilding credit components*/
import { RebuildingCreditComponent } from "app/knowledge-center/rebuilding-credit/rebuilding-credit.component";
import { BuildingCreditHealthAfterSetbackComponent } from "app/knowledge-center/rebuilding-credit/building-credit-health-after-setback/building-credit-health-after-setback.component";
import { CreditCardFactsComponent } from "app/knowledge-center/rebuilding-credit/credit-card-facts/credit-card-facts.component";
import { HowToPayOffDebtComponent } from "app/knowledge-center/rebuilding-credit/how-to-pay-off-debt/how-to-pay-off-debt.component";
import { ImproveCreditHealthComponent } from "app/knowledge-center/rebuilding-credit/improve-credit-health/improve-credit-health.component";
import { ImproveCreditHistoryComponent } from "app/knowledge-center/rebuilding-credit/improve-credit-history/improve-credit-history.component";

export const routes: Routes = [
	{
		path: '',
		component: KnowledgeCenterComponent
	},
	{
		path: 'debt-management',
		component: DebtManagementComponent
	},
	{
		path: 'debt-management/balance-transfer',
		component: BalanceTransferComponent
	},
	{
		path: 'debt-management/best-ways-to-pay-off-debt',
		component: BestWaysToPayOffDebtComponent
	},	
	{
		path: 'debt-management/consolidating-credit-card-debt',
		component: ConsolidatingCreditCardDebtComponent
	},
	{
		path: 'debt-management/debt-snowball',
		component: DebtSnowballComponent
	},
	{
		path: 'debt-management/fifty-thirty-twenty-budget-planner',
		component: FiftyThirtyTwentyBudgetPlannerComponent
	},
	{
		path: 'debt-management/four-ways-towards-financial-goals',
		component: FourWaysTowardsFinancialGoalsComponent
	},
	{
		path: 'debt-management/how-to-get-out-of-credit-card-debt',
		component: HowToGetOutOfCreditCardDebtComponent
	},
	{
		path: 'debt-management/how-to-get-out-of-debt-success-story',
		component: HowToGetOutOfDebtSuccessStoryComponent
	},
	{
		path: 'debt-management/how-to-pay-off-credit-card-debt',
		component: HowToPayOffCreditCardDebtComponent
	},
	{
		path: 'debt-management/how-to-pay-off-debt-with-debt-avalanche',
		component: HowToPayOffDebtWithDebtAvalancheComponent
	},
	{
		path: 'debt-management/personal-loans-and-credit-options',
		component: PersonalLoansAndCreditOptionsComponent
	},
	{
		path: 'debt-management/shared-credit-cards-pros-and-cons',
		component: SharedCreditCardsProsAndConsComponent
	},
	{
		path: 'debt-management/six-things-to-know-about-apr',
		component: SixThingsToKnowAboutAprComponent
	},
	{
		path: 'debt-management/ways-to-pay-off-credit-card',
		component: WaysToPayOffCreditCardComponent
	},
	{
		path: 'how-to-build-credit',
		component: HowToBuildCreditComponent
	},
	{
		path: 'how-to-build-credit/build-credit-new-residents',
		component: BuildCreditNewResidentsComponent
	},
	{	
		path: 'how-to-build-credit/build-credit-with-a-secured-credit-card',
		component: BuildCreditWithASecuredCreditCardComponent
	},
	{
		path: 'how-to-build-credit/building-credit-after-college',
		component: BuildingCreditAfterCollegeComponent
	},
	{
		path: 'how-to-build-credit/common-credit-card-terms-decoded',
		component: CommonCreditCardTermsDecodedComponent
	},
	{
		path: 'how-to-build-credit/credit-card-faqs-and-tips',
		component: CreditCardFaqsAndTipsComponent
	},
	{
		path: 'how-to-build-credit/credit-card-terms',
		component: CreditCardTermsComponent
	},
	{
		path: 'how-to-build-credit/five-questions-to-ask-before-getting-first-credit-card',
		component: FiveQuestionsToAskBeforeGettingFirstCreditCardComponent
	},
	{
		path: 'how-to-build-credit/how-to-check-a-credit-report',
		component: HowToCheckACreditReportComponent
	},
	{
		path: 'how-to-build-credit/how-to-help-build-credit',
		component: HowToHelpBuildCreditComponent
	},
	{
		path: 'how-to-build-credit/how-to-overcome-credit-card-fear',
		component: HowToOvercomeCreditCardFearComponent
	},
	{
		path: 'how-to-build-credit/inside-a-credit-report',
		component: InsideACreditReportComponent
	},
	{
		path: 'how-to-build-credit/secured-vs-unsecured-credit-cards',
		component: SecuredVsUnsecuredCreditCardsComponent
	},
	{
		path: 'how-to-build-credit/smart-credit-card-tips',
		component: SmartCreditCardTipsComponent
	},
	{												
		path: 'managing-your-money-lifestyle',
		component: ManagingYourMoneyLifestyleComponent
	},
	{												
		path: 'managing-your-money-lifestyle/budgeting-tips-cut-college-costs',
		component: BudgetingTipsCutCollegeCostsComponent
	},
	{												
		path: 'managing-your-money-lifestyle/college-costs-and-expenses',
		component: CollegeCostsAndExpensesComponent
	},
	{												
		path: 'managing-your-money-lifestyle/common-money-mistakes-to-avoid',
		component: CommonMoneyMistakesToAvoidComponent
	},
	{												
		path: 'managing-your-money-lifestyle/establishing-credit-and-building-credit-health',
		component: EstablishingCreditAndBuildingCreditHealthComponent
	},
	{												
		path: 'managing-your-money-lifestyle/four-things-to-know-about-holiday-spending',
		component: FourThingsToKnowAboutHolidaySpendingComponent
	},
	{												
		path: 'managing-your-money-lifestyle/get-the-most-from-your-credit-card',
		component: GetTheMostFromYourCreditCardComponent
	},
	{												
		path: 'managing-your-money-lifestyle/how-to-save-money-black-friday-cyber-monday',
		component: HowToSaveMoneyBlackFridayCyberMondayComponent
	},
	{												
		path: 'managing-your-money-lifestyle/money-management-lessons',
		component: MoneyManagementLessonsComponent
	},
	{												
		path: 'managing-your-money-lifestyle/moving-budget-checklist',
		component: MovingBudgetChecklistComponent
	},
	{												
		path: 'managing-your-money-lifestyle/9-ways-to-save-money-on-holiday-shopping',
		component: NineWaysToSaveMoneyOnHolidayShoppingComponent
	},
	{												
		path: 'managing-your-money-lifestyle/rewards-credit-cards-for-holiday-shopping',
		component: RewardsCreditCardsForHolidayShoppingComponent
	},
	{												
		path: 'managing-your-money-lifestyle/ways-to-save-money-holiday-shopping',
		component: WaysToSaveMoneyHolidayShoppingComponent
	},												
	{
		path: 'maximizing-credit-card-rewards',
		component: MaximizingCreditCardRewardsComponent
	},
	{
		path: 'maximizing-credit-card-rewards/airline-credit-cards',
		component: AirlineCreditCardsComponent
	},	
	{
		path: 'maximizing-credit-card-rewards/best-time-to-book-award-travel',
		component: BestTimeToBookAwardTravelComponent
	},
	{
		path: 'maximizing-credit-card-rewards/can-cash-back-or-rewards-credit-card-help-save',
		component: CanCashBackOrRewardsCreditCardHelpSaveComponent
	},
	{
		path: 'maximizing-credit-card-rewards/cash-back-vs-trave-rewards-credit-cards',
		component: CashBackVsTraveRewardsCreditCardsComponent
	},
	{
		path: 'maximizing-credit-card-rewards/digital-wallets-and-virtual-wallets',
		component: DigitalWalletsAndVirtualWalletsComponent
	},
	{
		path: 'maximizing-credit-card-rewards/five-tips-to-reduce-holiday-stress',
		component: FiveTipsToReduceHolidayStressComponent
	},
	{
		path: 'maximizing-credit-card-rewards/four-travel-tips-cards-overseas',
		component: FourTravelTipsCardsOverseasComponent
	},
	{
		path: 'maximizing-credit-card-rewards/how-do-cash-back-cards-work',
		component: HowDoCashBackCardsWorkComponent
	},
	{
		path: 'maximizing-credit-card-rewards/how-to-use-a-credit-card',
		component: HowToUseACreditCardComponent
	},
	{
		path: 'maximizing-credit-card-rewards/the-points-guy-credit-card-tips',
		component: ThePointsGuyCreditCardTipsComponent
	},
	{
		path: 'maximizing-credit-card-rewards/travel-credit-card',
		component: TravelCreditCardComponent
	},
	{
		path: 'maximizing-credit-card-rewards/travel-hacks',
		component: TravelHacksComponent
	},
	{
		path: 'maximizing-credit-card-rewards/travel-rewards',
		component: TravelRewardsComponent
	},
	{
		path: 'maximizing-credit-card-rewards/traveling-the-world',
		component: TravelingTheWorldComponent
	},
	{
		path: 'maximizing-credit-card-rewards/using-credit-card-rewards-for-travel',
		component: UsingCreditCardRewardsForTravelComponent
	},
	{
		path: 'maximizing-credit-card-rewards/using-your-credit-card-abroad',
		component: UsingYourCreditCardAbroadComponent
	},
	{
		path: 'maximizing-credit-card-rewards/what-to-know-about-cash-back-credit-cards',
		component: WhatToKnowAboutCashBackCreditCardsComponent
	},											
	{
		path: 'planning-for-the-future',
		component: PlanningForTheFutureComponent
	},
	{
		path: 'planning-for-the-future/employment-credit-check',
		component: EmploymentCreditCheckComponent
	},	
	{
		path: 'planning-for-the-future/financial-literacy-for-kids',
		component: FinancialLiteracyForKidsComponent
	},
	{
		path: 'planning-for-the-future/financial-tips-to-get-ahead',
		component: FinancialTipsToGetAheadComponent
	},
	{
		path: 'planning-for-the-future/five-financial-questions-to-ask-partner',
		component: FiveFinancialQuestionsToAskPartnerComponent
	},
	{
		path: 'planning-for-the-future/getting-a-credit-card-for-kids',
		component: GettingACreditCardForKidsComponent
	},
	{
		path: 'planning-for-the-future/how-does-divorce-affect-your-credit',
		component: HowDoesDivorceAffectYourCreditComponent
	},
	{
		path: 'planning-for-the-future/how-to-pay-for-wedding-season',
		component: HowToPayForWeddingSeasonComponent
	},
	{
		path: 'planning-for-the-future/marriage-and-finances-answers-to-common-questions',
		component: MarriageAndFinancesAnswersToCommonQuestionsComponent
	},
	{
		path: 'planning-for-the-future/new-chip-credit-card-technology',
		component: NewChipCreditCardTechnologyComponent
	},
	{
		path: 'planning-for-the-future/seven-steps-to-financial-health',
		component: SevenStepsToFinancialHealthComponent
	},
	{
		path: 'planning-for-the-future/share-rent-lease-or-buy-a-car-options',
		component: ShareRentLeaseOrBuyACarOptionsComponent
	},
	{
		path: 'planning-for-the-future/should-i-get-a-business-credit-card',
		component: ShouldIGetABusinessCreditCardComponent
	},
	{
		path: 'planning-for-the-future/when-should-i-get-a-credit-card',
		component: WhenShouldIGetACreditCardComponent
	},
	{
		path: 'rebuilding-credit',
		component: RebuildingCreditComponent
	},
	{
		path: 'rebuilding-credit/building-credit-health-after-setback',
		component: BuildingCreditHealthAfterSetbackComponent
	},
	{
		path: 'rebuilding-credit/credit-card-facts',
		component: CreditCardFactsComponent
	},
	{
		path: 'rebuilding-credit/how-to-pay-off-debt',
		component: HowToPayOffDebtComponent
	},
	{
		path: 'rebuilding-credit/improve-credit-health',
		component: ImproveCreditHealthComponent
	},
	{
		path: 'rebuilding-credit/improve-credit-history',
		component: ImproveCreditHistoryComponent
	}
];

@NgModule({
	imports: [
		RouterModule.forChild(routes)
	],
	exports: [RouterModule]
})
export class KnowledgeCenterRoutingModule { }
