import { DDMain } from '../../shared/scripts/dd-main';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { BannerDataModel } from '../../drupal-content-services/models/nodes/banner_data.model';
import { BannerModel } from '../../drupal-content-services/models/paragraphs/banner.model';

import { JsonApiQueryData } from 'angular2-jsonapi';
import { BannerService } from '../../shared/services/banner.service';
import { MockDecision } from '../../mock-test/mock-decision';

@Component({
  selector: 'app-planning-for-the-future',
  templateUrl: './planning-for-the-future.component.html',
  styleUrls: ['./planning-for-the-future.component.css']
})
export class PlanningForTheFutureComponent implements OnInit, AfterViewInit {

  passedData: any;
  mp: MarketingPageModel;
  bd: BannerDataModel;
  ddMain: DDMain;
  mockDecision: MockDecision;
  
  //This is the machine generated uuid for the content item in Drupal
 //private pageId = '655be9b2-03bb-4964-88c2-f78cb40ef8ee';
  //private pageId = '5e294352-44a3-44ae-a762-8f5f9a0ced7f';
  
  private pageFilters = {
    titleFilter: {
      condition: {
        path: 'title',
        value: 'CKC - Planning for the Future'
      }
    }
  };

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  private bannerParameters = {};

  public isLoaded: boolean = false;



  constructor(private bannerService: BannerService, private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.pageFilters,
    };
    this.bannerParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.bannerService.getfilters(),
    };
    this.passedData = {};
    this.mockDecision = new MockDecision('hero');
    this.passedData = this.mockDecision.bannerInfo;
    console.log(this.passedData);
    this.ddMain = new DDMain(this.passedData.contentVars);
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.datastore.findAll(MarketingPageModel, this.queryParameters)
      .subscribe((marketingPage: JsonApiQueryData<MarketingPageModel>) => {
        this.mp = marketingPage.getModels()[0];
        console.log('mktdata', this.mp);
        this.mp.pageType = "category";
        this.isLoaded = true;
      });

    /* TODO: Handling differences when calling Banner via Marketing Page or directly 
       by adding an @Input binding to the Banner component that specifies whether or not
       the Banner content is static (part of the Marketing Page model) or dynamic (part
       of a second call right to that specific Banner item). Might need to clean up this
       implementation, but it works for now. Also, when we move to the updated Drupal site, 
       get content using the filter strategy and not by uuid like we're doing here.
    */ 
      
    this.datastore.findAll(BannerDataModel, this.bannerParameters)
      .subscribe((bannerData: JsonApiQueryData<BannerDataModel>) => {
        this.bd = bannerData.getModels()[0];
        console.log('BannerData', bannerData);
        this.bd.parsedReusableContent = this.ddMain.replaceContentVars(this.bd, this.passedData.contentVars);
      });
  }

}
