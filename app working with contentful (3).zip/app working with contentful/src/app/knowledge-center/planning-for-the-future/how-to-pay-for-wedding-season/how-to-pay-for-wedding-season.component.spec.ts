import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToPayForWeddingSeasonComponent } from './how-to-pay-for-wedding-season.component';

describe('HowToPayForWeddingSeasonComponent', () => {
  let component: HowToPayForWeddingSeasonComponent;
  let fixture: ComponentFixture<HowToPayForWeddingSeasonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToPayForWeddingSeasonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToPayForWeddingSeasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
