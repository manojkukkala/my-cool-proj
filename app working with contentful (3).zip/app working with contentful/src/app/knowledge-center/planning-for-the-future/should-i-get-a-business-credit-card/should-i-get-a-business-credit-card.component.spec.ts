import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShouldIGetABusinessCreditCardComponent } from './should-i-get-a-business-credit-card.component';

describe('ShouldIGetABusinessCreditCardComponent', () => {
  let component: ShouldIGetABusinessCreditCardComponent;
  let fixture: ComponentFixture<ShouldIGetABusinessCreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShouldIGetABusinessCreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShouldIGetABusinessCreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
