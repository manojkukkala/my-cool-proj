import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmploymentCreditCheckComponent } from './employment-credit-check.component';

describe('EmploymentCreditCheckComponent', () => {
  let component: EmploymentCreditCheckComponent;
  let fixture: ComponentFixture<EmploymentCreditCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmploymentCreditCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmploymentCreditCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
