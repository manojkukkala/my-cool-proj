import { Datastore } from '../../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../../../drupal-content-services/drupal-jsonapi.service';
import { ArticlePageModel } from '../../../drupal-content-services/models/nodes/article_page.model';
import { SocialIconsComponent } from '../../../uicomponents-with-content/social-icons/social-icons.component';


@Component({
  selector: 'app-how-to-use-a-credit-card',
  templateUrl: './how-to-use-a-credit-card.component.html',
  styleUrls: ['./how-to-use-a-credit-card.component.css']
})

export class HowToUseACreditCardComponent implements OnInit {

  /**
   * content ID of the article page node
  */
  private pageId = "03e2a746-8252-4f05-87de-3506f3ef4917";
  ap: ArticlePageModel;
  /**
   * JSONAPI include
   */
  private include = '';
/**
  * JSONAPI fields
  */
  private fields = {};
  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }
  ngOnInit() {
    this.datastore.findRecord(ArticlePageModel, this.pageId, this.queryParameters)
      .subscribe((articlePage: ArticlePageModel) => {
        this.ap = articlePage;
        console.log(articlePage);
        this.isLoaded = true;
      });
  }
}
