export class MockDecision{
    public bannerInfo: any;
    public data: any;
    public pageID: string;

    constructor(page: string){
        this.pageID = page;
        if(this.pageID === 'hero'){
            this.data = {
                'Simplicity': {
                    'contentVars': {
                        'var_CardTitle':'Citi Simplicity® Card',
                        'var_introAPR': '0.9',
                        'var_introDuration': '12',
                        'var_purchaseAPRValue': '15.24% - 25.24% variable APR based on your creditworthiness.',
                        'var_Annualfee': '0',
                        'var_BTfee': '$5 or 5% of the amount each transfer, whichever is greater'
                    }
                },
                'Costco':{
                    'contentVars': {
                        'var_CardTitle':'Costco Anywhere Visa Card By Citi',
                        'var_purchaseAPRLow': '16.24',
                        'var_purchaseAPRHigh': '26.74',
                        'var_Annualfee': '0'
                    }
                },
                'DoubleCash':{
                    'contentVars': {
                        'var_CardTitle':'Citi Double Cash Card',
                        'var_introAPR': '0',
                        'var_introDuration': '18',
                        'var_purchaseAPRLow': '14.74',
                        'var_purchaseAPRHigh': '24.76',
                        'var_Annualfee': '0'
                    }
                },
                'AAdvantage':{
                    'contentVars': {
                        'var_CardTitle':'Citi/AAdvantage Platinum Select World Elite Mastercard',
                        'var_purchaseAPRValue': '17.24% - 25.24% variable APR based on your creditworthiness.',
                        'var_Annualfee': '95',
                        'var_rewardValue': '50,000',
                        'var_rewardPurchase': '2,500',
                        'var_rewardDuration': '3',
                        'var_feeWaivedDuration': '12'
                    }
                }
            };
            this.bannerInfo = this.data.Simplicity;
        }
    }        
}