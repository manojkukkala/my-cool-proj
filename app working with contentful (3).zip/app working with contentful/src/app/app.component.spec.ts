import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { CbolCoreModule } from './cbol_core/cbol_core.module';
import { APP_BASE_HREF } from '@angular/common';

jasmine.DEFAULT_TIMEOUT_INTERVAL = 50000;

describe('AppComponent', () => {

	beforeEach(async(() => {

		TestBed.configureTestingModule({
			imports: [CbolCoreModule],
			declarations: [
				AppComponent
			],
			providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
		}).compileComponents();

	}));

	it('true is true', async(() => {
		expect(true).toBe(true);
	}));

	it('should create the app', async(() => {
		const fixture = TestBed.createComponent(AppComponent);
		const component = fixture.debugElement.componentInstance;
		expect(component).toBeTruthy();
	}));

});
