import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FinancialHarmonyComponent } from './financial-harmony/financial-harmony.component';
import { BudgetChecklistComponent } from './budget-checklist/budget-checklist.component';
import { VacationExpensesComponent } from './vacation-expenses/vacation-expenses.component';

export const routes: Routes = [
	{
		path: '',
		redirectTo: 'financial-harmony',
		pathMatch: 'full'
	},
	{
		path: 'financial-harmony',
		component: FinancialHarmonyComponent
	},
	{
		path: 'budgeting-checklist',
		component: BudgetChecklistComponent
	},
	{
		path: 'vacation-expenses',
		component: VacationExpensesComponent
	}
];

@NgModule({
	imports: [
		RouterModule.forChild(routes)
	],
	exports: [RouterModule]
})
export class ArticlesRoutingModule { }
