import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--copy_warning'
})
export class CopyWarningModel extends JsonApiModel {
    @Attribute()
    header: string;

    @Attribute()
    headerType: string;

    @Attribute()
    copyContent: string;

    @Attribute()
    textStyle: string;

    @Attribute()
    border: boolean;

    @HasMany()
    components: JsonApiModel[];

}