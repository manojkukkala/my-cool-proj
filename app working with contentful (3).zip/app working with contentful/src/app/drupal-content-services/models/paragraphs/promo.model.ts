import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--promo'
})
export class PromoModel extends JsonApiModel {
    @Attribute()
    promoCopyText: string;

    @Attribute()
    linkText: string;

    @Attribute()
    promoTheme: string;

    @Attribute()
    promoSubText: string;

    @Attribute()
    secondaryCta: string;    

    @HasMany()
    components: JsonApiModel[];
}