import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { LinkModel } from "../nodes/link.model";


@JsonApiModelConfig({
    type: 'paragraph--breadcrumb'
})
export class BreadcrumbModel extends JsonApiModel {
    @Attribute()
    currentPage: string;

    @HasMany()
    parentPage: LinkModel[];

}