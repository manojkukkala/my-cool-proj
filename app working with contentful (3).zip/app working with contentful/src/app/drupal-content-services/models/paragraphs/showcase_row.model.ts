import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { ColumnDataModel } from '../nodes/column_data.model';

@JsonApiModelConfig({
    type: 'paragraph--showcase_row'
})
export class RowDataModel extends JsonApiModel {
    @HasMany()
    columnData: ColumnDataModel[];

    @Attribute()
    lineDivider: boolean;
}