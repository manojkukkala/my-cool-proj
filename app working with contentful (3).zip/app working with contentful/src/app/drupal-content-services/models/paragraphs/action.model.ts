import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { ActionDataModel } from "../nodes/action_data.model";

@JsonApiModelConfig({
    type: 'paragraph--action'
})
export class ActionModel extends JsonApiModel {
    @Attribute()
    headerText: string;

    @HasMany()
    actionData: ActionDataModel[];

    @HasMany()
    components: JsonApiModel[];
}