import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { BannerDataModel } from "../nodes/banner_data.model";

@JsonApiModelConfig({
    type: 'paragraph--banner'
})
export class BannerModel extends JsonApiModel {

    @BelongsTo()
    bannerData: BannerDataModel;

}