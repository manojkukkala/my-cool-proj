import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
  type: 'alert'
})
export class AlertDataModel extends JsonApiModel {

  @Attribute()
  title: string;

  @Attribute()
  alertTitle: string;

  @Attribute()
  alertBody: string;

  @Attribute()
  alertType: string;

}