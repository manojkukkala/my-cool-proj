import {Component, OnInit, Input} from '@angular/core';
import { AlertDataModel } from 'app/drupal-content-services/models/nodes/alert_data.model';
import { AlertModel } from 'app/drupal-content-services/models/paragraphs/alert.model';
import { Datastore } from '../../drupal-content-services/datastore';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {

  @Input() component: AlertModel;
  @Input() alertData: AlertDataModel; 

  public isAlertHidden: boolean = false;

  public alertClass = 'alert';
  public criticalClass = 'critical';
  public alertBoxClass = 'alert-box';
  public cssClass: string;
  public _enableAlertBackground: boolean = true;
  public _isPageLevelAlert: boolean = false;
  public alertType: string;
  public _disabledBorder: boolean = false;
  
  constructor() {
  }

  // Hides alert once the user clicks to 'x'  
  hideAlert(){
    this.isAlertHidden = true;
  }

  /**
   * @Property: type
   * @Description: Sets the different types of alert. Acceptable values include 'alert', 'critical', and 'alertBox'.
   * @Type: string
   */
  @Input()
  set type(type: any) {
    this.alertType = type;
  }

  /**
   * @Property: enableAlertBackground
   * @Description: Enables/disables the grey background
   * @Type: string
   */
  @Input()
  set enableAlertBackground(value: boolean) {
    this._enableAlertBackground = value;
    this.generateCssClassString();
  }

  /**
   * @Property: isPageLevelAlert
   * @Description: Is this alert is a page level alert
   * @Type: string
   */
  @Input()
  set isPageLevelAlert(value: boolean) {
    this._isPageLevelAlert = value;
    this.generateCssClassString();
  }

  /**
   * @Property: notice
   * @Description: The label 'Alert' notice span is included if this is set to true
   * @Type: Boolean
   */
  @Input()
  notice: boolean = true;

  /**
   * @Property: noticeText
   * @Description: Text to display as a message
   * @Type: string
   */
  @Input()
  noticeText: string;

  /**
   * @Property: noticeText
   * @Description: Text to display as a message
   * @Type: string
   */
  @Input()
  alertText: string = 'Alert!';

  /**
   * @Property: disabledBorder
   * @Description: Disables/enables red left border in an alert box
   * @Type: string
   */
  @Input()
  set disabledBorder(value: boolean) {
    this._disabledBorder = value;
    this.generateCssClassString();
  }

  get disabledBorder() {
    return this._disabledBorder;
  }

  public generateCssClassString() {
    let componentArray: string[] = [];
    let notAlertBoxType = this.alertType !== 'alertBox' && this.alertType !== 'alertBoxSuccess'
      && this.alertType !== 'alertBoxCritical';
    let isAlertBoxType = !notAlertBoxType;
    let isAlertBoxWithIcon = this.alertType === 'alertBoxSuccess' || this.alertType === 'alertBoxCritical';

    if(isAlertBoxType) {
      componentArray.push(this.alertBoxClass);
      // Disables the grey background if required
      if (this._disabledBorder) {
        componentArray.push('no-left-border');
      }
    }
    else {
      componentArray.push(this.alertClass);
    }

    if (isAlertBoxWithIcon) {
      componentArray.push('alert-box-icon');
    }

    if (this._isPageLevelAlert) {
      componentArray.push('alert');
      componentArray.push('page-level-alert');
    }
    else {
      switch (this.alertType) {
        case 'critical':
          componentArray.push(this.criticalClass);
          break;
        case 'alertBoxSuccess':
          componentArray.push('alert-box-success');
          break;
        case 'alertBoxCritical':
          componentArray.push('alert-box-critical');
          break;
      }

      // If the alert type is not alert box but consumers still to want grey background,
      // adds the CSS class for the grey background
      if (notAlertBoxType && this._enableAlertBackground) {
        componentArray.push('theme-gray');
      }
    }

    this.cssClass = componentArray.join(' ');
  }

  ngOnInit() {
    // Alert type determines the Alert icon.
    if (this.component.alertData){
      this.alertType = this.component.alertData.alertType;
    }
    this.generateCssClassString();
  }
}
