import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { PromoModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'promo',
  templateUrl: './promo.component.html',
  styleUrls: ['./promo.component.css']
})
export class PromoComponent implements OnInit {
  @Input() component: PromoModel;

  @Input() promoCopyText: string;
  @Input() linkText: string;
  @Input() promoTheme: string;
  @Input() promoSubText: string;
  @Input() secondaryCta: string;
    
  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }


}