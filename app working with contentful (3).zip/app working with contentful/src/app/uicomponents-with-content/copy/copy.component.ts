import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { CopyModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-copy',
  templateUrl: './copy.component.html',
  styleUrls: ['./copy.component.css']
})
export class CopyComponent implements OnInit {
  @Input() component: CopyModel;

  @Input() columns: string;
  @Input() body: string;
  @Input() listType: string;
  @Input() title: string;
  @Input() listItem: string;
  @Input() listLeft: string;
  @Input() listRight: string;
  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }


}
