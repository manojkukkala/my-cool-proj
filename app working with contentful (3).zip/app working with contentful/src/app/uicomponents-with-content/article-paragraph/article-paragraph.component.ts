import { Component, OnInit, Input, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as _ from 'underscore';
import { ArticleParagraphModel } from '../../drupal-content-services/models/paragraphs';
import { SocialIconModel } from '../../drupal-content-services/models/paragraphs';
import { SocialIconsComponent } from '../../uicomponents-with-content/social-icons/social-icons.component';
import { environment } from 'environments/environment'
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-article-paragraph',
  templateUrl: './article-paragraph.component.html',
  styleUrls: ['./article-paragraph.component.css']
})
export class ArticleParagraphComponent implements OnInit {

  @Input() component: ArticleParagraphModel;

  public env = environment.drupalUrl;
  
  constructor(private element: ElementRef, private _sanitizer: DomSanitizer) { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }

    getStyles() {
    return this._sanitizer.bypassSecurityTrustStyle('left:' + -this.element.nativeElement.offsetLeft + 'px; width:' + document.body.clientWidth + 'px');
  }

}
