import { Injectable } from '@angular/core';
import { createClient, Entry } from 'contentful';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()

export class ContentfulService {
 
  private client = createClient({
    space: environment.contentful.spaceId,
    accessToken: environment.contentful.token
  });

  constructor(private http: HttpClient) { }

  getCourses() {
    return this.client.getEntries()
      .then(res => res.items);
  }

  getCourse(courseId): Promise<Entry<any>> {
    return this.client.getEntries(Object.assign({
      content_type: 'course'
    }, {'sys.id': courseId}))
      .then(res => res.items[0]);
  }



}
