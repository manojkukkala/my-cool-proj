import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { CardModel } from '../../drupal-content-services/models/paragraphs';
import { HeroModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-banking-packages',
  templateUrl: './banking-packages.component.html',
  styleUrls: ['./banking-packages.component.css']
})
export class BankingPackagesComponent implements OnInit {
/**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/146
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "d43d3f33-466e-4e1d-8542-05fcc1370cc3";
  
  /**
   * JSONAPI include
   */
  private include = 'components,components.field_card_name,components.field_feature_one_header,components.field_feature_one_text,components.field_feature_three_header,components.field_feature_three_text,components.field_feature_two_header,components.field_feature_two_text,components.field_list,components.field_list_text,components.field_primary_cta_label,components.field_primary_cta_url,components.field_product,components.field_producttitle';
  
  /**
   * JSONAPI fields
   */
  private fields = {
    'paragraph--card': 'cardName,product,productTitle,featureOneHeader,featureOneText,featureTwoHeader,featureTwoText,isList,listText,featureThreeHeader,featureThreeText,primaryCtaLabel,primaryCtaUrl',
    'paragraph--hero': 'field_hero_type,field_hero_title,field_eyebrow,field_legend,field_subheading_title,field_subheading_legend,field_citigold'
  };
  public components = {
    citigold:'6a8ce8d1-3f09-49ae-8871-785bd82d261a',
    citipriority:'14e14a96-c7ba-40fc-bf83-430195427601',
  };


  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};
    
  public isLoaded: boolean = false;
  public page: any;

  constructor(private drupalJSONAPIService: DrupalJSONAPIService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.drupalJSONAPIService.getDocument(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((document: MarketingPageModel) => {
        console.log(document); // metadata
        this.page = document;
        document.components.forEach(component => {
          if (component instanceof CardModel) {
            _.each(this.components, (v, k) => {
              if (component.id == v) {
                this.components[k] = component;
                console.log(component);
              } 
            });
          }
        });
      this.isLoaded = true;
      });
  }

}

