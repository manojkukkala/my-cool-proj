import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingPackagesHeroComponent } from './banking-packages-hero.component';

describe('BankingPackagesHeroComponent', () => {
  let component: BankingPackagesHeroComponent;
  let fixture: ComponentFixture<BankingPackagesHeroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingPackagesHeroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingPackagesHeroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
