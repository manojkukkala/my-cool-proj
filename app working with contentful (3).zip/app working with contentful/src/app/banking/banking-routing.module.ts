
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BankingComponent } from './banking.component';
import { CitigoldPackageComponent } from './citigold-package/citigold-package.component';
import { SimpleCheckingComponent } from './simple-checking/simple-checking.component';
import { CitiPriorityPackageComponent } from './citi-priority-package/citi-priority-package.component';
import { BankingPackagesComponent } from './banking-packages/banking-packages.component';

export const routes: Routes = [
	{
		path: '',
		redirectTo: 'index',
		pathMatch: 'full'
	},
	{
		path: 'index',
		component: BankingComponent
	},
	{
		path: 'citigold-package',
		component: CitigoldPackageComponent
	},
	{
		path: 'simple-checking',
		component: SimpleCheckingComponent
	},
	{
		path: 'citi-priority-package',
		component: CitiPriorityPackageComponent
	},
		{
		path: 'banking-packages',
		component: BankingPackagesComponent
	}
];

@NgModule({
	imports: [
		RouterModule.forChild(routes)
	],
	exports: [RouterModule]
})
export class BankingRoutingModule { }
