let gulp = require('gulp');
let cmd_executor = require('./gulp-cmd-executor');
let configFile = require('./package.ng.json');
let srcpath = configFile.dependencies.options.containerProjectPath;

gulp.task('update',()=>{
  cmd_executor.execute();
});
gulp.task('install',()=>{
  cmd_executor.execute();
});

gulp.task('test',()=>{
	console.log('inside test task!');
});

gulp.task('update-base-project',['copy-app-config-files',
                                  'copy-angular-cli.json',
                                  'copy-src-config-files',
                                  'copy-cbol-core-module',
                                  'copy-cbol-home-module',
                                  'copy-app-module',
                                  'copy-environment-module',
                                  'copy-assets-module']
         );

gulp.task('copy-app-config-files',()=>{
   gulp
   .src(srcpath+'/*.{json,js,md}')
   .pipe(gulp.dest(__dirname));

});
gulp.task('copy-angular-cli.json',()=>{
	gulp
   .src(srcpath+'/.angular-cli.json')
   .pipe(gulp.dest(__dirname));
});

gulp.task('copy-src-config-files',()=>{
	gulp
	.src(srcpath+'/src/*.{ico,html,ts,css,json}')
	.pipe(gulp.dest(__dirname+'/src/'));
});

gulp.task('copy-cbol-core-module',()=>{
	gulp
	.src(srcpath+'/src/app/cbol_core/**/*')
	.pipe(gulp.dest(__dirname+'/src/app/cbol_core'));
});

gulp.task('copy-cbol-home-module',()=>{
	gulp
	.src(srcpath+'/src/app/home/**/*')
	.pipe(gulp.dest(__dirname+'/src/app/home'));
});

gulp.task('copy-app-module',()=>{
	gulp
	.src(srcpath+'/src/app/*.{css,ts,html}')
	.pipe(gulp.dest(__dirname+'/src/app/'));
});

gulp.task('copy-environment-module',()=>{
	gulp
	.src(srcpath+'/src/environments/*.{css,ts,html}')
	.pipe(gulp.dest(__dirname+'/src/environments/'));
});

gulp.task('copy-assets-module',()=>{
	gulp
	.src(srcpath+'/src/assets/**/*')
	.pipe(gulp.dest(__dirname+'/src/assets/'));
});
