var userSessionId ='', ccsId ='', encrString ='', initVecString ='',keyString = '',signString='';
function getData2()
{
  return userSessionId;
};
function getData1() { 
    return {
      "p": [ccsId] };
};
function getPollData(encryptedResult, initalizationVector, keyID, signature) {  
        encrString=encryptedResult;initVecString=initalizationVector;keyString=keyID;signString=signature;
}