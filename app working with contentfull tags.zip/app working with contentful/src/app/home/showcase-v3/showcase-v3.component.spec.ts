import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowcaseV3Component } from './showcase-v3.component';

describe('ShowcaseV3Component', () => {
  let component: ShowcaseV3Component;
  let fixture: ComponentFixture<ShowcaseV3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowcaseV3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowcaseV3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
