import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IndexComponent } from './index.component';
import { ShowcaseV1Component } from "./showcase-v1/showcase-v1.component";
import { ShowcaseV2Component } from "./showcase-v2/showcase-v2.component";
import { ShowcaseV3Component } from "./showcase-v3/showcase-v3.component";
import { CardComponent } from "./card/card.component";
import { CardComponentV2 } from "./card-v2/card-v2.component";
import { CitigoldPackageComponent } from './banking-products/citigold-package/citigold-package.component';
import { CitiPriorityComponent } from './banking-products/citi-priority/citi-priority.component';
import { BankingProductsComponent } from './banking-products/banking-products.component';
import { BankingHeroComponent } from './banking-products/banking-hero/banking-hero.component';
import { BankWithCitiComponent } from './banking-products/bank-with-citi/bank-with-citi.component';

export const routes: Routes = [
	{
		path: '',
		redirectTo: 'index',
		pathMatch: 'full'
	},
	{
		path: 'index',
		component: IndexComponent
	},
	{
		path: 'showcase',
		component: ShowcaseV1Component
	},
	{
		path: 'showcase2',
		component: ShowcaseV2Component
	},
	{
		path: 'showcase3',
		component: ShowcaseV3Component
	},
	{
		path: 'card',
		component: CardComponent
	},
	{
		path: 'citigold',
		component: CitigoldPackageComponent
	},
	{
		path: 'priority',
		component: CitiPriorityComponent
	},
	{
		path: 'banking',
		component: BankingProductsComponent
	}
];
@NgModule({
	imports: [
		RouterModule.forChild(routes)
	],
	exports: [RouterModule]
})
export class HomeRoutingModule { }
