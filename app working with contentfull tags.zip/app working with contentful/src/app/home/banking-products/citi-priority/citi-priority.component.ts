import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citi-priority',
  templateUrl: './citi-priority.component.html',
  styleUrls: ['./citi-priority.component.css']
})
export class CitiPriorityComponent implements OnInit {

priority: object = [{ 
    "cardName":"Card 1",
    "product":"citipriority",
    "productTitle":"Citi Priority Package",
    "featureOneHeader": "Priority Banking with Dedicated Support",
    "featureOneText": "",
    "featureTwoHeader": "",
    "featureTwoText": "Professional strategies and guidance from a Citi Personal Wealth Management Financial Advisor by phone",
    "featureThreeHeader":"To waive the $30 monthly service fee",
    "featureThreeText": "Maintain a combined average monthly balance of $50,000+ in eligible linked deposit, retirement and investment accounts",
    "primaryCtaLabel":"See details",
    "primaryCtaURL":"https://online.citi.com/US/banking/checking/citi.action?ID=citigold"
}]

  constructor() { }

  ngOnInit() {
  }

}
