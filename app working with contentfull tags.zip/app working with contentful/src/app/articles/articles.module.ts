import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreCommonModule } from 'angular-nexus-uiux';
import { CitiModule } from 'uicomponents/citi.module';
import { AmwModule } from 'angular-container-common/amw';

import { UIComponentsWithContentModule } from '../uicomponents-with-content/uicomponents-with-content.module';
import { ArticlesRoutingModule } from "./articles-routing.module";
import { ArticlesComponent } from "app/articles/articles.component";
import { FinancialHarmonyComponent } from "app/articles/financial-harmony/financial-harmony.component";
import { BudgetChecklistComponent } from './budget-checklist/budget-checklist.component';
import { VacationExpensesComponent } from './vacation-expenses/vacation-expenses.component';

@NgModule({
  imports: [
		CoreCommonModule,
		CitiModule,
		AmwModule,
    ArticlesRoutingModule,
    UIComponentsWithContentModule
  ],
  declarations: [ArticlesComponent, FinancialHarmonyComponent, BudgetChecklistComponent, VacationExpensesComponent]
})
export class ArticlesModule { }
