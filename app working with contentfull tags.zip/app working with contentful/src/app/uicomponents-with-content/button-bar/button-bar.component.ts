import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { ButtonBarModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-button-bar',
  templateUrl: './button-bar.component.html',
  styleUrls: ['./button-bar.component.css']
})
export class ButtonBarComponent implements OnInit {
  @Input() component: ButtonBarModel;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }

}
