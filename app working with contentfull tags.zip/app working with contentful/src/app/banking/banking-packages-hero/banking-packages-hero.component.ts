import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { HeroModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-banking-packages-hero',
  templateUrl: './banking-packages-hero.component.html',
  styleUrls: ['./banking-packages-hero.component.css']
})
export class BankingPackagesHeroComponent implements OnInit {
/**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/146
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "f06bdf08-3b92-487f-9b05-667dd6b14785";
  
  /**
   * JSONAPI include
   */
  private include = 'components';
  
  /**
   * JSONAPI fields
   */
  private fields = {
    'paragraph--hero': 'field_hero_type,field_hero_title,field_eyebrow,field_legend,field_subheading_title,field_subheading_legend,field_citigold,field_promo_image'
  };
  public components = {
    bankingPackagesHero:'bfa1da5b-08f9-45f0-9cce-2a63a878e5dc'
    };


  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};
    
  public isLoaded: boolean = false;

  constructor(private drupalJSONAPIService: DrupalJSONAPIService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.drupalJSONAPIService.getDocument(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((document: MarketingPageModel) => {
        console.log(document); // metadata
        document.components.forEach(component => {
          if (component instanceof HeroModel) {
            _.each(this.components, (v, k) => {
              if (component.id == v) {
                this.components[k] = component;
                console.log(component);
              } 
            });
          }
        });
      this.isLoaded = true;
      });
  }

}
