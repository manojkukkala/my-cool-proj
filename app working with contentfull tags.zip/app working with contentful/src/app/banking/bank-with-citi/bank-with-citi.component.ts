import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { CopyModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-bank-with-citi',
  templateUrl: './bank-with-citi.component.html',
  styleUrls: ['./bank-with-citi.component.css']
})
export class BankWithCitiComponent implements OnInit {

  /**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/146
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "71c91d3c-dee9-48a2-9839-794352a0712a";
  
  /**
   * JSONAPI include
   */
  private include = 'components';
  
  /**
   * JSONAPI fields
   */
  private fields = {
    'paragraph--copy': 'listType,title,listItem'
  };
  public components = {
    bankWithCiti:'87a556d9-900e-4c7f-8a5f-eb75bd6fda6e'
  };


  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};
    
  public isLoaded: boolean = false;

  constructor(private drupalJSONAPIService: DrupalJSONAPIService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.drupalJSONAPIService.getDocument(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((document: MarketingPageModel) => {
        console.log(document); // metadata
        document.components.forEach(component => {
          if (component instanceof CopyModel) {
            _.each(this.components, (v, k) => {
              if (component.id == v) {
                this.components[k] = component;
                console.log(component);
              } 
            });
          }
        });
      this.isLoaded = true;
      });
  }

}