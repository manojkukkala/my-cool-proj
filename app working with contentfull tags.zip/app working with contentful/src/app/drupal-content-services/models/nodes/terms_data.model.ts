import { JsonApiModelConfig, JsonApiModel, Attribute } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'terms'
})
export class TermsDataModel extends JsonApiModel {

    @Attribute()
    body: string;
    
}