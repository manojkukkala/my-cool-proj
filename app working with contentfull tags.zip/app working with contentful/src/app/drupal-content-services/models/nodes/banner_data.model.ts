import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
import { FileDataModel } from '../nodes/file.model';

@JsonApiModelConfig({
    type: 'banner'
})
export class BannerDataModel extends JsonApiModel {

    @BelongsTo()
    bannerImg: FileDataModel;

    @Attribute()
    imageSide: string;

    @Attribute()
    eyebrowText: string;

    @Attribute()
    headerText: string;

    @Attribute()
    descriptionText: string;

    @Attribute()
    bannerLink: Link;

}