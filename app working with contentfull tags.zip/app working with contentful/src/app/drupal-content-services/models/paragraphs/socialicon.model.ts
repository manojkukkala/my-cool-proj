import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--social_icon'
})
export class SocialIconModel extends JsonApiModel {
    @Attribute()
    iconType: string;

    @Attribute()
    iconURL: string;

    @HasMany()
    components: JsonApiModel[];
}