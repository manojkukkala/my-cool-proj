import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--button'
})
export class ButtonModel extends JsonApiModel {
    @Attribute()
    button_label: string;

    @Attribute()
    button_link: string;

    @Attribute()
    button_as_link: boolean;
}