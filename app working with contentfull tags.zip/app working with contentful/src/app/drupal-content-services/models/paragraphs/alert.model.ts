import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { AlertDataModel } from "../nodes/alert_data.model";

@JsonApiModelConfig({
    type: 'paragraph--alert'
})
export class AlertModel extends JsonApiModel {

    @BelongsTo()
    alertData: AlertDataModel;  

}