import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class NonFatalErrorRedirectService {
	constructor(private route: Router) { }

	navigateToErrorPage(errorType) {
		this.route.navigateByUrl('/error?errorCode=' + errorType);

	}
}
