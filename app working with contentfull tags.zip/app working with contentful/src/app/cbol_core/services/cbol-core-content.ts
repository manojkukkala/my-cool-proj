export class CbolCoreContent {
    static readonly en_US: Object = {
            "copy$$SessionTimeOut": {
                "GROUP_TYPE": "Container",
                "SET_NOTIFICATION": "N",
                "SiteCatPageName": "Sign On Help - Bank Reset Password",
                "TimeOut": "Due to inactivity, your session will expire in:",
                "Minutes" : "minute(s)",
                "Seconds" : "second(s)",
                "Action": "If additional time is required, please click \"Continue Session\". To allow the session to end, click \"End\"",
                "PrimaryButtonText": "Continue",
                "CancelButtonText": "End",
                "Headline" : "Session Time-Out"
            }
    }
    static readonly es_US: Object = {
            "copy$$SessionTimeOut": {
                "GROUP_TYPE": "Container",
                "SET_NOTIFICATION": "N",
                "SiteCatPageName": "Sign On Help - Bank Reset Password",
                "TimeOut": "Tu sesi�n expirar� por falta de actividad en:",
                "Minutes" : "minuto(s)",
                "Seconds" : "segundo(s)",
                "Action": "If additional time is required please click \"Continue Session\". To allow the session to end click \"End\"",
                "PrimaryButtonText": "Continuar",
                "CancelButtonText": "End",
                "Headline" : "Expiraci�n de Sesi�n"
            }
    }
}   