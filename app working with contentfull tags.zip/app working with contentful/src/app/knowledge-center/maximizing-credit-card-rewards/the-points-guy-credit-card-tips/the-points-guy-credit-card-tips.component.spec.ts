import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThePointsGuyCreditCardTipsComponent } from './the-points-guy-credit-card-tips.component';

describe('ThePointsGuyCreditCardTipsComponent', () => {
  let component: ThePointsGuyCreditCardTipsComponent;
  let fixture: ComponentFixture<ThePointsGuyCreditCardTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThePointsGuyCreditCardTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThePointsGuyCreditCardTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
