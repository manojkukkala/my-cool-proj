import { Component, OnInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { JsonApiQueryData } from 'angular2-jsonapi';


@Component({
  selector: 'app-maximizing-credit-card-rewards',
  templateUrl: './maximizing-credit-card-rewards.component.html',
  styleUrls: ['./maximizing-credit-card-rewards.component.css']
})
export class MaximizingCreditCardRewardsComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  //private pageId = "40b16a18-a961-4cdf-a3a0-afdf45cbcad9";

  private pageFilters = {
    titleFilter: {
      condition: {
        path: 'title',
        value: 'Maximizing Credit Card Rewards'
      }
    }
  };

  mp: MarketingPageModel;

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.pageFilters,
    }
  }

  ngOnInit() {
    this.datastore.findAll(MarketingPageModel, this.queryParameters)
      .subscribe((marketingPage: JsonApiQueryData<MarketingPageModel>) => {
        this.mp = marketingPage.getModels()[0];
        console.log('mktdata',this.mp);
        this.mp.pageType = "category";
        this.isLoaded = true;
      });
  }

}
