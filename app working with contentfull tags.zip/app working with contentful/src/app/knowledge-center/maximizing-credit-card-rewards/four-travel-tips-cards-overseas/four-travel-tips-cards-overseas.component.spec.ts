import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FourTravelTipsCardsOverseasComponent } from './four-travel-tips-cards-overseas.component';

describe('FourTravelTipsCardsOverseasComponent', () => {
  let component: FourTravelTipsCardsOverseasComponent;
  let fixture: ComponentFixture<FourTravelTipsCardsOverseasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FourTravelTipsCardsOverseasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FourTravelTipsCardsOverseasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
