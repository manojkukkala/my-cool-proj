import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelCreditCardComponent } from './travel-credit-card.component';

describe('TravelCreditCardComponent', () => {
  let component: TravelCreditCardComponent;
  let fixture: ComponentFixture<TravelCreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelCreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelCreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
