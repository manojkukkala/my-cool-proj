import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareRentLeaseOrBuyACarOptionsComponent } from './share-rent-lease-or-buy-a-car-options.component';

describe('ShareRentLeaseOrBuyACarOptionsComponent', () => {
  let component: ShareRentLeaseOrBuyACarOptionsComponent;
  let fixture: ComponentFixture<ShareRentLeaseOrBuyACarOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShareRentLeaseOrBuyACarOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareRentLeaseOrBuyACarOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
