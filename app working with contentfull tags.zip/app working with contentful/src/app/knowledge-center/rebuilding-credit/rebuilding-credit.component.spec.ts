import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RebuildingCreditComponent } from './rebuilding-credit.component';

describe('RebuildingCreditComponent', () => {
  let component: RebuildingCreditComponent;
  let fixture: ComponentFixture<RebuildingCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RebuildingCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RebuildingCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
