import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToCheckACreditReportComponent } from './how-to-check-a-credit-report.component';

describe('HowToCheckACreditReportComponent', () => {
  let component: HowToCheckACreditReportComponent;
  let fixture: ComponentFixture<HowToCheckACreditReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToCheckACreditReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToCheckACreditReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
