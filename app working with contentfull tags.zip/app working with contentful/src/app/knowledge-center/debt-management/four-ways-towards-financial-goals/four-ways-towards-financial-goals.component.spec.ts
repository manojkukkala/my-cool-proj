import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FourWaysTowardsFinancialGoalsComponent } from './four-ways-towards-financial-goals.component';

describe('FourWaysTowardsFinancialGoalsComponent', () => {
  let component: FourWaysTowardsFinancialGoalsComponent;
  let fixture: ComponentFixture<FourWaysTowardsFinancialGoalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FourWaysTowardsFinancialGoalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FourWaysTowardsFinancialGoalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
