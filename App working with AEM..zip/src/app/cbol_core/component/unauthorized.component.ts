import { Component } from '@angular/core';

@Component({
	template: ''
})
export class UnauthorizedComponent {
	constructor() {
		window.location.href = 'US/JPS/portal/Unauthorized.do';
	}
}
