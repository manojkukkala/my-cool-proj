import { Injectable } from '@angular/core';
import { Response, Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

const configUrl = '/config';

@Injectable()
export class CbolCoreConfigService {

	private _config: any;

	constructor(private http: Http) { }

	/*public load(): Promise<any> {

		this._config = null;

		const headers = new Headers(environment.httpService.defaultHeaders);
		headers.set('channelId', 'AG');

		const requestOptions = new RequestOptions({
			headers: headers
		});
		return this.http
			.get(environment.apiServerUrl + configUrl, requestOptions)
			.map((res: Response) => res.json())
			.toPromise()
			.then((data: any) => this._config = data['US_GCB_AG'])
			.catch((err: any) => {
				console.log('error');
				Promise.resolve()
			});
	}*/

	public load(): any {
		//(jk63657) 01/23/18 Disabling service by making the load() method just log a string to the console.
		console.log('Cbol core config service disabled');
	}

	get config(): any {
		return this._config;
	}

	getConfigForKey(key: string): any {
		return this._config[key];
	}
}
