import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';

import { DrupalJSONAPIService } from '../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../drupal-content-services/models/nodes/marketing_page.model';
import { ButtonModel, ActionModel } from '../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-articles',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.css']
})
export class ArticlesComponent implements OnInit {



  /**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/146
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "9f891d9d-372f-40af-8e38-01e3149cc4b2";

  /**
   * JSONAPI include
   */
  private include = 'components,components.field_para_component';


  /**
   * JSONAPI fields
   */
  private fields = {
    'paragraph--action': 'body,buttons,title',
    'paragraph--button': 'button_as_link,button_label,button_link'
  };


  /**
   * Merge all query paramters in queryParamters
   */
  private queryParamters = {};


  public document: MarketingPageModel;

  constructor(private drupalJSONAPIService: DrupalJSONAPIService) {
    this.queryParamters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.drupalJSONAPIService.getDocument(MarketingPageModel, this.pageId, this.queryParamters)
      .subscribe((document: MarketingPageModel) => {
        this.document = document;
      });
  }
}
