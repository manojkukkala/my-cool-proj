import { Injectable } from '@angular/core';

@Injectable()
export class FaqfilterService {
    public data: any;
    public data1: any;
    constructor() {
        this.data1=[    
        { id: 'faqtags:CitiMobileSnapshot', itemName: 'CitiMobileSnapshot' },
        { id: 'faqtags:AppleWatchDevice', itemName: 'AppleWatchDevice' },
        { id: 'faqtags:Browser', itemName: 'Browser'},
        { id: 'faqtags:Rewards', itemName: 'Rewards'}
    
    
    
    ]
        this.data = { 
            
              Rewards:'5uzjonOvTOM2SE2KkcmoA0',
              Browser:'1JYLFoD4OsywIO88wQQMwa',
              Investments:'3zdh9lTZRmMSMC2WQMgksQ',
              iOS:'4QuSAna78Q64KkC0eeOAi2',
          // Filter by single Taxonomy term        
            // 'AppleWatchDevicetag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                     
            //             'value': 'Apple Watch Device'                
            //         }
            //     }
            // },
            // 'CitiMobileSnapshottag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Citi Mobile® Snapshot'                
            //         }
            //     }
            // },
            // 'FICOScoretag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'FICO Score'                
            //         }
            //     }
            // },
            // 'Investmentstag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Investments'                
            //         }
            //     }
            // },
            // 'MobileCheckDeposittag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Mobile Check Deposit'                
            //         }
            //     }
            // },
            // 'Rewardstag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Rewards'                
            //         }
            //     }
            // },
            // 'SignOntag': { /*Sign on*/
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Sign On'                
            //         }
            //     }
            // },
            // 'Statementstag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Statements'                
            //         }
            //     }
            // },
            // 'TrustedIdentitytag': {
            //     'tagFilter': {
            //         'condition': {
            //             'path': 'field_content_tags.name',                        
            //             'value': 'Trusted Identity'                
            //         }
            //     }
            // },
            // inFilter: {
            //     decisionFilter: {                
            //         path: 'field_content_tags.name',                
            //         value: ['Android','iOS','All Customers'],                
            //         operator: 'IN'                    
            //     }                
            // }
        };
    };
    // Default filter
    getfilters = () =>{  
        //  return this.data.inFilter;        
        let filterData =  this.data.inFilter; 
        if(filterData){
            return filterData;
        }else{
            return this.data.SignOntag;
        }
    };
}