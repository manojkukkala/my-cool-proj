import { Datastore } from '../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { JsonApiQueryData } from 'angular2-jsonapi';

@Component({
  selector: 'app-how-to-build-credit',
  templateUrl: './how-to-build-credit.component.html',
  styleUrls: ['./how-to-build-credit.component.css']
})
export class HowToBuildCreditComponent implements OnInit {

  //This is the machine generated node id for the content item in Drupal
  //private pageId = "5e361a27-8bd7-4d06-81af-5f8e5316b093";

  private pageFilters = {
    titleFilter: {
      condition: {
        path: 'title',
        value: 'CKC - How to Build Credit'
      }
    }
  };
  
  mp: MarketingPageModel;

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.pageFilters,
    }
  }

  ngOnInit() {
    this.datastore.findAll(MarketingPageModel, this.queryParameters)
      .subscribe((marketingPage: JsonApiQueryData<MarketingPageModel>) => {
        this.mp = marketingPage.getModels()[0];
        console.log('mktdata',this.mp);
        this.mp.pageType = "category";
        this.isLoaded = true;
      });
  }
}
