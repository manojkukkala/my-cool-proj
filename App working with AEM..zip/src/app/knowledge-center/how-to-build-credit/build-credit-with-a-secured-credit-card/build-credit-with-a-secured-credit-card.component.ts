import { Datastore } from '../../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../../../drupal-content-services/drupal-jsonapi.service';
import { ArticlePageModel } from '../../../drupal-content-services/models/nodes/article_page.model';
import { SocialIconsComponent } from '../../../uicomponents-with-content/social-icons/social-icons.component';


@Component({
  selector: 'app-build-credit-with-a-secured-credit-card',
  templateUrl: './build-credit-with-a-secured-credit-card.component.html',
  styleUrls: ['./build-credit-with-a-secured-credit-card.component.css']
})
export class BuildCreditWithASecuredCreditCardComponent implements OnInit {

  /**
   * content ID of the article page node
  */
  private pageId = "c57c3ec3-5061-43e2-b165-924e3e5dd5f3";

  ap: ArticlePageModel;
  /**
   * JSONAPI include
   */
  private include = '';
/**
  * JSONAPI fields
  */
  private fields = {};
  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }
  ngOnInit() {
    this.datastore.findRecord(ArticlePageModel, this.pageId, this.queryParameters)
      .subscribe((articlePage: ArticlePageModel) => {
        this.ap = articlePage;
        console.log(articlePage);
        this.isLoaded = true;
      });
  }
}
