import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildCreditWithASecuredCreditCardComponent } from './build-credit-with-a-secured-credit-card.component';

describe('BuildCreditWithASecuredCreditCardComponent', () => {
  let component: BuildCreditWithASecuredCreditCardComponent;
  let fixture: ComponentFixture<BuildCreditWithASecuredCreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildCreditWithASecuredCreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildCreditWithASecuredCreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
