import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedCreditCardsProsAndConsComponent } from './shared-credit-cards-pros-and-cons.component';

describe('SharedCreditCardsProsAndConsComponent', () => {
  let component: SharedCreditCardsProsAndConsComponent;
  let fixture: ComponentFixture<SharedCreditCardsProsAndConsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedCreditCardsProsAndConsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedCreditCardsProsAndConsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
