import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaximizingCreditCardRewardsComponent } from './maximizing-credit-card-rewards.component';

describe('MaximizingCreditCardRewardsComponent', () => {
  let component: MaximizingCreditCardRewardsComponent;
  let fixture: ComponentFixture<MaximizingCreditCardRewardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaximizingCreditCardRewardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaximizingCreditCardRewardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
