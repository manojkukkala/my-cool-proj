import { Datastore } from '../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';

import { DrupalJSONAPIService } from '../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../drupal-content-services/models/nodes/marketing_page.model';
import { ShowcaseComponent } from '../uicomponents-with-content/showcase/showcase.component';

import { ContentfulService } from '../contentful-services/contentful.service';
import { connectableObservableDescriptor } from 'rxjs/observable/ConnectableObservable';


import { AemService } from "../Aem-services/aem.service";
@Component({
  selector: 'app-knowledge-center',
  templateUrl: './knowledge-center.component.html',
  styleUrls: ['./knowledge-center.component.css']
})
export class KnowledgeCenterComponent implements OnInit {
  content;


  //This is the machine generated node id for the content item in Drupal
  private pageId = "f548bba3-1424-41cb-adb1-27dbff28943b";

  mp: MarketingPageModel;
  cf;


  aem;
  showcase;
  ActionType;
  BannerType;
  Hero;
  Announcements;
  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};
   
  version;
  //Merge all query paramters in queryParamters
  private queryParameters = {};
  id;
  public isLoaded: boolean = false;

  constructor(private datastore: Datastore,private contentfulService :ContentfulService,
    private Aemservice: AemService) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }

  ngOnInit() {
    this.contentfulService.getCourses()
    .then(faqDs => {
      let data = faqDs.filter(_marketPage =>{
        return _marketPage.sys.contentType.sys.id === "marketingPage"
      })
      this.cf = data[0].fields;
      this.version = this.cf.actionType.fields.version[0]
      // this.id = data[0].sys.id;
      this.isLoaded = true;
    })
    this.getAem()
    // this.datastore.findRecord(MarketingPageModel, this.pageId, this.queryParameters)
    //   .subscribe((marketingPage: MarketingPageModel) => {
    //     this.mp = marketingPage;
    //     console.log("marketing page",marketingPage);
    //     this.isLoaded = true;
    //   });
 }

 getAem() {

  this.content = [];
  this.Aemservice.getcardData().subscribe(data => {
    console.log("content", data)
    this.aem = data[":items"].root[':items']
    this.version = 'Version 4'
    console.log("---", this.aem)
    
    let content = []
    let banner = []
    let action = []
    let hero = []
    let announcement=[]
          for (let element in this.aem) {
        if (this.aem[element].elements.headerImg) {
          content.push(this.aem[element]);     
        }
        if (this.aem[element].elements.action_title) {
          action.push(this.aem[element]);     
        }
        if (this.aem[element].elements.banner_link_title) {
          banner.push(this.aem[element]); 
        }
        if (this.aem[element].elements.field_hero_type) {
          hero.push(this.aem[element]); 
        }
        if(this.aem[element].elements.announcements){
          announcement.push(this.aem[element])
        }
      }
    this.showcase=content
    this.ActionType= action
    this.BannerType= banner[0]
    this.Hero=hero[0]
    this.Announcements=announcement
console.log("hero ckc",this.Announcements)

  })
}
}

