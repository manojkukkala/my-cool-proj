import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagingYourMoneyLifestyleComponent } from './managing-your-money-lifestyle.component';

describe('ManagingYourMoneyLifestyleComponent', () => {
  let component: ManagingYourMoneyLifestyleComponent;
  let fixture: ComponentFixture<ManagingYourMoneyLifestyleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagingYourMoneyLifestyleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagingYourMoneyLifestyleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
