import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTheMostFromYourCreditCardComponent } from './get-the-most-from-your-credit-card.component';

describe('GetTheMostFromYourCreditCardComponent', () => {
  let component: GetTheMostFromYourCreditCardComponent;
  let fixture: ComponentFixture<GetTheMostFromYourCreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTheMostFromYourCreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTheMostFromYourCreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
