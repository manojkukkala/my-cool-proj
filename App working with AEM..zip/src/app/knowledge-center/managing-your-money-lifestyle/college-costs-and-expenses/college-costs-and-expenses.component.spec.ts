import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollegeCostsAndExpensesComponent } from './college-costs-and-expenses.component';

describe('CollegeCostsAndExpensesComponent', () => {
  let component: CollegeCostsAndExpensesComponent;
  let fixture: ComponentFixture<CollegeCostsAndExpensesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollegeCostsAndExpensesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollegeCostsAndExpensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
