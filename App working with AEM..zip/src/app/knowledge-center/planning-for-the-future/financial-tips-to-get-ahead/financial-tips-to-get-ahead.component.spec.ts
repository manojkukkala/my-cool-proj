import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialTipsToGetAheadComponent } from './financial-tips-to-get-ahead.component';

describe('FinancialTipsToGetAheadComponent', () => {
  let component: FinancialTipsToGetAheadComponent;
  let fixture: ComponentFixture<FinancialTipsToGetAheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialTipsToGetAheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialTipsToGetAheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
