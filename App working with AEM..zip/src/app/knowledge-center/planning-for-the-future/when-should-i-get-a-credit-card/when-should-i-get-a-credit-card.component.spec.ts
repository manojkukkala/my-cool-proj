import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhenShouldIGetACreditCardComponent } from './when-should-i-get-a-credit-card.component';

describe('WhenShouldIGetACreditCardComponent', () => {
  let component: WhenShouldIGetACreditCardComponent;
  let fixture: ComponentFixture<WhenShouldIGetACreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhenShouldIGetACreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhenShouldIGetACreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
