import { Injectable } from '@angular/core';
import { Response } from "@angular/http";
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs/operators';
@Injectable()

export class AemService {

  ckc_url = "http://citibank-dev1.adobecqms.net/content/we-retail/language-masters/en/api/ckc-home.model.json?foo"

  api = "https://citibank-dev1.adobecqms.net/content/we-retail/us/en/faq-page.model.json"
  constructor(private http: HttpClient) { }


  getdata() {
    return this.http.get(this.api, { responseType: "json" }).map((response: Response) => response);
  }


  getcardData() {
    console.log(this.ckc_url)
    return this.http.get(this.ckc_url, { responseType: "json" }).map((response: Response) => response);
  }
}