import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitiPriorityPackageComponent } from './citi-priority-package.component';

describe('CitiPriorityPackageComponent', () => {
  let component: CitiPriorityPackageComponent;
  let fixture: ComponentFixture<CitiPriorityPackageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitiPriorityPackageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitiPriorityPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
