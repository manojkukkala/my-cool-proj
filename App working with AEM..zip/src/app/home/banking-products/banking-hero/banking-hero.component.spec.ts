import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingHeroComponent } from './banking-hero.component';

describe('BankingHeroComponent', () => {
  let component: BankingHeroComponent;
  let fixture: ComponentFixture<BankingHeroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingHeroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingHeroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
