import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banking-hero',
  templateUrl: './banking-hero.component.html',
  styleUrls: ['./banking-hero.component.css']
})
export class BankingHeroComponent implements OnInit {

  bankinghero: object = [{
    "heroBackgroundImage": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_Hero.jpg",
    "heroTitle": "Banking With Citi",
    "heroPrimaryText": "Smart technology. Convenient access. Easy account management. With Citi, you get more than just a bank account — you get a package of services and benefits to meet your banking needs.",
    "heroSecondaryImage": "",
    "heroSecondaryImageAlt": "",
    "heroSecondaryTitle": "Earn Up To $500",
    "heroSecondaryText": "Choose which checking account is right for you. Open a new checking account and complete qualifying activities",
    "heroPrimaryCtaLabel": "Learn More",
    "heroPrimaryCtaURL": "https://banking.citibank.com/cbol/17/checking/combo-offer/default.htm?Promo_ID=CZ4N&intc=1~1~52~6~BANR~2~MChckHeader_081017&BT_TX=1&ProspectID=2ACB93AF826D4A3FA45065FA62F66995",
    "heroSecondaryCtaLabel": "",
    "heroSecondaryCtaURL": ""
  }]
  constructor() { }

  ngOnInit() {
  }

}
