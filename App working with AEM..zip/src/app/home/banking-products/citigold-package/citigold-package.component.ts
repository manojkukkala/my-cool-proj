import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citigold-package',
  templateUrl: './citigold-package.component.html',
  styleUrls: ['./citigold-package.component.css']
})
export class CitigoldPackageComponent implements OnInit {

  promo: object = [
    {
    "promoText": "Invest and bank with ease using the new Citigold experience in the Citi Mobile® app for iPhone®",
    "promoCtaLabel": "Details",
    "promoCtaURL":"https://online.citi.com/US/login.do"
  }
]

  card: object = [{ 
    "moduleName":"Card 1",
    "product":"citigold",
    "productTitle":"Citigold® Package",
    "featureOne": [{
        "header":"Banking and Wealth Management",
        "list": false,
            "featureOneText": [{
                "text":""},
                {
                "text": "" }]
                }],
    "featureTwo": [{
        "header":"",
        "list": true,
            "featureTwoText": [{
                "text":"Your own dedicated team, including a Citigold Relationship Manager for your banking needs, and a Citi Personal Wealth Management Financial Advisor for investing strategies" },
              {
                "text":"In-depth financial guidance with Citi Clarity® One-on-One, Citi's proprietary financial planning process" },
              {
                "text":"Access to market insights and world-class investment capabilities" },
              {
                "text":"Preferred pricing and rates on select deposit products and services" },
              {
                "text":"Ability to earn the highest level of Citi ThankYou Rewards Points offered for a checking relationship" }]
                }],
    "featureThree": [{
        "header":"To become a Citigold client",
        "list": false,
            "featureThreeText": [{
                "text":"Maintain a combined average monthly balance of $200,000+ in eligible linked deposit, retirement and investment accounts. There are no monthly service fees for Citigold clients." }]
                }],            
    "primaryCtaLabel":"See details",
    "primaryCtaURL":"https://online.citi.com/US/banking/checking/citi.action?ID=citigold"
}]
  // productType = "Citigold"

  constructor() {  }


  ngOnInit() {
  }


}