export interface ShowcaseV1 {
    headerText: string;
    footerLinkText: string;
    footerLinkUrl: string;
    columnData: any;
}