import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showcase-v3',
  templateUrl: './showcase-v3.component.html',
  styleUrls: ['./showcase-v3.component.css']
})
export class ShowcaseV3Component implements OnInit {

  showcases = [
    { 
      "headerText": "Bank Anywhere 24/7",
      "imageSide": "right",
      "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_LookingForMore.jpg",
      "descriptionText": "<p>With ATMs and branches in the places you live, work and play, you're never far from your money.</p> <p>Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.</p>",
      "footerLinkText": "Sign up for Citi Price Rewind",
      "footerLinkUrl": "https://www.citi.com"
    },
    { 
      "headerText": "Looking for More?",
      "imageSide": "left",
      "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_BusinessBanking.jpg",
      "descriptionText": "<p>Switch banks with ease:</p><a href='https://online.citi.com/JRS/forms/SwitchKitForms.pdf' class='chevron-link bold'>Get the Citibank Switch Kit</a><br><br><p>Need more info?</p><a href='https://online.citi.com/JRS/popups/PT_CAP_CitibankGold_.pdf' class='chevron-link bold'>See Citigold Account Details</a><br><br><p>Terms and Conditions:</p><ul><li><a href='https://online.citi.com/JRS/popups/ao/Consumer_Client_Manual.pdf' class='chevron-link bold'>Client Manual: Consumer Accounts</a></li><li><a href='https://online.citi.com/JRS/popups/ao/Citi_Marketplace.pdf' class='chevron-link bold'>Marketplace Addendum</a></li></ul>"
    },
    { 
      "headerText": "Looking for an Investment IRA?",
      "imageSide": "right",
      "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_LookingForInvestmentIRA.jpg",
      "descriptionText": "Are you looking for more IRA options? IRAs with investment products are available through Citi Personal Wealth Management.<sup>3</sup>",
      "footerLinkText": "Learn more about Investment IRAs",
      "footerLinkUrl": "https://online.citi.com/US/JRS/pands/detail.do?ID=InvestingProducts"
    },
    { 
      "headerText": "I am the Walrus",
      "imageSide": "left",
      "headerImg": "https://online.citi.com/JRS/Marketing/Banking/img/Banking_BusinessBanking.jpg",
      "descriptionText": "With ATMs and branches in the places you live, work and play, you're never far from your money. Move your money, manage your portfolio, and view stock quotes and market news - right from the palm of your hand.",
      "footerLinkText": "Sign up for Citi Price Rewind",
      "footerLinkUrl": "https://www.citi.com"
    }
  ]

  constructor() { }

  ngOnInit() {
  }

}
