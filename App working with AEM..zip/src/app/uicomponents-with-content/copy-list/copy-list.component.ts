import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { CopyListModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'copy-list',
  templateUrl: './copy-list.component.html',
  styleUrls: ['./copy-list.component.css']
})
export class CopyListComponent implements OnInit {
  @Input() component: CopyListModel;

  @Input() listType: string;
  @Input() listStyle: string;
  @Input() listTitle: string;
  @Input() listItems: string;
  @Input() leftListItems: string;
  @Input() rightListItems: string;

  constructor() { }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }


}
