import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { environment } from 'environments/environment'
import { Http } from '@angular/http';
import { FaqDataModel } from '../../drupal-content-services/models/nodes';
import { JsonApiQueryData } from 'angular2-jsonapi';
import { FaqfilterService } from '../../shared/services/faqfilter.service';
import { ContentfulService } from '../../contentful-services/contentful.service';
import { AemService } from "../../Aem-services/aem.service";
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  public content = [];
  @Input() faqData: FaqDataModel;
  @Input() dynamic: boolean;

  tagsdata = [];
  faqEdit=environment.aem.faq
  public faq_title: string;
  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId

  private faqfilterService: FaqfilterService;

  public faqDelivery = this.dynamic;

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  private _isOpen: boolean = false;
  public data: any;
  public question: any;
  public answer: any;
  public tips: any;
  public filterFaq: any = {};
  public categoryKeys: any;
  public filterFaqs: any;
  public categoryType: any;
  public tags: any = [];

  public dropdownList: any = [];
  public selectedItems: any = [];
  public dropdownSettings: any = {};



  constructor(private datastore: Datastore, private contentfulService: ContentfulService, private Aemservice: AemService) {
    this.faqfilterService = new FaqfilterService();
    this.faq_title = "Products & Service";
    this.data = this.faqfilterService.data
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.faqfilterService.getfilters(),
    }
  }
  filters: boolean = false;
  ngOnInit() {
    this.getContent();
    this.dropdownList = this.faqfilterService.data1
    this.selectedItems = [];
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Tags',
      id: 'id',
      itemName: 'itemName',
      allowSearchFilter: true,
      enableCheckAll: false,
      closeDropDownOnSelection: true
    };
  }

  ngAfterViewInit() {
    // this.getContent();

  }
  onItemSelect(item: any) {
    this.tags.push(item.id);
    console.log("id", item.id);
    this.filters = true;
    this.getContent();
  }

  onItemDeSelect(item: any) {
    let index = this.tags.indexOf(item.id);
    if (index > -1) {
      this.tags.splice(index, 1);
    }
    if (this.tags.length == 0) {
      this.filters = false;
    } else {
      this.filters = true;
    }
    this.getContent();
  }


  getContent() {
    this.content = [];
    this.Aemservice.getdata()
      .subscribe(faqDs => {
        // console.log("content", faqDs)
        let data = faqDs[":items"].root[':items']
        for (let element in data) {
          this.content.push(data[element]);
        }
        this.filterFaq = {}
        let group = [];
        if (this.filters != true) {
          this.content.forEach(_content => {
            console.log(_content.elements.tags.value[0])

            let faqData = {};
            let tagArray = _content.elements.faqCategories.value ? _content.elements.faqCategories.value.split(',')[0] : 'others';
            faqData['faqQuestion'] = _content.elements.questions.value;
            faqData['faqAnswer'] = _content.elements.answers.value;
            // faqData['nid'] = _content.sys['id']
            console.log(faqData)
            if (!this.filterFaq[tagArray]) {
              group = [];
              group.push(faqData);
            }
            else {
              group = this.filterFaq[tagArray];
              group.push(faqData);
            }
            this.filterFaq[tagArray] = group;
          })
          this.categoryKeys = Object.keys(this.filterFaq);
          this.categoryType = this.categoryKeys[0];
        }
        else {
          this.content.forEach(_content => {
            this.categoryKeys;
            this.categoryType;
            let faqData = {};

            this.tags.forEach(_selctedTag => {
              if (_content.elements.tags.value[0].includes(_selctedTag)) {


                let tagArray = _content.elements.faqCategories.value ? _content.elements.faqCategories.value.split(',')[0] : 'others';
                faqData['faqQuestion'] = _content.elements.questions.value;
                faqData['faqAnswer'] = _content.elements.answers.value;

                if (!this.filterFaq[tagArray]) {
                  group = [];
                  group.push(faqData);
                }
                else {
                  group = this.filterFaq[tagArray];
                  group.push(faqData);
                }
                this.filterFaq[tagArray] = group;
              }
            })

          })

          this.categoryKeys = Object.keys(this.filterFaq);
          this.categoryType = this.categoryKeys[0];
        }

      })

  }
  // getcontent(){
  //   this.contentfulService.getdata().subscribe(values=>{
  //     console.log("abcdefg",values)
  //   })
  // }



  // showContent(tip) {
  //   if (!tip.isOpen) {
  //     this.closeAllTips();
  //   }
  //   tip.isOpen = !tip.isOpen;
  // }
}