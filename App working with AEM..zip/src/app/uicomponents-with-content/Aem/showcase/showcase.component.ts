import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { AemService } from "../../../Aem-services/aem.service";
@Component({
  selector: 'app-showcase-Aem',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.css']
})
export class ShowcaseAemComponent implements OnInit {
 
  @Input() component;
  @Input() version;

  @Input() layout;
 url="https://citibank-dev1.adobecqms.net"

  /*  Setting page types changes the Showcase template view so that the same content 
      structure can be used in different visual variations. The only currently accepted
      value is 'category' and is set at the Marketing Page level.
  */
  public pageType = this.layout;

  constructor() { }

  ngOnInit() {
    this.pageType = this.layout;
     console.log("showcase",this.component)
    // this.get()
  }

  isObject(obj) {
    return _.isObject(obj);
  }




}