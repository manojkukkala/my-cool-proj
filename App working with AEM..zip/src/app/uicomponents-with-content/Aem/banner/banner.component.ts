import { Component, OnInit, Input } from '@angular/core';

import { environment } from 'environments/environment'
@Component({
  selector: 'app-banner-Aem',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css']
})
export class BannerAemComponent implements OnInit {
url="https://citibank-dev1.adobecqms.net"
  @Input() component;
edit =environment.aem.ckc
  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId
  constructor() { }

  ngOnInit() {
    console.log("banner",this.component)
  }

}
