import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-action-Aem',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css']
})
export class ActionAemComponent implements OnInit {
  
  @Input() component;

url="https://citibank-dev1.adobecqms.net"
  constructor() { }

  ngOnInit() {
    console.log("action",this.component)
  }

}
