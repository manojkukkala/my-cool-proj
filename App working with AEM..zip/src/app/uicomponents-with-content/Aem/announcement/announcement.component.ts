import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-announcement-Aem',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.css']
})
export class AnnouncementAemComponent implements OnInit {
  @Input() component;
  constructor() { }

  ngOnInit() {
    console.log(this.component)

  }

}
