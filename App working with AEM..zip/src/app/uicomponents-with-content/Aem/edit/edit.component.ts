import { Component, OnInit, Input } from '@angular/core';
import { MarketingPageModel } from "app/drupal-content-services/models/nodes";
import { environment } from 'environments/environment'

@Component({
  selector: 'cms-edit-Aem',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditAemComponent implements OnInit {
  ckcEdit=environment.aem.ckc
  @Input() component: MarketingPageModel;
  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId;
  
  constructor() { }

  ngOnInit() {}

}
