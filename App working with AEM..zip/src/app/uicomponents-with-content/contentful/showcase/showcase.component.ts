import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { AemService } from "../../../Aem-services/aem.service";
@Component({
  selector: 'app-showcase-contentful',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.css']
})
export class ShowcaseContentfulComponent implements OnInit {
  content;
  @Input() component;
  @Input() version;

  @Input() layout;


  /*  Setting page types changes the Showcase template view so that the same content 
      structure can be used in different visual variations. The only currently accepted
      value is 'category' and is set at the Marketing Page level.
  */
  public pageType = this.layout;

  constructor(private Aemservice: AemService) { }

  ngOnInit() {
    this.pageType = this.layout;
    // console.log("vesionnnnnn",this.version)
    // this.get()
  }

  isObject(obj) {
    return _.isObject(obj);
  }

  // get() {
  //   this.content = [];
  //   this.Aemservice.getcardData().subscribe(data => {
  //     console.log("content", data)
  //     let cardcontent = data[":items"].root[':items']
  //     console.log("---", cardcontent)
  //     for (let element in cardcontent) {
  //       if (cardcontent[element].elements.headerImg) {
  //         this.content.push(cardcontent[element]);
  //       }

  //     }
  //     console.log("===>", this.content)
  //   })
  // }


}