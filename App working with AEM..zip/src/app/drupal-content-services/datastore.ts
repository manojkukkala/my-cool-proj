import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { JsonApiDatastoreConfig, JsonApiDatastore } from 'angular2-jsonapi';
import { environment } from 'environments/environment'

// models
  //nodes
import { MarketingPageModel, AlertDataModel, ArticlePageModel, ArticleRelatedModel, ColumnDataModel, FileDataModel, TaxDataModel, LinkModel, ActionDataModel, BannerDataModel, FaqDataModel, TermsDataModel } from './models/nodes';
  //paragraph types
import { ActionModel, AlertModel, ButtonModel, HeroModel, ShowcaseModel, CardModel, CTAModel, CopyModel, RowDataModel, CopyListModel, CopyWarningModel, PromoModel, ListModel, ArticleParagraphModel, ButtonBarModel, BreadcrumbModel, BannerModel, SocialIconModel, TermsModel } from './models/paragraphs';


@Injectable()
@JsonApiDatastoreConfig({
  baseUrl: environment.drupalUrl + '/jsonapi',
  models: {
    marketing_page: MarketingPageModel,
    'article_page': ArticlePageModel,
    'article_related': ArticleRelatedModel,
    'paragraph--article': ArticleParagraphModel,
    'paragraph--alert': AlertModel,
    'paragraph--action': ActionModel,
    'paragraph--button': ButtonModel,
    'paragraph--buttonbar': ButtonBarModel,
    'paragraph--banner': BannerModel,        
    'paragraph--hero': HeroModel,
    'paragraph--card': CardModel,
    'paragraph--showcase': ShowcaseModel,
    'paragraph--cta': CTAModel,
    'paragraph--list': ListModel,
    'paragraph--showcase_row': RowDataModel,
    'paragraph--copy': CopyModel,
    'paragraph--copy_list': CopyListModel,
    'paragraph--copy_warning': CopyWarningModel,
    'paragraph--promo': PromoModel,
    'paragraph--breadcrumb': BreadcrumbModel,
    'paragraph--social_icon': SocialIconModel, 
    'showcase': ColumnDataModel,
    'file--file': FileDataModel,
    'faq': FaqDataModel,
    'taxonomy_term--categories': TaxDataModel,
    'link': LinkModel,
    'action': ActionDataModel,
    'banner': BannerDataModel,
    'alert': AlertDataModel,
    'terms': TermsDataModel,
    'paragraph--terms': TermsModel
  }
})
export class Datastore extends JsonApiDatastore {
  constructor(http: Http) {
    super(http);
  }
}