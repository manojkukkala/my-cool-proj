import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { LinkModel } from "../nodes/link.model";


@JsonApiModelConfig({
    type: 'paragraph--buttonbar'
})
export class ButtonBarModel extends JsonApiModel {
    @HasMany()
    linkData: LinkModel[];

    @HasMany()
    components: JsonApiModel[];
}