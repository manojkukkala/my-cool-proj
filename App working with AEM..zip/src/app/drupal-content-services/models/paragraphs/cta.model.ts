import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--cta'
})
export class CTAModel extends JsonApiModel {
    @Attribute()
    field_cta_type: string;

    @Attribute()
    field_href: string;

    @Attribute()
    field_size: string;
    
    @Attribute()
    field_value: string;

    @Attribute()
    field_aria_label: string;

    @Attribute()
    field_aria_description: string;
}