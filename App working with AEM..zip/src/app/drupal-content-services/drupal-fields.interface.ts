export interface body {
    value: string;
    format: string;
}

export interface Link {
    uri: string;
    text: string;
}
