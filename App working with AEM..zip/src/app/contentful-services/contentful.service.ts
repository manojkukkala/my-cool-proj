import { Injectable } from '@angular/core';
import { createClient, Entry } from 'contentful';
import { environment } from '../../environments/environment';
import { all } from 'q';
import { Response } from "@angular/http";
import { HttpClient} from '@angular/common/http'
import { map } from 'rxjs/operators';
@Injectable()

export class ContentfulService {
 
  private client = createClient({
    space: environment.contentful.spaceId,
    accessToken: environment.contentful.token,
  });
  api="https://citibank-dev1.adobecqms.net/content/we-retail/us/en/faq-page.model.json"
  constructor(private http: HttpClient) { }
data:any;
  getCourses() {
    return this.client.getEntries()
      .then(res => res.items);
  }

  // getCourse(courseId): Promise<Entry<any>> {
  //   return this.client.getEntries(Object.assign({
  //     content_type: 'course'
  //   }, {'sys.id': courseId}))
  //     .then(res => res.items[0]);
  // }

  getfilter(data){
    return this.http
    .get(environment.api+data,{responseType: "json" }).map((response:Response)=> response);
 
  }


  getdata() {
    return this.http.get(this.api,{ responseType: "json" }).map((response:Response)=> response);
}

  getSingleAsset(){
    return this.client.getAsset("5B1xwgXM1GwwisiMSqwqgY")
    .then((asset) => console.log(asset))
    .catch(console.error)
  }
}
