import { Datastore } from './../../drupal-content-services/datastore';
import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { CopyModel, HeroModel, CopyListModel, CopyWarningModel, PromoModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-citi-priority-package',
  templateUrl: './citi-priority-package.component.html',
  styleUrls: ['./citi-priority-package.component.css']
})

export class CitiPriorityPackageComponent implements OnInit {

 /**
   * Page ID (uuid) of the banking page: http://cddemo10dev.prod.acquia-sites.com/node/146
   * uuid is not normally visible and internally used by drupal JSONAPI module
   */
  private pageId = "c95234af-3dca-48d2-87ce-c77195a29fd0";
  
  /**
   * JSONAPI include
   */
  // private include = 'components,components.field_list_columns,components.field_list_items,components.field_left_list_items,components.field_right_list_items,components.field_list_style,components.field_list_title';
  // private include = 'components,components.field_copy_content,components.field_header,components.field_header_type,components.field_text_style,components.field_border';
  private include = 'components,components.components,components.field_showcase_type,components.field_showcase_header_image,components.field_showcase_header_icon,components.field_showcase_headline,components.field_showcase_subheader_text,components.field_showcase_cta,components.field_showcase_content,components.field_showcase_content.field_showcase_img,components.field_showcase_content.field_showcase_headline,components.field_showcase_content.field_body,components.field_showcase_content.field_showcase_cta,components.field_showcase_row_data,components.field_showcase_row_data.field_showcase_column_data,components.field_showcase_row_data.field_showcase_column_data.field_body,components.field_showcase_row_data.field_showcase_column_data.field_showcase_cta,components.field_showcase_row_data.field_showcase_column_data.field_showcase_headline,components.field_showcase_row_data.field_showcase_column_data.field_showcase_img';

  mp: MarketingPageModel;

  /**
   * JSONAPI fields
   */
  private fields = {
    // 'paragraph--copy_list':'listTitle,listColumns,listStyle,listItems,leftListItems,rightListItems',
    // 'paragraph--copy_warning':'copyContent,header,headerType,textStyle,border',
    // 'paragraph--promo':'promoCopyText,linkText'

  };
  public components = {
    // promo1: 'd51ff54a-052d-4f01-8222-a02786ec5f0c',
    // promo2: '09535bd4-dc2b-4461-9865-e627c761b4c1'
    // warning: '63c8bdc9-f0c7-419b-926f-0a7ac3c9399f',
    // rando: '457f383f-fb26-4d70-a006-77507ba0ec13',
    // citiPriority: '5462dfb0-6492-44df-881f-e8b2b367e2b5'
  };


  /**
   * Merge all query parameters in queryParameters
   */
  private queryParameters = {};
  public isLoaded: boolean = false;

   constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields
    }
  }
  ngOnInit() {
    this.datastore.findRecord(MarketingPageModel, this.pageId, this.queryParameters)
      .subscribe((mp: MarketingPageModel) => {
        this.mp = mp;
        console.log(mp);
      this.isLoaded = true;
      });
  }
}

