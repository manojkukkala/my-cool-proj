import { FileDataModel } from './../nodes/file.model';
import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--hero'
})
export class HeroModel extends JsonApiModel {
    @Attribute()
    field_citigold: boolean;

    @Attribute()
    field_eyebrow: string;

    @Attribute()
    field_hero_title: string;

    @Attribute()
    field_hero_type: string;

    @Attribute()
    field_legend: string;

    @BelongsTo()
    field_promo_image: FileDataModel;

    @Attribute()
    field_subheading_legend: string;

    @Attribute()
    field_subheading_title: string;

    @BelongsTo()
    field_subheading_image: FileDataModel;

    @HasMany()
    components: JsonApiModel[];
}