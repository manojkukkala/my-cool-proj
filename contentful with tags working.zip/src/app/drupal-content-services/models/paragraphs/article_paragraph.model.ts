import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { FileDataModel } from '../nodes/file.model';
import { ArticleRelatedModel } from '../nodes/article_related.model';
import { SocialIconModel } from '../paragraphs/socialicon.model';
import { ButtonModel } from '../paragraphs/button.model';

@JsonApiModelConfig({
    type: 'paragraph--article'
})
export class ArticleParagraphModel extends JsonApiModel {

    @BelongsTo()
    heroImg: FileDataModel;

    @Attribute()
    heroTitle: string;

    @Attribute()
    heroText: string;

    @Attribute()
    articleTitle: string;
    
    @Attribute()
    ctaType: string;

    @Attribute()
    ctaButtonLabel:string;

    @Attribute()
    ctaButtonUrl:string;

    @HasMany()
    socialIcon: SocialIconModel[];
    
    @HasMany()
    components: JsonApiModel[];

}