import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'taxonomy_term--categories'
})
export class TaxDataModel extends JsonApiModel {
    
    @Attribute()
    name: string;

}