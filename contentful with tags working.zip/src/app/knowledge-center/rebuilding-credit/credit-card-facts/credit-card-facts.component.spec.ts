import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditCardFactsComponent } from './credit-card-facts.component';

describe('CreditCardFactsComponent', () => {
  let component: CreditCardFactsComponent;
  let fixture: ComponentFixture<CreditCardFactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditCardFactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardFactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
