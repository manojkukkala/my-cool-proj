import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImproveCreditHistoryComponent } from './improve-credit-history.component';

describe('ImproveCreditHistoryComponent', () => {
  let component: ImproveCreditHistoryComponent;
  let fixture: ComponentFixture<ImproveCreditHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImproveCreditHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImproveCreditHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
