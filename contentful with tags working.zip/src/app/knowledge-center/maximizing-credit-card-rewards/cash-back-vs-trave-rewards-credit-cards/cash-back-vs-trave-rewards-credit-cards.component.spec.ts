import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CashBackVsTraveRewardsCreditCardsComponent } from './cash-back-vs-trave-rewards-credit-cards.component';

describe('CashBackVsTraveRewardsCreditCardsComponent', () => {
  let component: CashBackVsTraveRewardsCreditCardsComponent;
  let fixture: ComponentFixture<CashBackVsTraveRewardsCreditCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CashBackVsTraveRewardsCreditCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashBackVsTraveRewardsCreditCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
