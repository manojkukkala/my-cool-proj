import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BestTimeToBookAwardTravelComponent } from './best-time-to-book-award-travel.component';

describe('BestTimeToBookAwardTravelComponent', () => {
  let component: BestTimeToBookAwardTravelComponent;
  let fixture: ComponentFixture<BestTimeToBookAwardTravelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BestTimeToBookAwardTravelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BestTimeToBookAwardTravelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
