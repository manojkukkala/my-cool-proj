import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelingTheWorldComponent } from './traveling-the-world.component';

describe('TravelingTheWorldComponent', () => {
  let component: TravelingTheWorldComponent;
  let fixture: ComponentFixture<TravelingTheWorldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelingTheWorldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelingTheWorldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
