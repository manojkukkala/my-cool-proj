import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecuredVsUnsecuredCreditCardsComponent } from './secured-vs-unsecured-credit-cards.component';

describe('SecuredVsUnsecuredCreditCardsComponent', () => {
  let component: SecuredVsUnsecuredCreditCardsComponent;
  let fixture: ComponentFixture<SecuredVsUnsecuredCreditCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecuredVsUnsecuredCreditCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecuredVsUnsecuredCreditCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
