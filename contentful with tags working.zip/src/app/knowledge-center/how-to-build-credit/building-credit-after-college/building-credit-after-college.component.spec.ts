import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingCreditAfterCollegeComponent } from './building-credit-after-college.component';

describe('BuildingCreditAfterCollegeComponent', () => {
  let component: BuildingCreditAfterCollegeComponent;
  let fixture: ComponentFixture<BuildingCreditAfterCollegeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildingCreditAfterCollegeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildingCreditAfterCollegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
