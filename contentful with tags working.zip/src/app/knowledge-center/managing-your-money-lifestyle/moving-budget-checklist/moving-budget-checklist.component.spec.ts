import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovingBudgetChecklistComponent } from './moving-budget-checklist.component';

describe('MovingBudgetChecklistComponent', () => {
  let component: MovingBudgetChecklistComponent;
  let fixture: ComponentFixture<MovingBudgetChecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovingBudgetChecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovingBudgetChecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
