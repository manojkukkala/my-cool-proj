import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EstablishingCreditAndBuildingCreditHealthComponent } from './establishing-credit-and-building-credit-health.component';

describe('EstablishingCreditAndBuildingCreditHealthComponent', () => {
  let component: EstablishingCreditAndBuildingCreditHealthComponent;
  let fixture: ComponentFixture<EstablishingCreditAndBuildingCreditHealthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EstablishingCreditAndBuildingCreditHealthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EstablishingCreditAndBuildingCreditHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
