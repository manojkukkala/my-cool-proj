import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardsCreditCardsForHolidayShoppingComponent } from './rewards-credit-cards-for-holiday-shopping.component';

describe('RewardsCreditCardsForHolidayShoppingComponent', () => {
  let component: RewardsCreditCardsForHolidayShoppingComponent;
  let fixture: ComponentFixture<RewardsCreditCardsForHolidayShoppingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardsCreditCardsForHolidayShoppingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardsCreditCardsForHolidayShoppingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
