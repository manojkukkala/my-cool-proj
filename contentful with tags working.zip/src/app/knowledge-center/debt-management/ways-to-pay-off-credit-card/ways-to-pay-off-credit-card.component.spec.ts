import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaysToPayOffCreditCardComponent } from './ways-to-pay-off-credit-card.component';

describe('WaysToPayOffCreditCardComponent', () => {
  let component: WaysToPayOffCreditCardComponent;
  let fixture: ComponentFixture<WaysToPayOffCreditCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaysToPayOffCreditCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaysToPayOffCreditCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
