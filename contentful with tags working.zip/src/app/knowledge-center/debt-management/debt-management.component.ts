import { Component, OnInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { MarketingPageModel } from '../../drupal-content-services/models/nodes/marketing_page.model';
import { JsonApiQueryData } from 'angular2-jsonapi';

@Component({
  selector: 'app-debt-management',
  templateUrl: './debt-management.component.html',
  styleUrls: ['./debt-management.component.css']
})
export class DebtManagementComponent implements OnInit {

  mp: MarketingPageModel;

  //This is the machine generated uuid for the content item in Drupal
  private pageId = "";

  //JSONAPI filtering
  /* TODO:
  /* Currently pulling in all content here from the How to Build Credit page just to show 
  /* a simple use-case of requesting content via filters and not via uuid. 
  /* Change this when the Debt Management page content has been built.
  */ 
  private pageFilters = {
    titleFilter: {
      condition: {
        path: 'title',
        value: 'Temporary Place Holder Page'
      }
    }
  };

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  //Merge all query parameters in queryParameters
  private queryParameters = {};

  public isLoaded: boolean = false;

  constructor(private datastore: Datastore) {
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.pageFilters
    }
  }

  ngOnInit() {
    this.datastore.findAll(MarketingPageModel, this.queryParameters)
      .subscribe((marketingPage: JsonApiQueryData<MarketingPageModel>) => {
        this.mp = marketingPage.getModels()[0];
        console.log(this.mp);
        this.mp.pageType = "category";
        this.isLoaded = true;
      }
    );
  }

}
