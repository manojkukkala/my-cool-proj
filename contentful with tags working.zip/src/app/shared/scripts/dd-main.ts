
export class DDMain {
    passedData: any;

    constructor(dataObj: any) {
        this.passedData = dataObj;
    }
    
   	/**
	 * Replaces all of the variables in in the content object with the proper values
	 * @param contentObj The list of content objects retrieved from CMS
	 * @param variables The list of variables/values that will overwerite the placeholder
	 */
	replaceContentVars(contentObj: any, variables: any) {
		let variable;
        // base case - no variables passed in (either variables is not passed in or emptye object)
		if (typeof variables === 'undefined' || Object.keys(variables).length === 0) {
			return contentObj;
		}
	
		if (typeof contentObj['descriptionText'] === 'string') {
			contentObj['descriptionText'] = DDMain.replaceAll(contentObj['descriptionText'].toString(), variables);
		}
		else{
			var descriptionText = contentObj['descriptionText'].toString();
			console.log('descriptionText '+ descriptionText.value);
			console.log('variables '+ variables);
			contentObj['descriptionText'] = DDMain.replaceAll(descriptionText, variables);
		}
		return contentObj;
	}

    /**
	 *
	 * @param {String} str The string to have its mapObj replaced with
	 * @param {Object} mapObj A JSON object containing all of the substrings to replace and the corresponding replacement values
	*/
    static replaceAll(str: string, mapObj: Object): string {
		let re = new RegExp(Object.keys(mapObj).join('|'), 'gi');

		return str.replace(re, function (matched) {
			return mapObj[matched];
		});
    }
}