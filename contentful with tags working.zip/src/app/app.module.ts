import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { JsonApiModule } from 'angular2-jsonapi';
import { AppComponent } from './app.component';
import { CbolCoreModule } from './cbol_core/cbol_core.module';
import { DrupalJSONAPIService } from './drupal-content-services/drupal-jsonapi.service';
import { Datastore } from './drupal-content-services/datastore';
import { ContentfulService } from './contentful-services/contentful.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
	declarations: [
		AppComponent
	],
	imports: [
		BrowserModule,
		CbolCoreModule,
		JsonApiModule,
		HttpModule,
		HttpClientModule
	],
	exports:[HttpModule],
	providers: [DrupalJSONAPIService, Datastore, ContentfulService],
	bootstrap: [AppComponent]
})
export class AppModule {
}
