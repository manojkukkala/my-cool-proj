import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialHarmonyComponent } from './financial-harmony.component';

describe('FinancialHarmonyComponent', () => {
  let component: FinancialHarmonyComponent;
  let fixture: ComponentFixture<FinancialHarmonyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialHarmonyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialHarmonyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
