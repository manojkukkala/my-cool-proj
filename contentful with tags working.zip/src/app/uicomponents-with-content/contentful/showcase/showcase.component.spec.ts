import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowcaseContentfulComponent } from './showcase.component';

describe('ShowcaseContentfulComponent', () => {
  let component: ShowcaseContentfulComponent;
  let fixture: ComponentFixture<ShowcaseContentfulComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowcaseContentfulComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowcaseContentfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
