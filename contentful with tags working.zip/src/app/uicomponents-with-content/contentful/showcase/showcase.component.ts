import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';

@Component({
  selector: 'app-showcase-contentful',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.css']
})
export class ShowcaseContentfulComponent implements OnInit {

  @Input() component;
  @Input() version;

  @Input() layout;


  /*  Setting page types changes the Showcase template view so that the same content 
      structure can be used in different visual variations. The only currently accepted
      value is 'category' and is set at the Marketing Page level.
  */
  public pageType = this.layout;

  constructor() { }

  ngOnInit() {
    this.pageType = this.layout;
  }

  isObject(obj){
    return _.isObject(obj);
  }

}
