import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BreadcrumbContenfulComponent } from './breadcrumb.component';

describe('BreadcrumbContenfulComponent', () => {
  let component: BreadcrumbContenfulComponent;
  let fixture: ComponentFixture<BreadcrumbContenfulComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BreadcrumbContenfulComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbContenfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
