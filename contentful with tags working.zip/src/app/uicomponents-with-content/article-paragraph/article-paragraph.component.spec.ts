import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleParagraphComponent } from './article-paragraph.component';

describe('ArticleParagraphComponent', () => {
  let component: ArticleParagraphComponent;
  let fixture: ComponentFixture<ArticleParagraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleParagraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleParagraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
