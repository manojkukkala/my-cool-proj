import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { Datastore } from '../../drupal-content-services/datastore';
import { DrupalJSONAPIService } from '../../drupal-content-services/drupal-jsonapi.service';
import { environment } from 'environments/environment'
import { Http } from '@angular/http';
import { FaqDataModel } from '../../drupal-content-services/models/nodes';
import { JsonApiQueryData } from 'angular2-jsonapi';
import { FaqfilterService } from '../../shared/services/faqfilter.service';
import { ContentfulService } from '../../contentful-services/contentful.service';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {

  @Input() faqData: FaqDataModel;
  @Input() dynamic: boolean;

  public faq_title: string;
  public env = environment.contentfulUrl;
  public spaceId = environment.contentful.spaceId

  private faqfilterService: FaqfilterService;

  public faqDelivery = this.dynamic;

  //Merge all query paramters in queryParamters
  private queryParameters = {};

  //JSONAPI includes
  private include = '';

  //JSONAPI fields
  private fields = {};

  private _isOpen: boolean = false;
  public data: any;
  public question: any;
  public answer: any;
  public tips: any;
  public filterFaq: any = {};
  public categoryKeys: any;
  public filterFaqs: any;
  public categoryType: any;
  public tags: any = [];

  public dropdownList: any = [];
  public selectedItems: any = [];
  public dropdownSettings: any = {};

  constructor(private datastore: Datastore, private contentfulService: ContentfulService) {
    this.faqfilterService = new FaqfilterService();
    this.faq_title = "Products & Service";
    this.data = this.faqfilterService.data
    this.queryParameters = {
      include: this.include,
      fields: this.fields,
      filter: this.faqfilterService.getfilters(),
    }
  }
  filters: boolean = false;
  ngOnInit() {

    this.dropdownList = this.faqfilterService.data1
    this.selectedItems = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      allowSearchFilter: true,
      enableCheckAll: false,
      closeDropDownOnSelection: true
    };
  }

  ngAfterViewInit() {
    this.getContent();


  }
  onItemSelect(item: any) {
    this.tags.push(item.item_id);
    // console.log(item.item_id);
    this.filters = true;
    this.getContent();
  }

  onItemDeSelect(item: any) {
    let index= this.tags.indexOf(item.item_id);
    if (index>-1){
      this.tags.splice(index, 1);
    }
    if (this.tags.length == 0) {
      this.filters = false;
    } else {
      this.filters = true;
    }
    this.getContent();
  }


  getContent() {
    if (this.filters == false) {
      // console.log(this.data)
      this.contentfulService.getCourses()
        .then(faqDs => {
          // console.log("content", faqDs)
          this.filterFaq = {}
          let group = [];
          let data = faqDs.filter(_faqPage => {
            return _faqPage.sys.contentType.sys.id === "faq"
          })

          data.forEach(_content => {
            let faqData = {};
            let tagArray = _content.fields['faqCategories'] ? _content.fields['faqCategories'].split(',')[0] : 'others';
            faqData['faqQuestion'] = _content.fields['questions'];
            faqData['faqAnswer'] = _content.fields['answers'];
            faqData['nid'] = _content.sys['id']
            if (!this.filterFaq[tagArray]) {
              group = [];
              group.push(faqData);
            }
            else {
              group = this.filterFaq[tagArray];
              group.push(faqData);
            }
            this.filterFaq[tagArray] = group;
          })
          this.categoryKeys = Object.keys(this.filterFaq);
          this.categoryType = this.categoryKeys[0];
        }
        );

    }
    else {
      // console.log("Tags===",this.tags)
      this.contentfulService.getfilter(this.tags.toString())
        .subscribe(filters => {
          // console.log("===>", filters)
          this.filterFaq = {}
          let group = [];
          let data = filters['items']
          data.forEach(_content => {
            // console.log("data////",_content)
            let faqData = {};
            let tagArray = _content.fields['faqCategories'] ? _content.fields['faqCategories'].split(',')[0] : 'others';
            faqData['faqQuestion'] = _content.fields['questions'];
            faqData['faqAnswer'] = _content.fields['answers'];
            faqData['nid'] = _content.sys['id'];
            if (!this.filterFaq[tagArray]) {
              group = [];
              group.push(faqData);
            }
            else {
              group = this.filterFaq[tagArray];
              group.push(faqData);
            }
            this.filterFaq[tagArray] = group;
          })

          this.categoryKeys = Object.keys(this.filterFaq);
          this.categoryType = this.categoryKeys[0];
        })
    }
  }




  // showContent(tip) {
  //   if (!tip.isOpen) {
  //     this.closeAllTips();
  //   }
  //   tip.isOpen = !tip.isOpen;
  // }
}