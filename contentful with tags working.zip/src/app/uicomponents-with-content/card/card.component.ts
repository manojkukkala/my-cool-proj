import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'underscore';
import { CardModel } from '../../drupal-content-services/models/paragraphs';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],

})
export class CardComponent implements OnInit {
  @Input() component: CardModel;
  
  @Input() product: string;
  @Input() name: string;
  @Input() productTitle: string;
  @Input() featureOneHeader: string;
  @Input() featureOneText: string;

  @Input() featureTwoHeader: string;
  @Input() featureTwoText: string;
  @Input() isList: boolean;
  @Input() listText: string;

  @Input() featureThreeHeader: string;
  @Input() featureThreeText: string;

  @Input() primaryCtaLabel: string;
  @Input() primaryCtaUrl: string;


  constructor() {  }

  ngOnInit() {
    console.log('Component', this.component);
  }

  isObject(obj){
    return _.isObject(obj);
  }

}

