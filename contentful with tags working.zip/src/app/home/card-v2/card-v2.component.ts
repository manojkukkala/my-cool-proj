import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-card-v2',
  templateUrl: './card-v2.component.html',
  styleUrls: ['./card-v2.component.css'],

})
export class CardComponentV2 implements OnInit {
  @Input() product: string;
  @Input() name: string;
  @Input() productTitle: string;
  @Input() featureOneHeader: string;
  @Input() featureOneList: boolean;
  @Input() featureOneText: string;

  @Input() listText1: string;
  @Input() listText2: string;
  @Input() listText3: string;
  @Input() listText4: string;
  @Input() listText5: string;
  @Input() listText6: string;
  @Input() listText7: string;
  @Input() listText8: string;


  @Input() featureTwoHeader: string;
  @Input() featureTwoList: boolean;
  @Input() featureTwoText: string;

  @Input() featureThreeHeader: string;
  @Input() featureThreeList: boolean;
  @Input() featureThreeText: string;

  @Input() primaryCtaLabel: string;
  @Input() primaryCtaUrl: string;

//   card: object = [{ 
//     "cardName":"Card 1",
//     "product":"citigold",
//     "productTitle":"Citigold® Package",
//     "featureOneHeader": "Banking and Wealth Management",
//     "featureOneText": "Feature one text",
//     "featureTwoHeader": "header",
//     "featureTwoText": "Feature two text",
//     "featureThreeHeader":"To waive the $30 monthly service fee",
//     "featureThreeText": "Feature three text",
//     "primaryCtaLabel":"See details",
//     "primaryCtaUrl":"https://online.citi.com/US/banking/checking/citi.action?ID=citigold"
// }]
  constructor() {  }


  ngOnInit() {
  }


}
