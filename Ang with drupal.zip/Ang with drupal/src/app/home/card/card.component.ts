import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],

})
export class CardComponent implements OnInit {

  @Input() product: string;
  @Input() name: string;
  @Input() productTitle: string;
  @Input() featureOneHeader: string;
  @Input() featureOneList: boolean;
  @Input() featureOneText: string;

  @Input() featureTwoHeader: string;
  @Input() featureTwoList: boolean;
  @Input() featureTwoText: string;

  @Input() featureThreeHeader: string;
  @Input() featureThreeList: boolean;
  @Input() featureThreeText: string;

  @Input() primaryCtaLabel: string;
  @Input() primaryCtaUrl: string;


 card: object = [{ 
    "cardName":"Card 1",
    "product":"citigold",
    "productTitle":"Citigold® Package",
    "featureOne": [{
        "header":"Banking and Wealth Management",
        "list": true,
            "featureOneText": [{
                "text":""},
                {
                "text": "" }]
                }],
    "featureTwo": [{
        "header":"",
        "list": true,
            "featureTwoText": [{
                "text":"Professional strategies and guidance from a Citi Personal Wealth Management Financial Advisor by phone" },
              {
                "text":"Investment resources to simplify your financial decisions" },
              {
                "text":"Preferred pricing and rates on select deposit products and services" },
              {
                "text":"Ability to earn a higher level of Citi ThankYou Rewards Points offered for a checking relationship" },
              {
                "text":"A robust library of online financial education articles and tools" }]
                }],
    "featureThree": [{
        "header":"To waive the $30 monthly service fee",
        "list": false,        
            "featureThreeText": [{
                "text":"Maintain a combined average monthly balance of $50,000+ in eligible linked deposit, retirement and investment accounts." }]
                }],            
    "primaryCtaLabel":"See details",
    "primaryCtaURL":"https://online.citi.com/US/banking/checking/citi.action?ID=citigold"
}]


  constructor() {  }


  ngOnInit() {
  }


}
