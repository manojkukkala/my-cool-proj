import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingPackagesComponent } from './banking-packages.component';

describe('BankingPackagesComponent', () => {
  let component: BankingPackagesComponent;
  let fixture: ComponentFixture<BankingPackagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingPackagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingPackagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
