import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreCommonModule } from 'angular-nexus-uiux';
import { CitiModule } from 'uicomponents/citi.module';
import { AmwModule } from 'angular-container-common/amw';

import { BankingRoutingModule } from './banking-routing.module';

import { BankingComponent } from './banking.component';
import { UIComponentsWithContentModule } from '../uicomponents-with-content/uicomponents-with-content.module';
import { CitigoldPackageComponent } from './citigold-package/citigold-package.component';
import { SimpleCheckingComponent } from './simple-checking/simple-checking.component';
import { CitiPriorityPackageComponent } from './citi-priority-package/citi-priority-package.component';
import { BankingPackagesComponent } from './banking-packages/banking-packages.component';
import { BankingPackagesHeroComponent } from './banking-packages-hero/banking-packages-hero.component';
import { BankWithCitiComponent } from './bank-with-citi/bank-with-citi.component';

@NgModule({
  imports: [
		CoreCommonModule,
		CitiModule,
		AmwModule,
    BankingRoutingModule,
    UIComponentsWithContentModule
  ],
  declarations: [BankingComponent, CitigoldPackageComponent, SimpleCheckingComponent, CitiPriorityPackageComponent, BankingPackagesComponent, BankingPackagesHeroComponent, BankWithCitiComponent]
})
export class BankingModule { }
