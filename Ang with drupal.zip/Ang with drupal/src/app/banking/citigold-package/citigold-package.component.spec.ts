import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitigoldPackageComponent } from './citigold-package.component';

describe('CitigoldPackageComponent', () => {
  let component: CitigoldPackageComponent;
  let fixture: ComponentFixture<CitigoldPackageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitigoldPackageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitigoldPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
