import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { JsonApiModule } from 'angular2-jsonapi';
import { AppComponent } from './app.component';
import { CbolCoreModule } from './cbol_core/cbol_core.module';
import { DrupalJSONAPIService } from './drupal-content-services/drupal-jsonapi.service';
import { Datastore } from './drupal-content-services/datastore';
import {OauthService} from './oauth/oauth-service';
import { ContentfulService } from './contentfull-services/contentfull.service';

@NgModule({
	declarations: [
		AppComponent
	],
	imports: [
		BrowserModule,
		CbolCoreModule,
		JsonApiModule
	],
	providers: [DrupalJSONAPIService, Datastore, OauthService,ContentfulService],
	bootstrap: [AppComponent]
})
export class AppModule {
}
