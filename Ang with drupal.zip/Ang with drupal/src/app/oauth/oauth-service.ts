import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs';
import { AppConfigService } from 'angular-nexus-uiux/services';
import { environment } from '../../environments/environment';

@Injectable()
export class OauthService {
    refreshTokenInterval: number = 0;
    authConfig:any ={};

    constructor(private http: Http, private appConfigService: AppConfigService) {
    }

    setAuthConfig(authConfig){
        this.authConfig = authConfig
    }

    getOauthToken() {
        let _authConfig = this.authConfig;
        let formData: FormData = new FormData();
        formData.append('grant_type', _authConfig.grant_type);
        formData.append('client_id', _authConfig.client_id);
        formData.append('client_secret', _authConfig.client_secret);
        formData.append('username', _authConfig.username);
        formData.append('password', _authConfig.password);
        let tokenUrl = this.appConfigService.getConfig('drupalUrl');
        this.http.post(tokenUrl + '/oauth/token', formData).subscribe(
            (response: any) => {
                this.setEnviromentBearerToken(response);
            });
    }

    getAuthConfigSetting(){
        return this.http.get('assets/json/oauth-config.json')
    }

    private setEnviromentBearerToken(response) {
        let _authConfig = this.authConfig;
        try {
            let tokenResponse = JSON.parse(response._body);
            let authHeader = environment.sessionCookieInformation.headers.
                find(e => e.headerName === 'Authorization');
            authHeader.headerValue = authHeader.headerValue.replace('[authToken]', tokenResponse.access_token);
            if (!this.refreshTokenInterval) {
                this.refreshTokenInterval = tokenResponse.expires_in;
                let intervalSeconds = this.refreshTokenInterval * 1000 - _authConfig.refreshTime * 1000;
                setInterval(() => {
                    this.getOauthToken();
                }, intervalSeconds);
            }
        } catch (error) {

        }
    }

    getAuthorizationHeader() {
        let authHeader = this.appConfigService.getSessionCookieInformation().headers.
            find(e => e.headerName === 'Authorization');
        let headers = new Headers();
        headers.append(authHeader.headerName, authHeader.headerValue);
        return headers;
    }



}