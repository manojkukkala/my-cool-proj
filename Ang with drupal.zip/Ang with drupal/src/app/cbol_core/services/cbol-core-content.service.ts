import { Injectable } from '@angular/core';
import { ContentService, HttpServiceErrorHandler } from 'angular-nexus-uiux/services';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { CbolCoreContent } from './cbol-core-content';
import { Cookie } from 'ng2-cookies/ng2-cookies';

@Injectable()
export class CbolCoreContentService {
	private content: Object = {};
	private appId = 'cbol_ag_container';

	constructor(private contentService: ContentService) {
		console.log('Constructor CbolCoreContentService');
		const locale = Cookie.get('locale') ? Cookie.get('locale') : 'en_US';
		this.content = CbolCoreContent[locale];
		this.onInit();
	};

	onInit(): void {
		const content: Observable<any> = this.contentService.getStaticBundle(this.appId);
		content.subscribe(data => {
			this.content = data;
			console.log('Core content fetched');
		}, this.errorHandler);
	}

	getContent(): Object {
		return this.content;
	}

	getContentForKey(key: string): Object {
		if (key != null && key !== undefined) {
			return this.content[key];
		}
	}

	/*Custom Error Handler to handle content fetch failure
		Use hardcoded content to display page
		TODO Move content to separate file*/
	errorHandler: HttpServiceErrorHandler = (error: Response): Observable<any> => {
		console.log('Core Content Fetch failed');
		return Observable.of(this.content);
	}
}
