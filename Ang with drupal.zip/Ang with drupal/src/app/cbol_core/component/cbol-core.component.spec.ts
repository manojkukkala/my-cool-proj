import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CoreCommonModule, CoreServicesModule } from 'angular-nexus-uiux';
import { CbolCoreComponent } from './cbol-core.component';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing'
import { SessionService, AppConfigService, StorageService, HttpService } from 'angular-nexus-uiux/services';
import { CitiServicesModule } from 'uicomponents/citi-services.module';

describe('CbolCoreComponent', () => {

	const appConfigService = {
		crossSiteScriptingRegex() {

		},
		getHttpServiceConfig() {
			return {
				defaultHeaders: {
					'Content-Type': 'application/json',
					'client_id': '19ec18cc-9580-43d5-8449-90cd2e13edb1',
					'businessCode': 'GCB',
					'countryCode': 'US',
					'channelId': 'CBOL',
					'Accept': 'application/json',
					'uuid': 'e941b996-ada1-4f4f-ab76-cf3aaf96c100'
				},
				headersToSendFromPreviousResponse: [
					{
						headerNameInPreviousResponse: 'CCPToken',
						headerNameToSendInRequest: 'CCPToken'
					},
					{
						headerNameInPreviousResponse: 'bizToken',
						headerNameToSendInRequest: 'bizToken',
						deleteOnAppLoad: true
					}
				]
			}
		}
	}

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [RouterModule, CoreCommonModule, RouterTestingModule, CoreServicesModule, CitiServicesModule
			],
			declarations: [CbolCoreComponent],
			providers: [SessionService, HttpService, StorageService,
				{ provide: AppConfigService, useValue: appConfigService }],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		})
			.compileComponents();
	}));

	it('should create', () => {
		const fixture = TestBed.createComponent(CbolCoreComponent);
		const component = fixture.debugElement.componentInstance;
		expect(component).toBeTruthy();
	});
});
