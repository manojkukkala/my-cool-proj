import { Component, OnInit,ViewEncapsulation  } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { NonFatalErrorService } from '../services/cbol-core-nonFatalError.service';
import { Subscription } from 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';
import { ContentService,AppConfigService } from 'angular-nexus-uiux/services';
@Component({
  templateUrl: './cbol-core-nonFatalError.component.html',
  styleUrls: ['./cbol-core-nonFatalError.component.css'],
  providers:[NonFatalErrorService]
})
export class NonFatalErrorComponent implements OnInit {
   errorContentConfig :any;
   subscription: Subscription;
   errorType:any;
  errorCategory:any;
  contentData:any;
  constructor( private angularErrorPageService : NonFatalErrorService,private route : ActivatedRoute,private _cs: ContentService) {

  }
 getErrorMessageContent(errorType){
		 this.angularErrorPageService.getErrorMessageData(errorType).catch((err: Response) => {
			return Observable.throw(err);
		 }).subscribe (response => {
			this.errorContentConfig = (this._cs.get('USCBOL', 'config', 'ErrorCategoryConfig', 'VALUE'));
			this.errorCategory = this.errorContentConfig[errorType];       
			this.contentData=(this._cs.get('USCBOL', 'copy', this.errorCategory, 'TEXT'));
		 })

	}
  ngOnInit() {
		this.subscription = this.route.queryParams.subscribe((queryParam: any) => {
			if (queryParam['errorCode'] != null) {
			  this.errorType = queryParam['errorCode'];
			}
			});

		this.getErrorMessageContent(this.errorType);

		};
 }
