import { Injectable } from '@angular/core';

@Injectable()
export class FaqfilterService {
    public data: any;

    constructor() {
        this.data = { 
    // Filter by single Taxonomy term        
            'AppleWatchDevicetag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Apple Watch Device'                
                    }
                }
            },
            'CitiMobileSnapshottag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Citi Mobile® Snapshot'                
                    }
                }
            },
            'FICOScoretag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'FICO Score'                
                    }
                }
            },
            'Investmentstag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Investments'                
                    }
                }
            },
            'MobileCheckDeposittag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Mobile Check Deposit'                
                    }
                }
            },
            'Rewardstag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Rewards'                
                    }
                }
            },
            'SignOntag': { /*Sign on*/
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Sign On'                
                    }
                }
            },
            'Statementstag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Statements'                
                    }
                }
            },
            'TrustedIdentitytag': {
                'tagFilter': {
                    'condition': {
                        'path': 'field_content_tags.name',                        
                        'value': 'Trusted Identity'                
                    }
                }
            },
            inFilter: {
                decisionFilter: {                
                    path: 'field_content_tags.name',                
                    value: ['Android','iOS','All Customers'],                
                    operator: 'IN'                    
                    }                
            }
        };
    };
    // Default filter
    getfilters = () =>{  
        //return this.data.inFilter1;        
        let filterData =  this.data.inFilter; 
        if(filterData){
            return filterData;
        }else{
            return this.data.SignOntag;
        }
    };
}