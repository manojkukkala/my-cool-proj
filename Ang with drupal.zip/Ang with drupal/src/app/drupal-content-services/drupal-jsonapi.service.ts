import { Injectable, OnDestroy } from '@angular/core';
import { Headers, RequestOptionsArgs, Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';

import { JsonApiQueryData, ModelType, JsonApiModel } from 'angular2-jsonapi';
import { Datastore } from '../drupal-content-services/datastore';

@Injectable()
export class DrupalJSONAPIService{

    constructor( private http: Http, private dataStore: Datastore){
    }

    getDocument(model: ModelType<JsonApiModel>, id: string, parameters: Object = {}): Observable<JsonApiModel>{
        return Observable.create(observer => {
            this.dataStore.findRecord(model, id, parameters).subscribe(document => {
                observer.next(document);
                observer.complete();
            }) 
        })
    }
}