import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { TermsDataModel } from "../nodes/terms_data.model";

@JsonApiModelConfig({
    type: 'paragraph--terms'
})
export class TermsModel extends JsonApiModel {
    @Attribute()
    headerText: string;

    @BelongsTo()
    termsData: TermsDataModel;

    @HasMany()
    components: JsonApiModel[];
}