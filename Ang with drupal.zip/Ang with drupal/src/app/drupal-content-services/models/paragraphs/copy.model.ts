import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--copy'
})
export class CopyModel extends JsonApiModel {
    @Attribute()
    title: string;

    @Attribute()
    listItem: string;

    @Attribute()
    listType: string;
}