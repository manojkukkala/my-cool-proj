import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';

@JsonApiModelConfig({
    type: 'paragraph--copy_list'
})
export class CopyListModel extends JsonApiModel {
    @Attribute()
    listTitle: string;

    @Attribute()
    listItems: string;

    @Attribute()
    listColumns: string;

    @Attribute()
    leftListItems: string;

    @Attribute()
    rightListItems: string;    

    @Attribute()
    listStyle: string;
}