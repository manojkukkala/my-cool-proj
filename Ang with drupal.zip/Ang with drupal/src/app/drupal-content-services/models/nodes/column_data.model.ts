import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
import { FileDataModel } from '../nodes/file.model';

@JsonApiModelConfig({
    type: 'showcase'
})
export class ColumnDataModel extends JsonApiModel {
    @BelongsTo()
    headerImg: FileDataModel;

    @Attribute()
    headerText: string;

    @Attribute()
    descriptionText: string;

    @Attribute()
    footerLink: Link;

    @Attribute()
    linkText: string;

    @Attribute()
    linkUrl: string;
}