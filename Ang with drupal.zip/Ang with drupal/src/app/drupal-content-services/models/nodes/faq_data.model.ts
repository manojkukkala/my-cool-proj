import { JsonApiModelConfig, JsonApiModel, Attribute, HasMany, BelongsTo } from 'angular2-jsonapi';
import { Link } from '../../drupal-fields.interface';
// import { TaxDataModel } from 'app/drupal-content-services/models/nodes';
// import { TaxDataModel } from '../nodes/tax.model';

@JsonApiModelConfig({
    type: 'faq'
})
export class FaqDataModel extends JsonApiModel {

    //  @BelongsTo()
    //  faqCategory: TaxDataModel;

     @Attribute()
    faqCategory: string;
    
    @Attribute()
    nid: string;

     @Attribute()
    faqQuestion: string;

    @Attribute()
    faqAnswer: string;

}