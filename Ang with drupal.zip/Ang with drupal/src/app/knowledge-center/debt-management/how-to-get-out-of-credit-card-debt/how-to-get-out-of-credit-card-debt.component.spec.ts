import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToGetOutOfCreditCardDebtComponent } from './how-to-get-out-of-credit-card-debt.component';

describe('HowToGetOutOfCreditCardDebtComponent', () => {
  let component: HowToGetOutOfCreditCardDebtComponent;
  let fixture: ComponentFixture<HowToGetOutOfCreditCardDebtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToGetOutOfCreditCardDebtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToGetOutOfCreditCardDebtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
