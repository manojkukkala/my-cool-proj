import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImproveCreditHealthComponent } from './improve-credit-health.component';

describe('ImproveCreditHealthComponent', () => {
  let component: ImproveCreditHealthComponent;
  let fixture: ComponentFixture<ImproveCreditHealthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImproveCreditHealthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImproveCreditHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
