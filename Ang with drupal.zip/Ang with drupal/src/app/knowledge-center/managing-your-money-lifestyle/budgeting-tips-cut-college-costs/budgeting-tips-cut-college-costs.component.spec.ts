import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BudgetingTipsCutCollegeCostsComponent } from './budgeting-tips-cut-college-costs.component';

describe('BudgetingTipsCutCollegeCostsComponent', () => {
  let component: BudgetingTipsCutCollegeCostsComponent;
  let fixture: ComponentFixture<BudgetingTipsCutCollegeCostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BudgetingTipsCutCollegeCostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BudgetingTipsCutCollegeCostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
