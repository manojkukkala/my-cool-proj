import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowDoesDivorceAffectYourCreditComponent } from './how-does-divorce-affect-your-credit.component';

describe('HowDoesDivorceAffectYourCreditComponent', () => {
  let component: HowDoesDivorceAffectYourCreditComponent;
  let fixture: ComponentFixture<HowDoesDivorceAffectYourCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowDoesDivorceAffectYourCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowDoesDivorceAffectYourCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
