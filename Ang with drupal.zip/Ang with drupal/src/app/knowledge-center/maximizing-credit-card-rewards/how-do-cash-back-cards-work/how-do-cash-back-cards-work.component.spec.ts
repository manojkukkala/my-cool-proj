import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowDoCashBackCardsWorkComponent } from './how-do-cash-back-cards-work.component';

describe('HowDoCashBackCardsWorkComponent', () => {
  let component: HowDoCashBackCardsWorkComponent;
  let fixture: ComponentFixture<HowDoCashBackCardsWorkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowDoCashBackCardsWorkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowDoCashBackCardsWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
