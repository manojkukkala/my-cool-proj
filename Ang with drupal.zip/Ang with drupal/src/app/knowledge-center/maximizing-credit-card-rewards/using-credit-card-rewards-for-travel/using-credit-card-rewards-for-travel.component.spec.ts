import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsingCreditCardRewardsForTravelComponent } from './using-credit-card-rewards-for-travel.component';

describe('UsingCreditCardRewardsForTravelComponent', () => {
  let component: UsingCreditCardRewardsForTravelComponent;
  let fixture: ComponentFixture<UsingCreditCardRewardsForTravelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsingCreditCardRewardsForTravelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsingCreditCardRewardsForTravelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
