import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsideACreditReportComponent } from './inside-a-credit-report.component';

describe('InsideACreditReportComponent', () => {
  let component: InsideACreditReportComponent;
  let fixture: ComponentFixture<InsideACreditReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsideACreditReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsideACreditReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
