import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToOvercomeCreditCardFearComponent } from './how-to-overcome-credit-card-fear.component';

describe('HowToOvercomeCreditCardFearComponent', () => {
  let component: HowToOvercomeCreditCardFearComponent;
  let fixture: ComponentFixture<HowToOvercomeCreditCardFearComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToOvercomeCreditCardFearComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToOvercomeCreditCardFearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
