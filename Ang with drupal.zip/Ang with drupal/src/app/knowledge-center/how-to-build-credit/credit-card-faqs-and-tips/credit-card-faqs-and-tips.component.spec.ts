import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditCardFaqsAndTipsComponent } from './credit-card-faqs-and-tips.component';

describe('CreditCardFaqsAndTipsComponent', () => {
  let component: CreditCardFaqsAndTipsComponent;
  let fixture: ComponentFixture<CreditCardFaqsAndTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditCardFaqsAndTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardFaqsAndTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
