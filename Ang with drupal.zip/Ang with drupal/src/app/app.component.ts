import { Component, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { HttpService, HttpServiceErrorHandler } from 'angular-nexus-uiux/services';
import {OauthService} from './oauth/oauth-service';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

	constructor(private _httpService: HttpService, private _oauthService:OauthService) {
	}

	ngOnInit() {
		this._oauthService.getAuthConfigSetting().subscribe(
            (response: any) => {
				this._oauthService.setAuthConfig(JSON.parse(response._body));
                this._oauthService.getOauthToken();
            });
		const globalErrorHandler: HttpServiceErrorHandler = (error: Response): Observable<Response> => {
			// Define the global error handler
			let errMsg: string;
			const body = error.json() || '';
			const err = body.error || JSON.stringify(body);
			if (error.status === 500) {
				// Handle 500 error
				errMsg = `Global Error: 500`;
			} else if (error.status === 400) {
				// Handle 400 error
				errMsg = `Global Error: 400`;
			} else {
				errMsg = `Global Error: ${error.status} - ${error.statusText || ''} ${err}`;
			}
			console.error(errMsg);
			return Observable.throw(error);
		}

		this._httpService.addGlobalErrorHandler('globalErrorHandler', globalErrorHandler);

	}



}
