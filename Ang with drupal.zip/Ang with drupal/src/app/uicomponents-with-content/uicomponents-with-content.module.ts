import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActionComponent } from './action/action.component';
import { CitiModule } from 'uicomponents/citi.module';
import { SharedModule } from '../shared/shared.module';
import { HeroComponent } from './hero/hero.component';
import { ShowcaseComponent } from './showcase/showcase.component';
import { CardComponent } from './card/card.component';
import { CopyComponent } from './copy/copy.component';
import { CopyListComponent } from './copy-list/copy-list.component';
import { CopywarningComponent } from './copywarning/copywarning.component';
import { PromoComponent } from './promo/promo.component';
import { CitiActionsComponent } from './citi-actions/citi-actions.component';
import { ArticleParagraphComponent } from './article-paragraph/article-paragraph.component';
import { ButtonBarComponent } from './button-bar/button-bar.component';
import { EditComponent } from './edit/edit.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { BannerComponent } from './banner/banner.component';
import { SocialIconsComponent } from './social-icons/social-icons.component';
import { FaqComponent } from './faq/faq.component';
import { AlertComponent } from './alert/alert.component';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CitiModule
  ],
  declarations: [ActionComponent, HeroComponent, ShowcaseComponent, CardComponent, CopyComponent, CopyListComponent, CopywarningComponent, PromoComponent, CitiActionsComponent, ArticleParagraphComponent, ButtonBarComponent, EditComponent, BreadcrumbComponent, BannerComponent, SocialIconsComponent, FaqComponent, AlertComponent],
  exports: [
    AlertComponent,
    ActionComponent, 
    HeroComponent,
    ShowcaseComponent,
    CardComponent,
    CopyComponent,
    CopyListComponent,
    CopywarningComponent,
    PromoComponent,
    CitiActionsComponent,
    ArticleParagraphComponent,
    ButtonBarComponent,
    EditComponent,
    BreadcrumbComponent,
    BannerComponent,
    SocialIconsComponent,
	  FaqComponent
  ]
})
export class UIComponentsWithContentModule { }
