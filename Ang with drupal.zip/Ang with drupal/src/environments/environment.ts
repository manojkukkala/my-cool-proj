// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
	production: false,
	environment: 'DEV',
	drupalUrl: 'http://cddemo10ode52.prod.acquia-sites.com',
	contentfulUrl:'https://app.contentful.com',
	locale: 'en_US',
	businessId: 'USGCB',
	apiServerUrl: 'http://localhost:7878',
	snarejsUrl: 'https://ci-mpsnare.iovation.com/snare.js',
	amwSubDomainName: 'paperuat.citi.com',
	amwSnippetId: '1278930',
	ensightenHost: 'https://nexus.ensighten.com/citi/na_dev',
	crossSiteScriptingRegex: /\00|<|\+ADw-|>|\+AD4-|%25|\(\s*[a-z]{2,}\.[a-z]{2,}.*\)/g,
	sessionCookieInformation: {

		cookieName: 'NGACoExistenceCookie',
		valueSeparator: '|',
		headers: [
			{
				headerName: 'bizToken',
				headerValue: '[bizToken]'
			},
			{
				headerName: 'Authorization',
				headerValue: 'Bearer [authToken]'
			},
			{
				headerName: 'client_id',
				headerValue: '[clientId]'
			}
		],
		isFriendKey: 'isFriend'
	},

	sessionService: {
		sessionTimeout: 600,
		keepAliveInterval: 180,
		sessionKeepAliveUrl: 'http://localhost:7878/keepAlive',
		sessionTimeoutUrl: 'http://localhost:3000/US/JSO/signon/CBOLSessionRecovery.do'
	},

	contentService: {
		staticBaseUrl: 'http://localhost:7878',
		bundles: {
			static_test: {
				businessId: 'BUSIDSTATICTEST',
				locale: 'en_US'
			}
		}
	},

	mfaUiService: {
		bundleName: 'mfa_common',
		pinBlockedUrl: 'https://uat1.online.citi.com/JSO/signoff/Signoff.do?eostype=OTPBlockedPIN'
	},
	idleTimeRouterService: {
		routeAfter: 600,
		routingInfo: [
			{
				appName: 'TY',
				routeUrl: 'https://thankyou.com'
			}
		],
		defaultRoute: 'https://uat1.online.citi.com/US/login.do'
	},

	httpService: {
		defaultHeaders:
		{
			'Content-Type': 'application/json',
			'client_id': '19ec18cc-9580-43d5-8449-90cd2e13edb1',
			'businessCode': 'GCB',
			'countryCode': 'US',
			'channelId': 'CBOL',
			'Accept': 'application/json',
			'uuid': 'e941b996-ada1-4f4f-ab76-cf3aaf96c100'
		},
		headersToSendFromPreviousResponse: [
			{
				headerNameInPreviousResponse: 'CCPToken',
				headerNameToSendInRequest: 'CCPToken'
			},
			{
				headerNameInPreviousResponse: 'bizToken',
				headerNameToSendInRequest: 'bizToken',
				deleteOnAppLoad: true
			}
		]
	},
	mapService: {
		googleApiKey: 'AIzaSyBm5OAD_gzMWGCYtZMQQqYCEnRngONa9qw',
		endpointUrl: '//geolocationservice-dev1.cfapps-gcg-gtdc1.citipaas-dev.dyn.nsroot.net/geoLocations/places/retrieve'
	},
	customConfig: {
		brandingEndpoint: '/api/brandingConfig',
		errorUrl: '/US/JPS/portal/Unauthorized.do',
		chatServiceEndpoint: 'https://vm-f1a3-a41e.nam.nsroot.net:8885/chat/getChatConfig?screenId=',
		chatScriptSrc: 'https://vm-f1a3-a41e.nam.nsroot.net:8885/JEA/CHAT/js/injectChat.js'
	},

//*******  Contentful  *******//
	contentful: {
		spaceId: 'u15lqv8s2w38',
		token: '79aee87dee526ddbc0b2e6de027cf3f7413abc2fc2b7ccc5f2ede73c9dac07e6'
	  }




}
